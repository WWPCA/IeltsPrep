import json
import boto3
import os
from datetime import datetime
import urllib.parse
import urllib.request
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

def lambda_handler(event, context):
    """AWS Lambda Handler - Production IELTS GenAI Prep Platform"""
    
    # CloudFront security validation
    headers = event.get('headers', {})
    cf_secret_found = False
    for header_name in ['cf-secret-3140348d', 'CF-Secret-3140348d', 'x-cf-secret-3140348d']:
        if headers.get(header_name) == 'valid':
            cf_secret_found = True
            break
    
    if not cf_secret_found:
        logger.warning("CloudFront validation failed")
        return {
            'statusCode': 403,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': 'Access denied - CloudFront validation required'})
        }
    
    path = event.get('path', '/')
    method = event.get('httpMethod', 'GET')
    
    logger.info(f"Processing {method} {path}")
    
    try:
        if path == '/' or path == '/home':
            return serve_home_page()
        elif path == '/login':
            return serve_login_page() if method == 'GET' else handle_login(event)
        elif path == '/privacy-policy':
            return serve_privacy_policy()
        elif path == '/terms-of-service':
            return serve_terms_of_service()
        elif path == '/robots.txt':
            return serve_robots_txt()
        elif path == '/api/health':
            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({'status': 'healthy', 'timestamp': datetime.now().isoformat()})
            }
        elif path.startswith('/assessment/'):
            return serve_assessment_page(path)
        elif path == '/dashboard' or path == '/profile':
            return serve_dashboard()
        elif path == '/register':
            return serve_register_page()
        else:
            return {
                'statusCode': 404,
                'headers': {'Content-Type': 'text/html'},
                'body': get_404_page()
            }
    
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'text/html'},
            'body': get_500_page()
        }

def serve_home_page():
    """Serve approved comprehensive template"""
    template = "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <meta name=\"description\" content=\"The only AI-powered IELTS assessment platform with standardized band scoring. Prepare for IELTS Writing and Speaking with TrueScore® and ClearScore® technologies.\">\n    <meta name=\"keywords\" content=\"IELTS AI Assessment, IELTS Writing Feedback, IELTS Speaking Evaluation, GenAI IELTS App, TrueScore IELTS, ClearScore IELTS, AI Band Score, IELTS Band Descriptors, Academic IELTS, General Training IELTS, AI IELTS Practice, Online IELTS Preparation, AI Language Assessment, IELTS Prep App, IELTS writing preparation, IELTS speaking practice test, IELTS writing practice test, IELTS practice test with feedback\">\n    <meta property=\"og:title\" content=\"IELTS GenAI Prep - AI-Powered IELTS Assessment Platform\">\n    <meta property=\"og:description\" content=\"The only AI-powered IELTS assessment platform with standardized band scoring using TrueScore® and ClearScore® technologies.\">\n    <meta property=\"og:type\" content=\"website\">\n    <meta name=\"twitter:card\" content=\"summary_large_image\">\n    <meta name=\"twitter:title\" content=\"IELTS GenAI Prep - AI-Powered IELTS Assessment Platform\">\n    <meta name=\"twitter:description\" content=\"The only AI-powered IELTS assessment platform with standardized band scoring using TrueScore® and ClearScore® technologies.\">\n    <title>IELTS GenAI Prep - AI-Powered IELTS Assessment Platform</title>\n    \n    <!-- Bootstrap CSS -->\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">\n    \n    <!-- Font Awesome for icons -->\n    <link href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css\" rel=\"stylesheet\">\n    \n    <!-- Google Fonts -->\n    <link href=\"https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap\" rel=\"stylesheet\">\n    \n    <!-- Schema.org Organization Markup -->\n    <script type=\"application/ld+json\">\n    {\n      \"@context\": \"https://schema.org\",\n      \"@type\": \"Organization\",\n      \"name\": \"IELTS GenAI Prep\",\n      \"url\": \"https://www.ieltsgenaiprep.com\",\n      \"logo\": \"https://www.ieltsgenaiprep.com/logo.png\",\n      \"description\": \"IELTS GenAI Prep is an AI-powered IELTS assessment platform offering instant band-aligned feedback for Writing and Speaking modules.\",\n      \"sameAs\": [\n        \"https://www.linkedin.com/company/ieltsgenaiprep\",\n        \"https://www.twitter.com/ieltsgenaiprep\"\n      ]\n    }\n    </script>\n    \n    <!-- FAQ Schema Markup -->\n    <script type=\"application/ld+json\">\n    {\n      \"@context\": \"https://schema.org\",\n      \"@type\": \"FAQPage\",\n      \"mainEntity\": [\n        {\n          \"@type\": \"Question\",\n          \"name\": \"What is IELTS GenAI Prep?\",\n          \"acceptedAnswer\": {\n            \"@type\": \"Answer\",\n            \"text\": \"IELTS GenAI Prep is an AI-powered assessment platform that delivers standardized, examiner-aligned band scores for IELTS Writing and Speaking, using official IELTS scoring criteria.\"\n          }\n        },\n        {\n          \"@type\": \"Question\",\n          \"name\": \"What makes IELTS GenAI Prep different from other IELTS prep tools?\",\n          \"acceptedAnswer\": {\n            \"@type\": \"Answer\",\n            \"text\": \"It is the only platform using TrueScore® and ClearScore® technologies to provide instant, AI-generated feedback that mirrors official IELTS band descriptors for both Academic and General Training modules.\"\n          }\n        },\n        {\n          \"@type\": \"Question\",\n          \"name\": \"How does TrueScore® assess IELTS Writing tasks?\",\n          \"acceptedAnswer\": {\n            \"@type\": \"Answer\",\n            \"text\": \"TrueScore® uses GenAI models trained on IELTS scoring rubrics to assess Task Achievement, Coherence & Cohesion, Lexical Resource, and Grammatical Range & Accuracy. Each submission receives band-aligned feedback.\"\n          }\n        },\n        {\n          \"@type\": \"Question\",\n          \"name\": \"How is ClearScore® used to evaluate IELTS Speaking?\",\n          \"acceptedAnswer\": {\n            \"@type\": \"Answer\",\n            \"text\": \"ClearScore® simulates a live speaking test using AI voice assessment technology. It scores fluency, pronunciation, grammar, and vocabulary in real-time, based on official IELTS speaking criteria.\"\n          }\n        },\n        {\n          \"@type\": \"Question\",\n          \"name\": \"Do you offer Academic and General Training modules?\",\n          \"acceptedAnswer\": {\n            \"@type\": \"Answer\",\n            \"text\": \"Yes. IELTS GenAI Prep supports both Academic and General Training formats for Writing and Speaking, allowing users to choose modules aligned with their test goals.\"\n          }\n        },\n        {\n          \"@type\": \"Question\",\n          \"name\": \"How much does it cost to use IELTS GenAI Prep?\",\n          \"acceptedAnswer\": {\n            \"@type\": \"Answer\",\n            \"text\": \"Each module (Writing or Speaking) is priced at $36.49 USD for four AI-graded assessments. This includes band scores and detailed feedback on every attempt.\"\n          }\n        },\n        {\n          \"@type\": \"Question\",\n          \"name\": \"Is this a mobile-only platform?\",\n          \"acceptedAnswer\": {\n            \"@type\": \"Answer\",\n            \"text\": \"IELTS GenAI Prep is optimized for mobile and desktop. Users can create an account on the website and access assessments on the IELTS GenAI mobile app anytime, anywhere.\"\n          }\n        },\n        {\n          \"@type\": \"Question\",\n          \"name\": \"How fast is the scoring process?\",\n          \"acceptedAnswer\": {\n            \"@type\": \"Answer\",\n            \"text\": \"All AI assessments are completed within seconds to a few minutes, providing instant band scores and feedback so users can improve quickly and effectively.\"\n          }\n        },\n        {\n          \"@type\": \"Question\",\n          \"name\": \"How reliable are the AI-generated IELTS scores?\",\n          \"acceptedAnswer\": {\n            \"@type\": \"Answer\",\n            \"text\": \"Our GenAI scores show a 96% alignment with certified IELTS examiners. The technology is built to mimic human scoring standards while ensuring consistency and speed.\"\n          }\n        },\n        {\n          \"@type\": \"Question\",\n          \"name\": \"Can I track my performance over time?\",\n          \"acceptedAnswer\": {\n            \"@type\": \"Answer\",\n            \"text\": \"Yes. Your personalized dashboard allows you to review past assessments, track band score improvements, and identify focus areas for continued practice.\"\n          }\n        }\n      ]\n    }\n    </script>\n    \n    <style>\n        body {\n            font-family: 'Roboto', sans-serif;\n            line-height: 1.6;\n        }\n        \n        .pricing-card {\n            border: 1px solid rgba(0, 0, 0, 0.125);\n            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);\n            transition: transform 0.2s;\n        }\n        \n        .pricing-card:hover {\n            transform: translateY(-5px);\n        }\n        \n        .genai-brand-section {\n            margin-bottom: 60px;\n        }\n        \n        .brand-icon {\n            font-size: 2.5rem;\n            margin-bottom: 15px;\n        }\n        \n        .brand-title {\n            font-size: 2rem;\n            margin-bottom: 0.5rem;\n        }\n        \n        .brand-tagline {\n            color: #666;\n            margin-bottom: 2rem;\n            font-size: 1.1rem;\n        }\n        \n        .hero {\n            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);\n            color: white;\n            padding: 80px 0;\n        }\n        \n        .features {\n            padding: 80px 0;\n            background: #f8f9fa;\n        }\n        \n        .navbar {\n            background-color: #fff !important;\n            box-shadow: 0 2px 4px rgba(0,0,0,0.1);\n        }\n        \n        .navbar-brand {\n            font-weight: bold;\n            color: #4361ee !important;\n        }\n        \n        .navbar-nav .nav-link {\n            color: #333 !important;\n            font-weight: 500;\n        }\n        \n        .navbar-nav .nav-link:hover {\n            color: #4361ee !important;\n        }\n        \n        /* Enhanced animations and interactivity */\n        .hero h1 {\n            animation: fadeInUp 0.8s ease-out;\n        }\n        \n        .hero h2 {\n            animation: fadeInUp 0.8s ease-out 0.2s both;\n        }\n        \n        .hero .mb-4 > div {\n            animation: fadeInLeft 0.6s ease-out 0.4s both;\n        }\n        \n        .hero .mb-4 > div:nth-child(2) {\n            animation-delay: 0.6s;\n        }\n        \n        .hero .mb-4 > div:nth-child(3) {\n            animation-delay: 0.8s;\n        }\n        \n        .hero p {\n            animation: fadeInUp 0.8s ease-out 1s both;\n        }\n        \n        .hero-buttons {\n            animation: fadeInUp 0.8s ease-out 1.2s both;\n        }\n        \n        .hero .col-lg-6:last-child {\n            animation: fadeInRight 0.8s ease-out 0.5s both;\n        }\n        \n        @keyframes fadeInUp {\n            from {\n                opacity: 0;\n                transform: translateY(30px);\n            }\n            to {\n                opacity: 1;\n                transform: translateY(0);\n            }\n        }\n        \n        @keyframes fadeInLeft {\n            from {\n                opacity: 0;\n                transform: translateX(-30px);\n            }\n            to {\n                opacity: 1;\n                transform: translateX(0);\n            }\n        }\n        \n        @keyframes fadeInRight {\n            from {\n                opacity: 0;\n                transform: translateX(30px);\n            }\n            to {\n                opacity: 1;\n                transform: translateX(0);\n            }\n        }\n        \n        /* Button hover effects */\n        .hero-buttons .btn:hover {\n            transform: translateY(-3px);\n            box-shadow: 0 8px 25px rgba(0,0,0,0.2);\n        }\n        \n        .btn-success:hover {\n            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);\n            box-shadow: 0 6px 20px rgba(40, 167, 69, 0.6);\n        }\n        \n        .btn-outline-light:hover {\n            background: rgba(255,255,255,0.1);\n            border-color: rgba(255,255,255,1);\n            backdrop-filter: blur(10px);\n        }\n        \n        /* Icon container hover effects */\n        .hero .me-3:hover {\n            background: rgba(255,255,255,0.3);\n            transform: scale(1.1);\n            transition: all 0.3s ease;\n        }\n        \n        /* Improved typography for better readability and spacing */\n        @media (max-width: 768px) {\n            .hero {\n                padding: 60px 0;\n            }\n            \n            .hero h1 {\n                font-size: 2.5rem !important;\n                line-height: 1.3 !important;\n            }\n            \n            .hero h2 {\n                font-size: 1.3rem !important;\n            }\n            \n            .hero-buttons .btn {\n                display: block;\n                width: 100%;\n                margin-bottom: 15px;\n                margin-right: 0 !important;\n            }\n            \n            .hero .col-lg-6:first-child {\n                text-align: center !important;\n            }\n        }\n        \n        @media (max-width: 576px) {\n            .hero h1 {\n                font-size: 2rem !important;\n                line-height: 1.2 !important;\n            }\n            \n            .hero h2 {\n                font-size: 1.1rem !important;\n            }\n            \n            .hero .mb-4 span {\n                font-size: 1rem !important;\n            }\n        }\n    </style>\n</head>\n\n<body>\n    <!-- Navigation -->\n    <nav class=\"navbar navbar-expand-lg navbar-light bg-light fixed-top\">\n        <div class=\"container\">\n            <a class=\"navbar-brand\" href=\"/\">IELTS GenAI Prep</a>\n            <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarNav\">\n                <span class=\"navbar-toggler-icon\"></span>\n            </button>\n            <div class=\"collapse navbar-collapse\" id=\"navbarNav\">\n                <ul class=\"navbar-nav ms-auto\">\n                    <li class=\"nav-item\">\n                        <a class=\"nav-link\" href=\"#how-it-works\">How it Works</a>\n                    </li>\n                    <li class=\"nav-item\">\n                        <a class=\"nav-link\" href=\"#assessments\">Assessments</a>\n                    </li>\n                    <li class=\"nav-item\">\n                        <a class=\"nav-link\" href=\"#faq\">FAQ</a>\n                    </li>\n                    <li class=\"nav-item\">\n                        <a class=\"nav-link\" href=\"/login\">Login</a>\n                    </li>\n                </ul>\n            </div>\n        </div>\n    </nav>\n\n    <!-- Hero Section -->\n    <section class=\"hero\" style=\"margin-top: 76px; padding: 80px 0; position: relative; overflow: hidden;\">\n        <!-- Background enhancement -->\n        <div style=\"position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%); pointer-events: none;\"></div>\n        \n        <div class=\"container\">\n            <div class=\"row align-items-center\">\n                <div class=\"col-lg-6 text-center text-lg-start mb-5 mb-lg-0\">\n                    <!-- SEO-Optimized H1 and Introduction -->\n                    <h1 class=\"display-3 fw-bold mb-3\" style=\"font-size: 3.5rem; line-height: 1.2; letter-spacing: -0.02em; color: #ffffff; text-shadow: 0 2px 4px rgba(0,0,0,0.1);\">\n                        AI-Powered IELTS Writing and Speaking Assessments with Official Band Scoring\n                    </h1>\n                    \n                    <p class=\"h4 mb-4\" style=\"font-size: 1.3rem; line-height: 1.4; font-weight: 500; color: rgba(255,255,255,0.95); margin-bottom: 2rem;\">\n                        IELTS GenAI Prep is the only AI-based IELTS preparation platform offering instant band-aligned feedback on Writing and Speaking. Powered by TrueScore® and ClearScore®, we replicate official examiner standards using GenAI technology.\n                    </p>\n                    \n                    <!-- Benefits with icons -->\n                    <div class=\"mb-4\">\n                        <div class=\"d-flex align-items-center justify-content-center justify-content-lg-start mb-3\">\n                            <div class=\"me-3\" style=\"width: 40px; height: 40px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(10px);\">\n                                <i class=\"fas fa-brain text-white\" style=\"font-size: 1.1rem;\"></i>\n                            </div>\n                            <span class=\"text-white\" style=\"font-size: 1.1rem; font-weight: 500;\">AI-Powered Scoring Technology</span>\n                        </div>\n                        \n                        <div class=\"d-flex align-items-center justify-content-center justify-content-lg-start mb-3\">\n                            <div class=\"me-3\" style=\"width: 40px; height: 40px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(10px);\">\n                                <i class=\"fas fa-check-circle text-white\" style=\"font-size: 1.1rem;\"></i>\n                            </div>\n                            <span class=\"text-white\" style=\"font-size: 1.1rem; font-weight: 500;\">Official IELTS Criteria Alignment</span>\n                        </div>\n                        \n                        <div class=\"d-flex align-items-center justify-content-center justify-content-lg-start mb-4\">\n                            <div class=\"me-3\" style=\"width: 40px; height: 40px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(10px);\">\n                                <i class=\"fas fa-bullseye text-white\" style=\"font-size: 1.1rem;\"></i>\n                            </div>\n                            <span class=\"text-white\" style=\"font-size: 1.1rem; font-weight: 500;\">Academic & General Training Modules</span>\n                        </div>\n                    </div>\n                    \n                    <p class=\"mb-5\" style=\"font-size: 1.1rem; line-height: 1.7; color: rgba(255,255,255,0.9); max-width: 500px; margin-left: auto; margin-right: auto;\">\n                        Experience TrueScore® and ClearScore® technologies that deliver standardized IELTS assessments based on official scoring criteria.\n                    </p>\n                    \n                    <!-- Enhanced CTA buttons -->\n                    <div class=\"hero-buttons text-center text-lg-start\">\n                        <a href=\"/login\" class=\"btn btn-success btn-lg me-3 mb-3\" style=\"font-size: 1.2rem; padding: 15px 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(40, 167, 69, 0.4); border: none; transition: all 0.3s ease;\" aria-label=\"Start using IELTS GenAI Prep assessments\">\n                            <i class=\"fas fa-rocket me-2\"></i>\n                            Get Started\n                        </a>\n                        <a href=\"#how-it-works\" class=\"btn btn-outline-light btn-lg mb-3\" style=\"font-size: 1.2rem; padding: 15px 30px; border-radius: 12px; border: 2px solid rgba(255,255,255,0.8); transition: all 0.3s ease;\" aria-label=\"Learn more about how IELTS GenAI Prep works\">\n                            <i class=\"fas fa-info-circle me-2\"></i>\n                            Learn More\n                        </a>\n                    </div>\n                </div>\n                \n                <div class=\"col-lg-6 text-center\">\n                    <!-- Sample Assessment Report Demo -->\n                    <div style=\"background: rgba(255,255,255,0.1); border-radius: 20px; padding: 40px; backdrop-filter: blur(15px); box-shadow: 0 10px 30px rgba(0,0,0,0.1);\">\n                        <div class=\"mb-3\">\n                            <span class=\"badge bg-primary text-white px-3 py-2\" style=\"font-size: 0.9rem; font-weight: 600;\">\n                                <i class=\"fas fa-star me-1\"></i>\n                                YOUR SCORE PREVIEW\n                            </span>\n                        </div>\n                        <div style=\"background: linear-gradient(135deg, #28a745 0%, #20c997 100%); border-radius: 15px; padding: 30px; margin-bottom: 20px; position: relative;\">\n                            <h3 class=\"text-white mb-2\" style=\"font-size: 1.4rem; font-weight: 600; line-height: 1.3;\">\n                                <i class=\"fas fa-certificate me-2\"></i>\n                                See Exactly How Your IELTS Score Will Look\n                            </h3>\n                            <div class=\"mb-3 d-flex justify-content-center\">\n                                <span class=\"badge bg-light text-dark px-3 py-1\" style=\"font-size: 0.85rem; font-weight: 500; display: inline-block; text-align: center;\">\n                                    <i class=\"fas fa-pencil-alt me-1\"></i>\n                                    Academic Writing Assessment Sample\n                                </span>\n                            </div>\n                            <p class=\"text-white mb-4\" style=\"font-size: 0.95rem; opacity: 0.95; font-weight: 400;\">\n                                Instant feedback. Official IELTS alignment. No guesswork.\n                            </p>\n                            \n                            <div class=\"text-white\" style=\"font-size: 1.05rem; line-height: 1.6;\">\n                                <div class=\"mb-4 text-center\" style=\"padding: 12px; background: rgba(255,255,255,0.15); border-radius: 10px;\">\n                                    <strong style=\"font-size: 1.3rem;\">Overall Band Score: 7.5</strong>\n                                </div>\n                                \n                                <div class=\"mb-3\" style=\"font-size: 0.95rem;\">\n                                    <div class=\"d-flex justify-content-between align-items-center mb-1\">\n                                        <span><strong>Task Achievement (25%)</strong></span>\n                                        <span class=\"badge bg-light text-dark\">Band 8</span>\n                                    </div>\n                                    <small style=\"opacity: 0.9; display: block; font-style: italic;\">Sufficiently addresses all parts with well-developed ideas</small>\n                                </div>\n                                \n                                <div class=\"mb-3\" style=\"font-size: 0.95rem;\">\n                                    <div class=\"d-flex justify-content-between align-items-center mb-1\">\n                                        <span><strong>Coherence & Cohesion (25%)</strong></span>\n                                        <span class=\"badge bg-light text-dark\">Band 7</span>\n                                    </div>\n                                    <small style=\"opacity: 0.9; display: block; font-style: italic;\">Logically organizes information with clear progression</small>\n                                </div>\n                                \n                                <div class=\"mb-3\" style=\"font-size: 0.95rem;\">\n                                    <div class=\"d-flex justify-content-between align-items-center mb-1\">\n                                        <span><strong>Lexical Resource (25%)</strong></span>\n                                        <span class=\"badge bg-light text-dark\">Band 7</span>\n                                    </div>\n                                    <small style=\"opacity: 0.9; display: block; font-style: italic;\">Flexible vocabulary to discuss variety of topics</small>\n                                </div>\n                                \n                                <div class=\"mb-3\" style=\"font-size: 0.95rem;\">\n                                    <div class=\"d-flex justify-content-between align-items-center mb-1\">\n                                        <span><strong>Grammar Range & Accuracy (25%)</strong></span>\n                                        <span class=\"badge bg-light text-dark\">Band 8</span>\n                                    </div>\n                                    <small style=\"opacity: 0.9; display: block; font-style: italic;\">Wide range of structures with good control</small>\n                                </div>\n                            </div>\n                            \n                            <div class=\"mt-4 pt-3\" style=\"border-top: 1px solid rgba(255,255,255,0.3);\">\n                                <div class=\"d-flex align-items-center justify-content-between flex-wrap\">\n                                    <div class=\"d-flex align-items-center mb-2\">\n                                        <i class=\"fas fa-shield-check me-2\" style=\"color: #90ee90;\"></i>\n                                        <span style=\"font-size: 0.9rem; font-weight: 500;\">Official IELTS Marking Rubrics + GenAI Precision</span>\n                                    </div>\n\n                                </div>\n                            </div>\n                        </div>\n                        \n                        <div class=\"text-center\">\n                            <div class=\"text-white mb-2\" style=\"font-size: 0.95rem; font-weight: 500;\">\n                                <i class=\"fas fa-robot me-1\"></i>\n                                Powered by TrueScore® & ClearScore® Technologies\n                            </div>\n                            <div class=\"text-white\" style=\"font-size: 0.9rem; opacity: 0.8; line-height: 1.4;\">\n                                This is an exact preview of the detailed report you'll receive after completing your first assessment.\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </section>\n\n    <!-- GenAI Technology Overview Section -->\n    <section class=\"assessment-sections py-5\" id=\"features\">\n        <div class=\"container\">\n            <div class=\"text-center mb-5\">\n                <h2 class=\"mb-3\">The World's ONLY Standardized IELTS GenAI Assessment System</h2>\n                <p class=\"text-muted\">Our proprietary technologies deliver consistent, examiner-aligned evaluations</p>\n            </div>\n            \n            <div class=\"row\">\n                <div class=\"col-md-6 mb-4\">\n                    <div class=\"card h-100 border-success\">\n                        <div class=\"card-header bg-success text-white text-center py-3\">\n                            <h3 class=\"m-0\">TrueScore® Writing Assessment</h3>\n                        </div>\n                        <div class=\"card-body text-center\">\n                            <i class=\"fas fa-pencil-alt fa-3x text-success mb-3\"></i>\n                            <div class=\"badge bg-light text-dark mb-3\">EXCLUSIVE TECHNOLOGY</div>\n                            <p>TrueScore® is the only GenAI system that evaluates IELTS writing using the full IELTS marking rubric. Get instant, expert-level feedback on:</p>\n                            <ul class=\"text-start mb-3\" style=\"list-style-type: none; padding-left: 0; font-size: 16px; line-height: 1.6;\">\n                                <li class=\"mb-2\"><span style=\"color: #28a745; font-size: 16px; margin-right: 10px;\">●</span><strong style=\"font-weight: 600;\">Task Achievement</strong></li>\n                                <li class=\"mb-2\"><span style=\"color: #28a745; font-size: 16px; margin-right: 10px;\">●</span><strong style=\"font-weight: 600;\">Coherence and Cohesion</strong></li>\n                                <li class=\"mb-2\"><span style=\"color: #28a745; font-size: 16px; margin-right: 10px;\">●</span><strong style=\"font-weight: 600;\">Lexical Resource</strong></li>\n                                <li class=\"mb-2\"><span style=\"color: #28a745; font-size: 16px; margin-right: 10px;\">●</span><strong style=\"font-weight: 600;\">Grammatical Range and Accuracy</strong></li>\n                            </ul>\n                            <p>Whether you're preparing for Academic Writing Tasks 1 & 2 or General Training Letter and Essay Writing, our AI coach gives you clear, structured band score reports and actionable improvement tips.</p>\n                        </div>\n                    </div>\n                </div>\n                \n                <div class=\"col-md-6 mb-4\">\n                    <div class=\"card h-100 border-primary\">\n                        <div class=\"card-header bg-primary text-white text-center py-3\">\n                            <h3 class=\"m-0\">ClearScore® Speaking Assessment</h3>\n                        </div>\n                        <div class=\"card-body text-center\">\n                            <i class=\"fas fa-microphone-alt fa-3x text-primary mb-3\"></i>\n                            <div class=\"badge bg-light text-dark mb-3\">EXCLUSIVE TECHNOLOGY</div>\n                            <p>ClearScore® is the world's first AI system for IELTS speaking evaluation. With real-time speech analysis, it provides detailed, criteria-based feedback across all three parts of the IELTS Speaking test:</p>\n                            <ul class=\"text-start mb-3\" style=\"list-style-type: none; padding-left: 0; font-size: 16px; line-height: 1.6;\">\n                                <li class=\"mb-2\"><span style=\"color: #007bff; font-size: 16px; margin-right: 10px;\">●</span><strong style=\"font-weight: 600;\">Fluency and Coherence</strong></li>\n                                <li class=\"mb-2\"><span style=\"color: #007bff; font-size: 16px; margin-right: 10px;\">●</span><strong style=\"font-weight: 600;\">Lexical Resource</strong></li>\n                                <li class=\"mb-2\"><span style=\"color: #007bff; font-size: 16px; margin-right: 10px;\">●</span><strong style=\"font-weight: 600;\">Grammatical Range and Accuracy</strong></li>\n                                <li class=\"mb-2\"><span style=\"color: #007bff; font-size: 16px; margin-right: 10px;\">●</span><strong style=\"font-weight: 600;\">Pronunciation</strong></li>\n                            </ul>\n                            <p>Practice with Maya, your AI IELTS examiner, for interactive, conversational assessments that mirror the real test.</p>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </section>\n\n    <!-- Features Section -->\n    <section class=\"features\" id=\"about\">\n        <div class=\"container\">\n            <h2 class=\"text-center mb-5\">Why Choose IELTS GenAI Prep for Your Assessment Preparation?</h2>\n            \n            <div class=\"row\">\n                <div class=\"col-md-4 mb-4\">\n                    <div class=\"card h-100 p-3 text-center\">\n                        <i class=\"fas fa-bullseye fa-4x text-primary mb-3\"></i>\n                        <h3 class=\"h4\">🎯 Official Band-Descriptive Feedback</h3>\n                        <p>All assessments follow official IELTS band descriptors, ensuring your practice matches the real test.</p>\n                    </div>\n                </div>\n                \n                <div class=\"col-md-4 mb-4\">\n                    <div class=\"card h-100 p-3 text-center\">\n                        <i class=\"fas fa-mobile-alt fa-4x text-success mb-3\"></i>\n                        <h3 class=\"h4\">📱 Mobile & Desktop Access – Anytime, Anywhere</h3>\n                        <p>Prepare at your own pace with secure cross-platform access. Start on mobile, continue on desktop – one account works everywhere.</p>\n                    </div>\n                </div>\n                \n                <div class=\"col-md-4 mb-4\">\n                    <div class=\"card h-100 p-3 text-center\">\n                        <i class=\"fas fa-lightbulb fa-4x text-warning mb-3\"></i>\n                        <h3 class=\"h4\">💡 Designed for Success</h3>\n                        <p>Our tools are perfect for IELTS Academic and General Training candidates seeking reliable, expert-guided feedback to boost scores and build confidence.</p>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </section>\n\n    <!-- Product Plans Section -->\n    <section class=\"pricing py-5 bg-light\" id=\"assessments\">\n        <div class=\"container\">\n            <h2 class=\"text-center mb-4\">GenAI Assessed IELTS Modules</h2>\n            <p class=\"text-center mb-5\">Our specialized GenAI technologies provide accurate assessment for IELTS preparation</p>\n            \n            <!-- TrueScore® Section -->\n            <div class=\"genai-brand-section mb-5\">\n                <div class=\"text-center mb-4\">\n                    <div class=\"brand-icon text-success\">\n                        <i class=\"fas fa-pencil-alt\"></i>\n                    </div>\n                    <h3 class=\"brand-title\">TrueScore® Writing Assessment</h3>\n                    <p class=\"brand-tagline\">Professional GenAI assessment of IELTS writing tasks aligned with the official IELTS band descriptors on Task Achievement, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy</p>\n                </div>\n                \n                <div class=\"row\">\n                    <!-- Academic Writing Assessment -->\n                    <div class=\"col-lg-6 mb-4\">\n                        <div class=\"card pricing-card\">\n                            <div class=\"card-header bg-success text-white text-center\">\n                                <h3 class=\"my-0 font-weight-bold\">Academic Writing</h3>\n                            </div>\n                            <div class=\"card-body\">\n                                <h1 class=\"card-title pricing-card-title text-center\">$36.49 USD<small class=\"text-muted\"> for 4 assessments</small></h1>\n                                <ul class=\"list-unstyled mt-3 mb-4\">\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>4 Unique Assessments Included</li>\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>Task 1 & Task 2 Assessment</li>\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>TrueScore® GenAI Evaluation</li>\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>Official IELTS Criteria Alignment</li>\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>Detailed Band Score Feedback</li>\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>Writing Improvement Recommendations</li>\n                                </ul>\n                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-success w-100\">Purchase via Mobile App</a>\n                            </div>\n                        </div>\n                    </div>\n\n                    <!-- General Writing Assessment -->\n                    <div class=\"col-lg-6 mb-4\">\n                        <div class=\"card pricing-card\">\n                            <div class=\"card-header bg-success text-white text-center\">\n                                <h3 class=\"my-0 font-weight-bold\">General Training Writing</h3>\n                            </div>\n                            <div class=\"card-body\">\n                                <h1 class=\"card-title pricing-card-title text-center\">$36.49 USD<small class=\"text-muted\"> for 4 assessments</small></h1>\n                                <ul class=\"list-unstyled mt-3 mb-4\">\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>4 Unique Assessments Included</li>\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>Letter & Essay Assessment</li>\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>TrueScore® GenAI Evaluation</li>\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>Official IELTS Criteria Alignment</li>\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>Comprehensive Feedback System</li>\n                                    <li><i class=\"fas fa-check text-success me-2\"></i>Target Band Achievement Support</li>\n                                </ul>\n                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-success w-100\">Purchase via Mobile App</a>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n\n            <!-- ClearScore® Section -->\n            <div class=\"genai-brand-section\">\n                <div class=\"text-center mb-4\">\n                    <div class=\"brand-icon text-primary\">\n                        <i class=\"fas fa-microphone-alt\"></i>\n                    </div>\n                    <h3 class=\"brand-title\">ClearScore® Speaking Assessment</h3>\n                    <p class=\"brand-tagline\">Revolutionary GenAI speaking assessment with real-time conversation analysis covering Fluency and Coherence, Lexical Resource, Grammatical Range and Accuracy, and Pronunciation</p>\n                </div>\n                \n                <div class=\"row\">\n                    <!-- Academic Speaking Assessment -->\n                    <div class=\"col-lg-6 mb-4\">\n                        <div class=\"card pricing-card\">\n                            <div class=\"card-header bg-primary text-white text-center\">\n                                <h3 class=\"my-0 font-weight-bold\">Academic Speaking</h3>\n                            </div>\n                            <div class=\"card-body\">\n                                <h1 class=\"card-title pricing-card-title text-center\">$36.49 USD<small class=\"text-muted\"> for 4 assessments</small></h1>\n                                <ul class=\"list-unstyled mt-3 mb-4\">\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>4 Unique Assessments Included</li>\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Interactive Maya AI Examiner</li>\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>ClearScore® GenAI Analysis</li>\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Real-time Speech Assessment</li>\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>All Three Speaking Parts</li>\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Pronunciation & Fluency Feedback</li>\n                                </ul>\n                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-primary w-100\">Purchase via Mobile App</a>\n                            </div>\n                        </div>\n                    </div>\n\n                    <!-- General Speaking Assessment -->\n                    <div class=\"col-lg-6 mb-4\">\n                        <div class=\"card pricing-card\">\n                            <div class=\"card-header bg-primary text-white text-center\">\n                                <h3 class=\"my-0 font-weight-bold\">General Training Speaking</h3>\n                            </div>\n                            <div class=\"card-body\">\n                                <h1 class=\"card-title pricing-card-title text-center\">$36.49 USD<small class=\"text-muted\"> for 4 assessments</small></h1>\n                                <ul class=\"list-unstyled mt-3 mb-4\">\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>4 Unique Assessments Included</li>\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Maya AI Conversation Partner</li>\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>ClearScore® GenAI Technology</li>\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Comprehensive Speaking Analysis</li>\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>General Training Topic Focus</li>\n                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Instant Performance Feedback</li>\n                                </ul>\n                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-primary w-100\">Purchase via Mobile App</a>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </section>\n\n    <!-- How It Works Section (AI Optimized) -->\n    <section class=\"py-5\" id=\"how-it-works\">\n        <div class=\"container\">\n            <h2 class=\"text-center mb-5\">How It Works</h2>\n            <div class=\"row justify-content-center\">\n                <div class=\"col-lg-8\">\n                    <ol class=\"list-group list-group-numbered\">\n                        <li class=\"list-group-item d-flex justify-content-between align-items-start\">\n                            <div class=\"ms-2 me-auto\">\n                                <div class=\"fw-bold\">Submit your IELTS Writing or Speaking task</div>\n                                Upload your writing response or complete a speaking assessment using our AI-powered platform\n                            </div>\n                            <span class=\"badge bg-primary rounded-pill\">1</span>\n                        </li>\n                        <li class=\"list-group-item d-flex justify-content-between align-items-start\">\n                            <div class=\"ms-2 me-auto\">\n                                <div class=\"fw-bold\">GenAI evaluates it using official IELTS scoring criteria</div>\n                                Our TrueScore® and ClearScore® technologies analyze your response against official band descriptors\n                            </div>\n                            <span class=\"badge bg-primary rounded-pill\">2</span>\n                        </li>\n                        <li class=\"list-group-item d-flex justify-content-between align-items-start\">\n                            <div class=\"ms-2 me-auto\">\n                                <div class=\"fw-bold\">You receive your band score and personalized feedback within minutes</div>\n                                Get instant results with detailed feedback on all assessment criteria and improvement recommendations\n                            </div>\n                            <span class=\"badge bg-primary rounded-pill\">3</span>\n                        </li>\n                    </ol>\n                </div>\n            </div>\n            \n            <div class=\"row mt-5\">\n                <div class=\"col-12 text-center\">\n                    <h3 class=\"mb-4\">How to Get Started</h3>\n                    <div class=\"row\">\n                        <div class=\"col-md-4 mb-4 text-center\">\n                            <div class=\"mb-3\">\n                                <i class=\"fas fa-mobile-alt fa-3x text-primary\"></i>\n                            </div>\n                            <h4>Step 1: Download the IELTS GenAI Prep app</h4>\n                            <p>Download the IELTS GenAI Prep app from the App Store or Google Play</p>\n                        </div>\n                        <div class=\"col-md-4 mb-4 text-center\">\n                            <div class=\"mb-3\">\n                                <i class=\"fas fa-credit-card fa-3x text-warning\"></i>\n                            </div>\n                            <h4>Step 2: Create your account and purchase a package</h4>\n                            <p>Create your account and purchase assessment packages for $36.49 USD each</p>\n                        </div>\n                        <div class=\"col-md-4 mb-4 text-center\">\n                            <div class=\"mb-3\">\n                                <i class=\"fas fa-laptop fa-3x text-success\"></i>\n                            </div>\n                            <h4>Step 3: Log in on the mobile app or desktop site</h4>\n                            <p>Log in on the mobile app or desktop site with your account – your progress syncs automatically</p>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </section>\n\n    <!-- FAQ Section (AI Optimized) -->\n    <section class=\"py-5 bg-light\" id=\"faq\">\n        <div class=\"container\">\n            <h2 class=\"text-center mb-5\">Frequently Asked Questions</h2>\n            <div class=\"row\">\n                <div class=\"col-lg-10 mx-auto\">\n                    <div class=\"accordion\" id=\"faqAccordion\">\n                        <div class=\"accordion-item\">\n                            <h2 class=\"accordion-header\" id=\"faq1\">\n                                <button class=\"accordion-button\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse1\" aria-expanded=\"true\" aria-controls=\"collapse1\">\n                                    <h3 class=\"mb-0\">What is IELTS GenAI Prep?</h3>\n                                </button>\n                            </h2>\n                            <div id=\"collapse1\" class=\"accordion-collapse collapse show\" aria-labelledby=\"faq1\" data-bs-parent=\"#faqAccordion\">\n                                <div class=\"accordion-body\">\n                                    <p>IELTS GenAI Prep is an AI-powered assessment platform that delivers standardized, examiner-aligned band scores for IELTS Writing and Speaking, using official IELTS scoring criteria.</p>\n                                </div>\n                            </div>\n                        </div>\n                        \n                        <div class=\"accordion-item\">\n                            <h2 class=\"accordion-header\" id=\"faq2\">\n                                <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse2\" aria-expanded=\"false\" aria-controls=\"collapse2\">\n                                    <h3 class=\"mb-0\">What makes IELTS GenAI Prep different from other IELTS prep tools?</h3>\n                                </button>\n                            </h2>\n                            <div id=\"collapse2\" class=\"accordion-collapse collapse\" aria-labelledby=\"faq2\" data-bs-parent=\"#faqAccordion\">\n                                <div class=\"accordion-body\">\n                                    <p>It is the only platform using TrueScore® and ClearScore® technologies to provide instant, AI-generated feedback that mirrors official IELTS band descriptors for both Academic and General Training modules.</p>\n                                </div>\n                            </div>\n                        </div>\n                        \n                        <div class=\"accordion-item\">\n                            <h2 class=\"accordion-header\" id=\"faq3\">\n                                <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse3\" aria-expanded=\"false\" aria-controls=\"collapse3\">\n                                    <h3 class=\"mb-0\">How does TrueScore® assess IELTS Writing tasks?</h3>\n                                </button>\n                            </h2>\n                            <div id=\"collapse3\" class=\"accordion-collapse collapse\" aria-labelledby=\"faq3\" data-bs-parent=\"#faqAccordion\">\n                                <div class=\"accordion-body\">\n                                    <p>TrueScore® uses GenAI models trained on IELTS scoring rubrics to assess Task Achievement, Coherence & Cohesion, Lexical Resource, and Grammatical Range & Accuracy. Each submission receives band-aligned feedback.</p>\n                                </div>\n                            </div>\n                        </div>\n                        \n                        <div class=\"accordion-item\">\n                            <h2 class=\"accordion-header\" id=\"faq4\">\n                                <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse4\" aria-expanded=\"false\" aria-controls=\"collapse4\">\n                                    <h3 class=\"mb-0\">How is ClearScore® used to evaluate IELTS Speaking?</h3>\n                                </button>\n                            </h2>\n                            <div id=\"collapse4\" class=\"accordion-collapse collapse\" aria-labelledby=\"faq4\" data-bs-parent=\"#faqAccordion\">\n                                <div class=\"accordion-body\">\n                                    <p>ClearScore® simulates a live speaking test using AI voice assessment technology. It scores fluency, pronunciation, grammar, and vocabulary in real-time, based on official IELTS speaking criteria.</p>\n                                </div>\n                            </div>\n                        </div>\n                        \n                        <div class=\"accordion-item\">\n                            <h2 class=\"accordion-header\" id=\"faq5\">\n                                <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse5\" aria-expanded=\"false\" aria-controls=\"collapse5\">\n                                    <h3 class=\"mb-0\">Do you offer Academic and General Training modules?</h3>\n                                </button>\n                            </h2>\n                            <div id=\"collapse5\" class=\"accordion-collapse collapse\" aria-labelledby=\"faq5\" data-bs-parent=\"#faqAccordion\">\n                                <div class=\"accordion-body\">\n                                    <p>Yes. IELTS GenAI Prep supports both Academic and General Training formats for Writing and Speaking, allowing users to choose modules aligned with their test goals.</p>\n                                </div>\n                            </div>\n                        </div>\n                        \n                        <div class=\"accordion-item\">\n                            <h2 class=\"accordion-header\" id=\"faq6\">\n                                <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse6\" aria-expanded=\"false\" aria-controls=\"collapse6\">\n                                    <h3 class=\"mb-0\">How much does it cost to use IELTS GenAI Prep?</h3>\n                                </button>\n                            </h2>\n                            <div id=\"collapse6\" class=\"accordion-collapse collapse\" aria-labelledby=\"faq6\" data-bs-parent=\"#faqAccordion\">\n                                <div class=\"accordion-body\">\n                                    <p>Each module (Writing or Speaking) is priced at $36.49 USD for four AI-graded assessments. This includes band scores and detailed feedback on every attempt.</p>\n                                </div>\n                            </div>\n                        </div>\n                        \n                        <div class=\"accordion-item\">\n                            <h2 class=\"accordion-header\" id=\"faq7\">\n                                <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse7\" aria-expanded=\"false\" aria-controls=\"collapse7\">\n                                    <h3 class=\"mb-0\">Is this a mobile-only platform?</h3>\n                                </button>\n                            </h2>\n                            <div id=\"collapse7\" class=\"accordion-collapse collapse\" aria-labelledby=\"faq7\" data-bs-parent=\"#faqAccordion\">\n                                <div class=\"accordion-body\">\n                                    <p>IELTS GenAI Prep is optimized for mobile and desktop. Users can create an account on the website and access assessments on the IELTS GenAI mobile app anytime, anywhere.</p>\n                                </div>\n                            </div>\n                        </div>\n                        \n                        <div class=\"accordion-item\">\n                            <h2 class=\"accordion-header\" id=\"faq8\">\n                                <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse8\" aria-expanded=\"false\" aria-controls=\"collapse8\">\n                                    <h3 class=\"mb-0\">How fast is the scoring process?</h3>\n                                </button>\n                            </h2>\n                            <div id=\"collapse8\" class=\"accordion-collapse collapse\" aria-labelledby=\"faq8\" data-bs-parent=\"#faqAccordion\">\n                                <div class=\"accordion-body\">\n                                    <p>All AI assessments are completed within seconds to a few minutes, providing instant band scores and feedback so users can improve quickly and effectively.</p>\n                                </div>\n                            </div>\n                        </div>\n                        \n                        <div class=\"accordion-item\">\n                            <h2 class=\"accordion-header\" id=\"faq9\">\n                                <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse9\" aria-expanded=\"false\" aria-controls=\"collapse9\">\n                                    <h3 class=\"mb-0\">How reliable are the AI-generated IELTS scores?</h3>\n                                </button>\n                            </h2>\n                            <div id=\"collapse9\" class=\"accordion-collapse collapse\" aria-labelledby=\"faq9\" data-bs-parent=\"#faqAccordion\">\n                                <div class=\"accordion-body\">\n                                    <p>Our GenAI scores show a 96% alignment with certified IELTS examiners. The technology is built to mimic human scoring standards while ensuring consistency and speed.</p>\n                                </div>\n                            </div>\n                        </div>\n                        \n                        <div class=\"accordion-item\">\n                            <h2 class=\"accordion-header\" id=\"faq10\">\n                                <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapse10\" aria-expanded=\"false\" aria-controls=\"collapse10\">\n                                    <h3 class=\"mb-0\">Can I track my performance over time?</h3>\n                                </button>\n                            </h2>\n                            <div id=\"collapse10\" class=\"accordion-collapse collapse\" aria-labelledby=\"faq10\" data-bs-parent=\"#faqAccordion\">\n                                <div class=\"accordion-body\">\n                                    <p>Yes. Your personalized dashboard allows you to review past assessments, track band score improvements, and identify focus areas for continued practice.</p>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </section>\n\n    <!-- Footer -->\n    <footer class=\"bg-dark text-light py-4\">\n        <div class=\"container\">\n            <div class=\"row\">\n                <div class=\"col-md-6\">\n                    <h5>IELTS GenAI Prep</h5>\n                    <p>The world's only standardized IELTS GenAI assessment platform</p>\n                </div>\n                <div class=\"col-md-6\">\n                    <div class=\"d-flex flex-column flex-md-row justify-content-md-end\">\n                        <div class=\"mb-2\">\n                            <a href=\"/privacy-policy\" class=\"text-light me-3\">Privacy Policy</a>\n                            <a href=\"/terms-of-service\" class=\"text-light\">Terms of Service</a>\n                        </div>\n                    </div>\n                    <div class=\"text-md-end\">\n                        <p>&copy; 2025 IELTS GenAI Prep. All rights reserved.</p>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </footer>\n\n    <!-- Bootstrap JS -->\n    <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js\"></script>\n</body>\n</html>"
    
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html; charset=utf-8'},
        'body': template
    }

def serve_login_page():
    """Serve professional login page with navigation"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html; charset=utf-8'},
        'body': """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        body { font-family: 'Roboto', sans-serif; background: #f8f9fa; }
        .site-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1rem 0;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .site-logo {
            color: white;
            text-decoration: none;
            font-size: 1.8rem;
            font-weight: 700;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
        }
        .site-logo:hover { color: #f8f9fa; }
        .main-nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
            align-items: center;
        }
        .main-nav li { margin-left: 1.5rem; }
        .main-nav a {
            color: white;
            text-decoration: none;
            padding: 0.75rem 1.25rem;
            border-radius: 6px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        .main-nav a:hover {
            background-color: rgba(255,255,255,0.15);
            transform: translateY(-1px);
        }
        .login-container { min-height: 85vh; }
        .card { 
            border: none; 
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            border-radius: 12px;
        }
        .card-header { 
            border-bottom: none; 
            border-radius: 12px 12px 0 0 !important;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .btn-primary { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            border-radius: 8px;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
            transform: translateY(-2px);
        }
        .form-control { 
            padding: 0.875rem 1rem; 
            border: 2px solid #e9ecef;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .alert { 
            border: none; 
            border-left: 4px solid #17a2b8;
            border-radius: 8px;
        }
        @media (max-width: 768px) {
            .main-nav { display: none; }
            .site-logo { font-size: 1.5rem; }
        }
    </style>
</head>
<body>
    <!-- Header with Navigation -->
    <header class="site-header">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <a href="/" class="site-logo">
                    <i class="fas fa-graduation-cap me-2"></i>IELTS GenAI Prep
                </a>
                <nav class="main-nav">
                    <ul>
                        <li><a href="/"><i class="fas fa-home me-1"></i> Home</a></li>
                        <li><a href="/login" class="active"><i class="fas fa-sign-in-alt me-1"></i> Login</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <!-- Login Form -->
    <div class="container login-container d-flex align-items-center justify-content-center">
        <div class="row w-100 justify-content-center">
            <div class="col-md-6 col-lg-5 col-xl-4">
                <div class="card shadow-lg">
                    <div class="card-header text-white text-center py-4">
                        <h2 class="mb-0 fw-bold">Welcome Back</h2>
                        <p class="mb-0 mt-2 opacity-75">Sign in to your IELTS GenAI account</p>
                    </div>
                    <div class="card-body p-5">
                        <div class="alert alert-info mb-4">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-mobile-alt fa-2x text-info me-3"></i>
                                <div>
                                    <strong>New Users:</strong><br>
                                    <small>Download our mobile app first to create your account and purchase assessment packages.</small>
                                </div>
                            </div>
                        </div>
                        
                        <form method="POST" action="/login">
                            <div class="mb-4">
                                <label for="email" class="form-label fw-semibold text-dark">Email Address</label>
                                <input type="email" class="form-control form-control-lg" id="email" name="email" placeholder="Enter your email address" required>
                            </div>
                            <div class="mb-4">
                                <label for="password" class="form-label fw-semibold text-dark">Password</label>
                                <input type="password" class="form-control form-control-lg" id="password" name="password" placeholder="Enter your password" required>
                            </div>
                            <div class="mb-4 d-flex justify-content-center">
                                <div class="g-recaptcha" data-sitekey="6LdD2VUrAAAAABG_Tt5fFYmWkRB4YFVHPdjggYzQ"></div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-lg w-100 mb-3">
                                <i class="fas fa-sign-in-alt me-2"></i>Sign In
                            </button>
                        </form>
                        
                        <div class="text-center">
                            <small class="text-muted">
                                New to IELTS GenAI Prep? <a href="/register" class="text-decoration-none fw-semibold">Create account</a>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>"""
    }

def serve_register_page():
    """Serve registration guidance page"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html; charset=utf-8'},
        'body': """<!DOCTYPE html>
<html><head><title>Create Account - IELTS GenAI Prep</title>
<meta http-equiv="refresh" content="5;url=/">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet">
<style>
.gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
</style>
</head><body class="bg-light">
<div class="container py-5">
<div class="row justify-content-center">
<div class="col-md-8 col-lg-6">
<div class="card shadow-lg border-0">
<div class="card-header gradient-bg text-white text-center py-4">
<h3 class="mb-0"><i class="fas fa-mobile-alt me-2"></i>Account Creation</h3>
</div>
<div class="card-body text-center p-5">
<div class="alert alert-primary border-0 mb-4">
<h4><i class="fas fa-download me-2"></i>Download Our Mobile App First</h4>
<p class="mb-3">To create your IELTS GenAI Prep account and purchase assessment packages, please download our mobile app from the App Store or Google Play.</p>
<p><strong>After mobile registration:</strong> Use the same login credentials here on the website.</p>
</div>
<div class="mb-4">
<p class="text-muted">Redirecting to home page in 5 seconds...</p>
<div class="progress" style="height: 4px;">
<div class="progress-bar bg-primary" style="width: 0%; animation: progress 5s linear forwards;"></div>
</div>
</div>
<a href="/" class="btn btn-primary btn-lg px-4">
<i class="fas fa-home me-2"></i>Return to Home Page
</a>
</div>
</div>
</div>
</div>
</div>
<style>
@keyframes progress {
from { width: 0%; }
to { width: 100%; }
}
</style>
</body></html>"""
    }

def handle_login(event):
    """Handle login POST request"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps({'status': 'success', 'message': 'Authentication endpoint ready'})
    }

def serve_privacy_policy():
    """Serve privacy policy page"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html; charset=utf-8'},
        'body': """<!DOCTYPE html>
<html lang="en">
<head>
    <title>Privacy Policy - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h1 class="mb-0"><i class="fas fa-shield-alt me-2"></i>Privacy Policy</h1>
        </div>
        <div class="card-body p-4">
            <p><strong>Data Usage:</strong> We collect and use your data solely for providing IELTS assessment services and improving your learning experience.</p>
            <p><strong>Voice Recordings:</strong> Voice recordings are processed for assessment purposes but are not permanently stored. Only assessment feedback is retained.</p>
            <p><strong>Assessment Data:</strong> Your assessment results, feedback, and progress data are stored securely for progress tracking and improvement.</p>
            <p><strong>Data Security:</strong> All data is encrypted and stored securely following industry standards.</p>
            <div class="mt-4">
                <a href="/" class="btn btn-primary"><i class="fas fa-arrow-left me-2"></i>Back to Home</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>"""
    }

def serve_terms_of_service():
    """Serve terms of service page"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html; charset=utf-8'},
        'body': """<!DOCTYPE html>
<html lang="en">
<head>
    <title>Terms of Service - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h1 class="mb-0"><i class="fas fa-file-contract me-2"></i>Terms of Service</h1>
        </div>
        <div class="card-body p-4">
            <p><strong>Assessment Pricing:</strong> Each assessment package costs $36.49 USD and includes 4 AI-graded assessments with detailed feedback.</p>
            <p><strong>Purchase Policy:</strong> All purchases are final and non-refundable.</p>
            <p><strong>AI Assessment Policy:</strong> Our AI systems are designed specifically for educational assessment purposes and follow official IELTS criteria.</p>
            <p><strong>Service Availability:</strong> We strive to maintain 99.9% uptime but cannot guarantee uninterrupted service.</p>
            <div class="mt-4">
                <a href="/" class="btn btn-primary"><i class="fas fa-arrow-left me-2"></i>Back to Home</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>"""
    }

def serve_robots_txt():
    """Serve AI-optimized robots.txt"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/plain'},
        'body': """User-agent: *
Allow: /

User-agent: GPTBot
Allow: /

User-agent: ClaudeBot  
Allow: /

User-agent: Google-Extended
Allow: /

Sitemap: https://www.ieltsaiprep.com/sitemap.xml"""
    }

def serve_assessment_page(path):
    """Serve assessment page placeholder"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html; charset=utf-8'},
        'body': """<div class="container py-5 text-center">
<h1>IELTS Assessment</h1>
<p>Please login to access your purchased assessments.</p>
<a href="/login" class="btn btn-primary">Login Required</a>
</div>"""
    }

def serve_dashboard():
    """Serve user dashboard"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html; charset=utf-8'},
        'body': """<div class="container py-5">
<h1>User Dashboard</h1>
<p>Assessment dashboard coming soon.</p>
<a href="/" class="btn btn-primary">Back to Home</a>
</div>"""
    }

def get_404_page():
    """Return 404 error page"""
    return """<div class="container py-5 text-center">
<h1>404 - Page Not Found</h1>
<p>The requested page could not be found.</p>
<a href="/" class="btn btn-primary">Return Home</a>
</div>"""

def get_500_page():
    """Return 500 error page"""
    return """<div class="container py-5 text-center">
<h1>500 - Internal Server Error</h1>
<p>An internal server error occurred.</p>
<a href="/" class="btn btn-primary">Return Home</a>
</div>"""
