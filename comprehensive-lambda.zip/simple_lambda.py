import json

def lambda_handler(event, context):
    """Lambda handler with comprehensive home page"""
    
    path = event.get('path', '/')
    method = event.get('httpMethod', 'GET')
    
    print(f"Processing {method} {path}")
    
    # Comprehensive home page HTML content
    home_html = """<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"description\" content=\"IELTS GenAI Prep - Your comprehensive IELTS assessment preparation platform\">
    <title>IELTS GenAI Prep</title>
    
    <!-- Bootstrap CSS -->
    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
    
    <!-- Font Awesome for icons -->
    <link href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css\" rel=\"stylesheet\">
    
    <!-- Google Fonts -->
    <link href=\"https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap\" rel=\"stylesheet\">
    
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            line-height: 1.6;
        }
        
        .pricing-card {
            border: 1px solid rgba(0, 0, 0, 0.125);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }
        
        .pricing-card:hover {
            transform: translateY(-5px);
        }
        
        .genai-brand-section {
            margin-bottom: 60px;
        }
        
        .brand-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }
        
        .brand-title {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        
        .brand-tagline {
            color: #666;
            margin-bottom: 2rem;
            font-size: 1.1rem;
        }
        
        .hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 80px 0;
        }
        
        .features {
            padding: 80px 0;
            background: #f8f9fa;
        }
        
        .assessment-sections {
            padding: 80px 0;
            background: #f8f9fa;
        }
        
        .testimonials {
            padding: 80px 0;
        }
        
        .testimonial-card {
            height: 100%;
            border: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .testimonial-rating {
            text-align: center;
        }
        
        .testimonial-text {
            font-style: italic;
            margin-bottom: 20px;
        }
        
        .testimonial-author {
            text-align: center;
            border-top: 1px solid #eee;
            padding-top: 15px;
        }
        
        .testimonial-name {
            font-weight: bold;
            color: #333;
        }
        
        .testimonial-location {
            color: #666;
            font-size: 0.9rem;
        }
        
        .testimonial-score {
            color: #28a745;
            font-weight: bold;
            font-size: 0.9rem;
        }
        
        .equal-height-cards {
            display: flex;
            flex-wrap: wrap;
        }
        
        .equal-height-cards > [class*=\"col-\"] {
            display: flex;
        }
        
        .equal-height-cards .card {
            flex: 1;
        }
        
        .navbar {
            background-color: #fff !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-brand {
            font-weight: bold;
            color: #4361ee !important;
        }
        
        .navbar-nav .nav-link {
            color: #333 !important;
            font-weight: 500;
        }
        
        .navbar-nav .nav-link:hover {
            color: #4361ee !important;
        }
        
        /* Fix for mobile hero section spacing */
        @media (max-width: 768px) {
            .hero {
                padding: 60px 0;
            }
            
            .display-4 {
                font-size: 2rem;
            }
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <nav class=\"navbar navbar-expand-lg navbar-light bg-light fixed-top\">
        <div class=\"container\">
            <a class=\"navbar-brand\" href=\"/\">IELTS GenAI Prep</a>
            <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarNav\">
                <span class=\"navbar-toggler-icon\"></span>
            </button>
            <div class=\"collapse navbar-collapse\" id=\"navbarNav\">
                <ul class=\"navbar-nav ms-auto\">
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"#features\">Features</a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"#assessments\">Assessments</a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"/login\">Login</a>
                    </li>
                    <li class=\"nav-item dropdown\">
                        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdown\" role=\"button\" data-bs-toggle=\"dropdown\">
                            Legal
                        </a>
                        <ul class=\"dropdown-menu\">
                            <li><a class=\"dropdown-item\" href=\"/privacy-policy\">Privacy Policy</a></li>
                            <li><a class=\"dropdown-item\" href=\"/terms-of-service\">Terms of Service</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class=\"hero\" style=\"margin-top: 76px;\">
        <div class=\"container\">
            <div class=\"text-center mb-4\">
                <h1 class=\"display-4 fw-bold mb-3\">Master IELTS with the World's ONLY GenAI Assessment Platform</h1>
                <div class=\"p-2 mb-4\" style=\"background-color: #3498db; color: white; border-radius: 4px; display: inline-block; width: 100%; max-width: 100%; white-space: normal; word-wrap: break-word; word-break: break-word; overflow-wrap: break-word; text-align: center; padding: 8px; font-size: 1rem; line-height: 1.4;\">
                    Powered by TrueScore® & ClearScore® - Industry-Leading Standardized Assessment Technology
                </div>
            </div>
            
            <div class=\"row mb-4\">
                <div class=\"col-lg-10 mx-auto\">
                    <p class=\"lead\">IELTS GenAI Prep delivers precise, examiner-aligned feedback through our exclusive TrueScore® writing analysis and ClearScore® speaking assessment systems. Our proprietary technology applies the official IELTS marking criteria to provide consistent, accurate band scores and actionable feedback for both Academic and General Training.</p>
                </div>
            </div>

            <div class=\"text-center mb-5\">
                <div class=\"d-md-flex d-block justify-content-center gap-3\">
                    <div class=\"d-flex align-items-center justify-content-center mb-2 mb-md-0\">
                        <i class=\"fas fa-check-circle text-light me-2\"></i>
                        <span>Standardized Assessment</span>
                    </div>
                    <div class=\"d-flex align-items-center justify-content-center mb-2 mb-md-0\">
                        <i class=\"fas fa-check-circle text-light me-2\"></i>
                        <span>IELTS Criteria Aligned</span>
                    </div>
                    <div class=\"d-flex align-items-center justify-content-center\">
                        <i class=\"fas fa-check-circle text-light me-2\"></i>
                        <span>Personalized Feedback</span>
                    </div>
                </div>
            </div>

            <div class=\"hero-buttons text-center\">
                <a href=\"/qr-auth\" class=\"btn btn-primary btn-lg me-2\">Access Portal</a>
                <a href=\"#assessments\" class=\"btn btn-light btn-lg\">View Assessments</a>
            </div>
        </div>
    </section>

    <!-- GenAI Technology Overview Section -->
    <section class=\"assessment-sections py-5\" id=\"features\">
        <div class=\"container\">
            <div class=\"text-center mb-5\">
                <h2 class=\"mb-3\">The World's ONLY Standardized IELTS GenAI Assessment System</h2>
                <p class=\"text-muted\">Our proprietary technologies deliver consistent, examiner-aligned evaluations</p>
            </div>
            
            <div class=\"row\">
                <div class=\"col-md-6 mb-4\">
                    <div class=\"card h-100 border-success\">
                        <div class=\"card-header bg-success text-white text-center py-3\">
                            <h3 class=\"m-0\">TrueScore® Writing Assessment</h3>
                        </div>
                        <div class=\"card-body text-center\">
                            <i class=\"fas fa-pencil-alt fa-3x text-success mb-3\"></i>
                            <div class=\"badge bg-light text-dark mb-3\">EXCLUSIVE TECHNOLOGY</div>
                            <p>Our proprietary TrueScore® system is the only GenAI technology that standardizes writing assessment within the official IELTS marking criteria rubric. Receive detailed feedback on Task Achievement, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy for both Academic and General Training tasks.</p>
                        </div>
                    </div>
                </div>
                
                <div class=\"col-md-6 mb-4\">
                    <div class=\"card h-100 border-primary\">
                        <div class=\"card-header bg-primary text-white text-center py-3\">
                            <h3 class=\"m-0\">ClearScore® Speaking Assessment</h3>
                        </div>
                        <div class=\"card-body text-center\">
                            <i class=\"fas fa-microphone-alt fa-3x text-primary mb-3\"></i>
                            <div class=\"badge bg-light text-dark mb-3\">EXCLUSIVE TECHNOLOGY</div>
                            <p>ClearScore® is the world's first GenAI system to precisely assess IELTS speaking performance across all official criteria. Its sophisticated speech analysis delivers comprehensive feedback on Fluency and Coherence, Lexical Resource, Grammatical Range and Accuracy, and Pronunciation for all three speaking assessment sections.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class=\"features\" id=\"about\">
        <div class=\"container\">
            <h2 class=\"text-center mb-5\">Why Choose IELTS GenAI Prep for Your Assessment Preparation?</h2>
            
            <div class=\"row\">
                <div class=\"col-md-4 mb-4\">
                    <div class=\"card h-100 p-3 text-center\">
                        <i class=\"fas fa-clipboard-check fa-4x text-primary mb-3\"></i>
                        <h3 class=\"h4\">Comprehensive IELTS Assessment Preparation</h3>
                        <p>Master the IELTS Writing and Speaking modules with the world's only GenAI-driven assessments aligned with the official IELTS band descriptors for accurate feedback for both IELTS Academic and General Training. Boost your skills and achieve your target score with confidence.</p>
                    </div>
                </div>
                
                <div class=\"col-md-4 mb-4\">
                    <div class=\"card h-100 p-3 text-center\">
                        <i class=\"fas fa-user-graduate fa-4x text-success mb-3\"></i>
                        <h3 class=\"h4\">Your Personal GenAI IELTS Coach</h3>
                        <p>Get detailed feedback aligned with the official IELTS assessment criteria on both speaking and writing tasks with TrueScore® and ClearScore®.</p>
                    </div>
                </div>
                
                <div class=\"col-md-4 mb-4\">
                    <div class=\"card h-100 p-3 text-center\">
                        <i class=\"fas fa-globe fa-4x text-info mb-3\"></i>
                        <h3 class=\"h4\">Global Assessment Preparation: At Your Own Pace, from Anywhere</h3>
                        <p>Whether you're a student striving for academic success or an individual chasing new horizons through study or career opportunities abroad, our inclusive platform empowers your goals, delivering world-class assessment preparation tailored to your journey, wherever you are.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Product Plans Section -->
    <section class=\"pricing py-5 bg-light\" id=\"assessments\">
        <div class=\"container\">
            <h2 class=\"text-center mb-4\">GenAI Assessed IELTS Modules</h2>
            <p class=\"text-center mb-5\">Our specialized GenAI technologies provide accurate assessment for IELTS preparation</p>
            
            <!-- TrueScore® Section -->
            <div class=\"genai-brand-section mb-5\">
                <div class=\"text-center mb-4\">
                    <div class=\"brand-icon text-success\">
                        <i class=\"fas fa-pencil-alt\"></i>
                    </div>
                    <h3 class=\"brand-title\">TrueScore® Writing Assessment</h3>
                    <p class=\"brand-tagline\">Professional GenAI assessment of IELTS writing tasks aligned with the official IELTS band descriptors on Task Achievement, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy</p>
                </div>
                
                <div class=\"row\">
                    <!-- Academic Writing Assessment -->
                    <div class=\"col-lg-6 mb-4\">
                        <div class=\"card pricing-card\">
                            <div class=\"card-header bg-success text-white text-center\">
                                <h3 class=\"my-0 font-weight-bold\">Academic Writing</h3>
                            </div>
                            <div class=\"card-body\">
                                <h1 class=\"card-title pricing-card-title text-center\">$36<small class=\"text-muted\"> for 4 assessments</small></h1>
                                <ul class=\"list-unstyled mt-3 mb-4\">
                                    <li><i class=\"fas fa-check text-success me-2\"></i>4 Unique Assessments Included</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Task 1 & Task 2 Assessment</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>TrueScore® GenAI Evaluation</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Official IELTS Criteria Alignment</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Detailed Band Score Feedback</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Writing Improvement Recommendations</li>
                                </ul>
                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-success w-100\">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>

                    <!-- General Writing Assessment -->
                    <div class=\"col-lg-6 mb-4\">
                        <div class=\"card pricing-card\">
                            <div class=\"card-header bg-success text-white text-center\">
                                <h3 class=\"my-0 font-weight-bold\">General Training Writing</h3>
                            </div>
                            <div class=\"card-body\">
                                <h1 class=\"card-title pricing-card-title text-center\">$36<small class=\"text-muted\"> for 4 assessments</small></h1>
                                <ul class=\"list-unstyled mt-3 mb-4\">
                                    <li><i class=\"fas fa-check text-success me-2\"></i>4 Unique Assessments Included</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Letter & Essay Assessment</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>TrueScore® GenAI Evaluation</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Official IELTS Criteria Alignment</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Comprehensive Feedback System</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Target Band Achievement Support</li>
                                </ul>
                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-success w-100\">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ClearScore® Section -->
            <div class=\"genai-brand-section\">
                <div class=\"text-center mb-4\">
                    <div class=\"brand-icon text-primary\">
                        <i class=\"fas fa-microphone-alt\"></i>
                    </div>
                    <h3 class=\"brand-title\">ClearScore® Speaking Assessment</h3>
                    <p class=\"brand-tagline\">Revolutionary GenAI speaking assessment with real-time conversation analysis covering Fluency and Coherence, Lexical Resource, Grammatical Range and Accuracy, and Pronunciation</p>
                </div>
                
                <div class=\"row\">
                    <!-- Academic Speaking Assessment -->
                    <div class=\"col-lg-6 mb-4\">
                        <div class=\"card pricing-card\">
                            <div class=\"card-header bg-primary text-white text-center\">
                                <h3 class=\"my-0 font-weight-bold\">Academic Speaking</h3>
                            </div>
                            <div class=\"card-body\">
                                <h1 class=\"card-title pricing-card-title text-center\">$36<small class=\"text-muted\"> for 4 assessments</small></h1>
                                <ul class=\"list-unstyled mt-3 mb-4\">
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>4 Unique Assessments Included</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Interactive Maya AI Examiner</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>ClearScore® GenAI Analysis</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Real-time Speech Assessment</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>All Three Speaking Parts</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Pronunciation & Fluency Feedback</li>
                                </ul>
                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-primary w-100\">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>

                    <!-- General Speaking Assessment -->
                    <div class=\"col-lg-6 mb-4\">
                        <div class=\"card pricing-card\">
                            <div class=\"card-header bg-primary text-white text-center\">
                                <h3 class=\"my-0 font-weight-bold\">General Training Speaking</h3>
                            </div>
                            <div class=\"card-body\">
                                <h1 class=\"card-title pricing-card-title text-center\">$36<small class=\"text-muted\"> for 4 assessments</small></h1>
                                <ul class=\"list-unstyled mt-3 mb-4\">
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>4 Unique Assessments Included</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Maya AI Conversation Partner</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>ClearScore® GenAI Technology</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Comprehensive Speaking Analysis</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>General Training Topic Focus</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Instant Performance Feedback</li>
                                </ul>
                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-primary w-100\">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class=\"py-5\" id=\"how-it-works\">
        <div class=\"container\">
            <h2 class=\"text-center mb-5\">How to Access Your GenAI Assessments</h2>
            <div class=\"row\">
                <div class=\"col-md-4 mb-4 text-center\">
                    <div class=\"mb-3\">
                        <i class=\"fas fa-mobile-alt fa-3x text-primary\"></i>
                    </div>
                    <h4>1. Download Mobile App</h4>
                    <p>Get IELTS GenAI Prep from the App Store or Google Play Store</p>
                </div>
                <div class=\"col-md-4 mb-4 text-center\">
                    <div class=\"mb-3\">
                        <i class=\"fas fa-credit-card fa-3x text-warning\"></i>
                    </div>
                    <h4>2. Purchase & Register</h4>
                    <p>Create your account and purchase assessment packages for $36.00 each through secure app store billing</p>
                </div>
                <div class=\"col-md-4 mb-4 text-center\">
                    <div class=\"mb-3\">
                        <i class=\"fas fa-laptop fa-3x text-success\"></i>
                    </div>
                    <h4>3. Login Anywhere</h4>
                    <p>Use your mobile app credentials to login on this website for desktop access, or continue using the mobile app</p>
                </div>
            </div>
            
            <div class=\"row mt-4\">
                <div class=\"col-12 text-center\">
                    <div class=\"alert alert-success\">
                        <h5 class=\"mb-2\"><i class=\"fas fa-shield-alt me-2\"></i>Secure Cross-Platform Access</h5>
                        <p class=\"mb-0\">One account, multiple platforms. After purchasing in the mobile app, use the same login credentials to access assessments on desktop/laptop through this website.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class=\"bg-dark text-light py-4\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-6\">
                    <h5>IELTS GenAI Prep</h5>
                    <p>The world's only standardized IELTS GenAI assessment platform</p>
                </div>
                <div class=\"col-md-6\">
                    <div class=\"d-flex flex-column flex-md-row justify-content-md-end\">
                        <div class=\"mb-2\">
                            <a href=\"/privacy-policy\" class=\"text-light me-3\">Privacy Policy</a>
                            <a href=\"/terms-of-service\" class=\"text-light\">Terms of Service</a>
                        </div>
                    </div>
                    <div class=\"text-md-end\">
                        <p>&copy; 2024 IELTS GenAI Prep. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js\"></script>
</body>
</html>"""
    
    if path == '/' or path == '/index.html':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'text/html; charset=utf-8',
                'Cache-Control': 'no-cache'
            },
            'body': home_html
        }
    
    elif path == '/login':
        login_html = """<!DOCTYPE html>
<html>
<head>
    <title>Login - IELTS GenAI Prep</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h1 class="text-center mb-4">IELTS GenAI Prep Login</h1>
                <div class="alert alert-info">
                    <h5>Mobile-First Access Required</h5>
                    <p>To access assessments:</p>
                    <ol>
                        <li>Download our mobile app from App Store or Google Play</li>
                        <li>Create account and purchase assessment packages ($36 each)</li>
                        <li>Return here and login with your mobile app credentials</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</body>
</html>"""
        
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'text/html'},
            'body': login_html
        }
    
    elif path == '/qr-auth':
        qr_html = """<!DOCTYPE html>
<html>
<head>
    <title>Mobile App Access - IELTS GenAI Prep</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h1 class="text-center mb-4">Access IELTS GenAI Prep</h1>
                <div class="alert alert-primary">
                    <h5>Download Mobile App First</h5>
                    <p>To access our GenAI assessment platform:</p>
                    <ol>
                        <li><strong>Download</strong> IELTS GenAI Prep from App Store or Google Play</li>
                        <li><strong>Register</strong> and purchase assessment packages ($36.00 each)</li>
                        <li><strong>Login</strong> on this website using your mobile app credentials</li>
                    </ol>
                    <p class="mb-0">One account works on both mobile and web platforms!</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>"""
        
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'text/html'},
            'body': qr_html
        }
    
    elif path == '/privacy-policy':
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'text/html'},
            'body': '<!DOCTYPE html><html><head><title>Privacy Policy - IELTS GenAI Prep</title></head><body><div class="container mt-5"><h1>Privacy Policy</h1><p>IELTS GenAI Prep Privacy Policy - Coming Soon</p></div></body></html>'
        }
    
    elif path == '/terms-of-service':
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'text/html'},
            'body': '<!DOCTYPE html><html><head><title>Terms of Service - IELTS GenAI Prep</title></head><body><div class="container mt-5"><h1>Terms of Service</h1><p>IELTS GenAI Prep Terms of Service - Coming Soon</p></div></body></html>'
        }
    
    else:
        return {
            'statusCode': 302,
            'headers': {'Location': '/'},
            'body': ''
        }
