
import json
import os

def lambda_handler(event, context):
    """AWS Lambda entry point with security-enhanced robots.txt"""
    try:
        # Extract request information
        method = event.get('httpMethod', 'GET')
        path = event.get('path', '/')
        
        print(f"[CLOUDWATCH] Processing {method} {path}")
        
        # Handle robots.txt with security enhancements
        if path == '/robots.txt' and method == 'GET':
            robots_content = """# IELTS GenAI Prep - Security-Enhanced robots.txt
# Last Updated: July 21, 2025
# Based on visualcapitalist.com security best practices

User-agent: *
Disallow: /login
Disallow: /register
Disallow: /auth/
Disallow: /api/
Disallow: /dashboard
Disallow: /my-profile
Disallow: /*.log$
Disallow: /*.json$
Disallow: /*.zip$
Disallow: /*.env$
Disallow: /*.config$
Crawl-delay: 10

User-agent: GPTBot
Allow: /
Disallow: /assessment/
Disallow: /api/
Disallow: /login
Disallow: /register
Disallow: /auth/
Crawl-delay: 60

User-agent: ClaudeBot
Allow: /
Disallow: /assessment/
Disallow: /api/
Disallow: /login
Disallow: /register
Disallow: /auth/
Crawl-delay: 60

User-agent: Google-Extended
Allow: /
Disallow: /assessment/
Disallow: /api/
Crawl-delay: 30

User-agent: AhrefsBot
Disallow: /

User-agent: SemrushBot
Disallow: /

User-agent: MJ12bot
Disallow: /

User-agent: DotBot
Disallow: /

# Allow search engines for SEO
User-agent: Googlebot
Allow: /
Disallow: /api/
Disallow: /login
Disallow: /register
Disallow: /auth/
Crawl-delay: 2

User-agent: Bingbot
Allow: /
Disallow: /api/
Disallow: /login
Disallow: /register
Disallow: /auth/
Crawl-delay: 2"""
            
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'text/plain',
                    'Cache-Control': 'public, max-age=3600'
                },
                'body': robots_content
            }
        
        # Handle home page
        elif path == '/' and method == 'GET':
            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'text/html'},
                'body': '<h1>IELTS GenAI Prep</h1><p>Security-enhanced robots.txt deployed successfully.</p>'
            }
        
        # Handle health check
        elif path == '/api/health' and method == 'GET':
            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'status': 'healthy',
                    'security_update': 'July 21, 2025',
                    'robots_txt': 'security-enhanced'
                })
            }
        
        # Default 404
        else:
            return {
                'statusCode': 404,
                'headers': {'Content-Type': 'text/html'},
                'body': '<h1>404 - Page Not Found</h1>'
            }
            
    except Exception as e:
        print(f"[ERROR] Lambda execution failed: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': 'Internal server error', 'details': str(e)})
        }
