# IELTS GenAI Prep - Final Production Package

## Overview
This package contains all the production code and resources for the IELTS GenAI Prep platform deployed at https://www.ieltsaiprep.com

## Architecture
- **Backend**: AWS Lambda serverless function (lambda_function.py)
- **Frontend**: Progressive Web App with responsive design
- **Database**: DynamoDB Global Tables (mocked via aws_mock_config.py for development)
- **Authentication**: QR code mobile-to-web authentication
- **AI Services**: Amazon Nova Sonic (speaking) and Nova Micro (writing)

## Files Included

### Core Production Code
- `lambda_function.py` - Main AWS Lambda handler with all routes and templates
- `aws_mock_config.py` - Development environment AWS service mocking
- `replit.md` - Project architecture and user preferences documentation

### UI/Design Files
- `static/` - Static assets (CSS, JavaScript, images, audio files)
  - `css/` - Stylesheets (main styles, cookie consent, QR modal)
  - `js/` - JavaScript modules (main, speaking, mobile integration, offline support)
  - `images/` - UI icons, logos, and graphics
  - `audio/` - Sample audio files for assessments
- `templates/` - HTML templates for all pages
  - Complete page templates for assessments, admin, GDPR compliance
  - Error pages (404, 500)
  - User account management templates
  - Practice assessment templates

### Assessment Question Banks & Knowledge Base
- `Academic Writing Task 2 tests (essays).txt` - Academic writing prompts
- `General Training Writing Task 2 tests (essays).txt` - General training writing prompts
- `IELTS General Training Writing Task 1 letters.txt` - General training letters
- `General Reading Task 1 Multiple Cho.txt` - Reading comprehension questions
- `General Test Reading Task 2 True False Not Given.txt` - Reading assessment tasks
- `IELTS Reading Context File.txt` - Reading passages and contexts
- `IELTS Speaking Context File.xlsx` - Speaking assessment scenarios

### Database & API Documentation
- `DATABASE_SCHEMA.md` - Complete DynamoDB table schemas and relationships
- `API_INTEGRATION_GUIDE.md` - AWS Bedrock, DynamoDB, and mobile integration code
- `API_ENDPOINTS.md` - Complete API endpoint documentation

### Mobile App Configuration
- `android_play_store_config.json` - Complete Google Play Store submission configuration
- `capacitor.config.ts` - Mobile app Capacitor configuration
- `APP_STORE_SUBMISSION_GUIDE.md` - iOS/Android deployment guides
- `ANDROID_DEPLOYMENT_GUIDE.md` - Android-specific deployment instructions
- `BUILD_ANDROID_GUIDE.md` - Build process for Android app

### Production Deployment Packages
- `clean_lambda_with_deps.zip` - Clean Lambda deployment package with dependencies
- `ai_seo_gdpr_lambda.zip` - SEO-optimized GDPR-compliant Lambda package

## Complete System Components

### Knowledge Base & Question Banks
- **4,000+ Assessment Questions**: Academic and General Training modules
- **Reading Passages**: Comprehensive context files for reading assessments  
- **Speaking Scenarios**: Real IELTS speaking test situations and prompts
- **Writing Prompts**: Essays, letters, and task-specific content
- **Assessment Rubrics**: Official IELTS band descriptors integration

### Database Architecture  
- **7 DynamoDB Tables**: Users, sessions, assessments, questions, purchases, QR-auth, GDPR
- **Global Secondary Indexes**: Optimized queries for user data and assessment history
- **TTL Management**: Automatic cleanup of expired sessions and temporary data
- **Multi-Region**: Global tables across us-east-1, eu-west-1, ap-southeast-1

### API Integration
- **AWS Bedrock**: Nova Sonic (speaking) and Nova Micro (writing) AI models
- **Real-Time Processing**: WebSocket connections for live conversations
- **Purchase Validation**: iOS App Store and Google Play Store receipt verification
- **Email Services**: AWS SES for welcome emails and account management
- **Security**: CloudFront-based access control and reCAPTCHA v2

### Production Website (www.ieltsaiprep.com)
- Home page with SEO optimization and FAQ
- Privacy Policy (GDPR compliant)
- Terms of Service 
- Login/Registration system with reCAPTCHA v2
- Dashboard with assessment access
- Profile management with account deletion

### AI Assessment Engine
- **TrueScore® Writing Assessment**: AI evaluation using Nova Micro
- **ClearScore® Speaking Assessment**: AI conversation using Nova Sonic
- Real-time feedback based on official IELTS band descriptors
- Support for both Academic and General Training modules

### Pricing Structure
- $36 for 4 assessment attempts per module type
- Consumable purchase model via mobile app
- Cross-platform access (mobile app or web)

## Recent Updates (August 2025)
- Updated FAQ to emphasize official IELTS band descriptors alignment
- Removed contact information sections from Privacy Policy and Terms of Service
- Updated all pricing from $49.99 to $36 for consistency
- Enhanced robots.txt for AI bot SEO optimization
- Fixed production deployment issues and cache management

## Deployment
The main production function is deployed as:
- **AWS Lambda**: ielts-genai-prep-api (us-east-1)
- **CloudFront Distribution**: E1EPXAU67877FR
- **Domain**: www.ieltsaiprep.com

## Environment Variables Required
- RECAPTCHA_V2_SITE_KEY
- RECAPTCHA_V2_SECRET_KEY
- DYNAMODB_TABLE_PREFIX
- ENVIRONMENT=production

## Mobile App Integration
- Capacitor-based mobile apps for iOS/Android
- In-app purchase validation
- QR code authentication for web platform access
- Native features integration

## Security Features
- Google reCAPTCHA v2 integration
- PBKDF2-HMAC-SHA256 password hashing
- CloudFront-based access control
- GDPR compliance with data export/deletion
- Content safety measures for AI-generated content

For technical implementation details, see the individual files and replit.md documentation.