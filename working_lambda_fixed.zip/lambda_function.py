
import json
import os

# Set production environment
os.environ["REPLIT_ENVIRONMENT"] = "false"

def lambda_handler(event, context):
    """AWS Lambda entry point for IELTS GenAI Prep"""
    try:
        method = event.get("httpMethod", "GET")
        path = event.get("path", "/")
        
        print(f"[CLOUDWATCH] Lambda processing {method} {path}")
        
        if path == "/robots.txt" and method == "GET":
            return handle_robots_txt()
        elif path == "/" and method == "GET":
            return handle_home_page()
        elif path == "/login" and method == "GET":
            return handle_login_page()
        elif path == "/api/health" and method == "GET":
            return handle_health_check()
        else:
            return {
                "statusCode": 404,
                "headers": {"Content-Type": "text/html"},
                "body": "<h1>404 - Page Not Found</h1><p><a href="/">Return to Home</a></p>"
            }
            
    except Exception as e:
        print(f"[ERROR] Lambda execution failed: {str(e)}")
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "Internal server error", "details": str(e)})
        }

def handle_robots_txt():
    """Security-enhanced robots.txt"""
    robots_content = """# IELTS GenAI Prep - Security-Enhanced robots.txt
# Critical Security Update: July 21, 2025

User-agent: *
Allow: /
Disallow: /login
Disallow: /register  
Disallow: /auth/
Disallow: /api/
Disallow: /admin/
Disallow: /dashboard/
Disallow: /assessment/
Disallow: /my-profile
Disallow: /*.log$
Disallow: /*.json$
Disallow: /*.zip$
Disallow: /*.env$
Disallow: /*.config$
Crawl-delay: 10

User-agent: GPTBot
Allow: /
Allow: /privacy-policy
Allow: /terms-of-service
Allow: /robots.txt
Disallow: /assessment/
Disallow: /api/
Disallow: /login
Crawl-delay: 30

User-agent: ClaudeBot
Allow: /
Allow: /privacy-policy  
Allow: /terms-of-service
Allow: /robots.txt
Disallow: /assessment/
Disallow: /api/
Disallow: /login
Crawl-delay: 30

User-agent: AhrefsBot
Disallow: /
Crawl-delay: 60

User-agent: SemrushBot
Disallow: /
Crawl-delay: 60

Sitemap: https://www.ieltsaiprep.com/sitemap.xml"""
    
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "text/plain",
            "Cache-Control": "public, max-age=3600"
        },
        "body": robots_content
    }

def handle_home_page():
    """Comprehensive home page"""
    home_content = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IELTS GenAI Prep - AI-Powered IELTS Assessment Platform</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="text-center mb-5">
                    <h1 class="display-4 text-primary">Master IELTS with GenAI-Powered Scoring</h1>
                    <p class="lead">The only AI-based IELTS platform with official band-aligned feedback</p>
                    <div class="badge bg-success fs-6 mb-3">Website Fully Restored - July 21, 2025</div>
                </div>
                
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="card h-100 border-primary">
                            <div class="card-header bg-primary text-white">
                                <h5><i class="fas fa-pen-alt me-2"></i>TrueScore® Writing Assessment</h5>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-check text-success me-2"></i>Task Achievement Analysis</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Coherence & Cohesion Scoring</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Lexical Resource Evaluation</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Grammar Range & Accuracy</li>
                                </ul>
                                <div class="mt-3">
                                    <span class="badge bg-primary">6.49 USD for 4 assessments</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card h-100 border-info">
                            <div class="card-header bg-info text-white">
                                <h5><i class="fas fa-microphone me-2"></i>ClearScore® Speaking Assessment</h5>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-check text-info me-2"></i>Maya AI Examiner (Nova Sonic)</li>
                                    <li><i class="fas fa-check text-info me-2"></i>Real-time Speech Analysis</li>
                                    <li><i class="fas fa-check text-info me-2"></i>Fluency & Coherence Scoring</li>
                                    <li><i class="fas fa-check text-info me-2"></i>Pronunciation Assessment</li>
                                </ul>
                                <div class="mt-3">
                                    <span class="badge bg-info">6.49 USD for 4 assessments</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-5">
                    <a href="/login" class="btn btn-primary btn-lg me-3">
                        <i class="fas fa-sign-in-alt me-2"></i>Login to Website
                    </a>
                    <a href="/privacy-policy" class="btn btn-outline-secondary">Privacy Policy</a>
                    <a href="/terms-of-service" class="btn btn-outline-secondary">Terms of Service</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>"""
    
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "text/html"},
        "body": home_content
    }

def handle_login_page():
    """Professional login page"""
    login_content = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4><i class="fas fa-sign-in-alt me-2"></i>Welcome Back</h4>
                        <a href="/" class="btn btn-outline-light btn-sm float-end">
                            <i class="fas fa-home"></i> Home
                        </a>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <strong>New Users:</strong> Please download our mobile app first to register and purchase assessments.
                            <div class="mt-2">
                                <a href="#" class="btn btn-sm btn-primary me-2">App Store</a>
                                <a href="#" class="btn btn-sm btn-success">Google Play</a>
                            </div>
                        </div>
                        
                        <form>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Sign In</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>"""
    
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "text/html"},
        "body": login_content
    }

def handle_health_check():
    """Health check endpoint"""
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({
            "status": "healthy",
            "security_update": "July 21, 2025",
            "robots_txt": "security-enhanced",
            "website": "fully-functional"
        })
    }
