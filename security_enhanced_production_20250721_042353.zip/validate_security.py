
#!/usr/bin/env python3
"""
Production Security Validation Script
Validates that security enhancements are properly deployed
"""

import requests
import sys

def validate_production_security():
    """Validate security enhancements in production"""
    
    print("🔒 VALIDATING PRODUCTION SECURITY ENHANCEMENTS")
    print("=" * 50)
    
    try:
        # Test robots.txt security
        response = requests.get("https://www.ieltsaiprep.com/robots.txt", timeout=30)
        robots_content = response.text
        
        # Check authentication protection
        if "Disallow: /login" in robots_content:
            print("✅ Authentication protection: ACTIVE")
        else:
            print("❌ Authentication protection: MISSING")
            
        # Check API security
        if "Disallow: /api/" in robots_content:
            print("✅ API endpoint security: ACTIVE")
        else:
            print("❌ API endpoint security: MISSING")
            
        # Check rate limiting
        if "Crawl-delay: 10" in robots_content:
            print("✅ Enhanced rate limiting: ACTIVE")
        else:
            print("❌ Enhanced rate limiting: MISSING")
            
        # Check AI training protection
        if "Disallow: /assessment/" in robots_content and "GPTBot" in robots_content:
            print("✅ AI training protection: ACTIVE")
        else:
            print("❌ AI training protection: MISSING")
            
        # Check security timestamp
        if "July 21, 2025" in robots_content:
            print("✅ Security update timestamp: CURRENT")
        else:
            print("❌ Security update timestamp: OUTDATED")
            
        print("=" * 50)
        print("🔒 Security validation complete")
        
    except Exception as e:
        print(f"❌ Security validation failed: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    validate_production_security()
