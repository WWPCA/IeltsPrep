#!/usr/bin/env python3
"""
Comprehensive AWS Lambda Handler for IELTS GenAI Prep Production
All templates embedded with complete endpoint coverage
"""

import json
import os
import hashlib
import base64
import urllib.request
import urllib.parse
from datetime import datetime
import boto3
from botocore.exceptions import ClientError

# Environment detection
REPLIT_ENVIRONMENT = os.environ.get('REPLIT_ENVIRONMENT', 'false') == 'true'

def lambda_handler(event, context):
    """Main Lambda handler with comprehensive routing"""
    
    try:
        # CloudFront security validation
        headers = event.get('headers', {})
        cf_secret = headers.get('CF-Secret-3140348d') or headers.get('cf-secret-3140348d')
        
        if not REPLIT_ENVIRONMENT and not cf_secret:
            return {
                'statusCode': 403,
                'body': 'Forbidden',
                'headers': {'Content-Type': 'text/plain'}
            }
        
        # Extract request info
        method = event.get('httpMethod', 'GET')
        path = event.get('path', '/')
        query_params = event.get('queryStringParameters') or {}
        body = event.get('body', '')
        
        # Route handling
        if path == '/' and method == 'GET':
            return serve_home_page()
        elif path == '/login' and method == 'GET':
            return serve_login_page()
        elif path == '/login' and method == 'POST':
            return handle_login(body)
        elif path == '/privacy-policy' and method == 'GET':
            return serve_privacy_policy()
        elif path == '/terms-of-service' and method == 'GET':
            return serve_terms_of_service()
        elif path == '/robots.txt' and method == 'GET':
            return serve_robots_txt()
        elif path == '/api/health' and method == 'GET':
            return serve_health_check()
        elif path.startswith('/assessment/') and method == 'GET':
            return serve_assessment_page(path)
        elif path == '/dashboard' and method == 'GET':
            return serve_dashboard()
        elif path == '/my-profile' and method == 'GET':
            return serve_profile()
        else:
            return {
                'statusCode': 404,
                'body': 'Not Found',
                'headers': {'Content-Type': 'text/plain'}
            }
    
    except Exception as e:
        print(f"Lambda error: {e}")
        return {
            'statusCode': 500,
            'body': 'Internal Server Error',
            'headers': {'Content-Type': 'text/plain'}
        }

def serve_home_page():
    """Serve home page with comprehensive design"""
    template = """{% extends "layout.html" %}

{% block styles %}
<style>
.pricing-card {
    border: 1px solid rgba(0, 0, 0, 0.125);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s;
}
.pricing-card:hover {
    transform: translateY(-5px);
}
.genai-brand-section {
    margin-bottom: 60px;
}
.brand-icon {
    font-size: 2.5rem;
    margin-bottom: 15px;
}
.brand-title {
    font-size: 2rem;
    margin-bottom: 0.5rem;
}
.brand-tagline {
    color: #666;
    margin-bottom: 2rem;
    font-size: 1.1rem;
}
</style>
{% endblock %}

{% block content %}
<!-- Assessment Access Notice for Logged-in Users -->
{% if current_user.is_authenticated %}
<div class="container mt-4">
    <div class="alert alert-success mb-4">
        <div class="d-flex align-items-center">
            <div class="me-3">
                <i class="fas fa-check-circle fa-2x text-success"></i>
            </div>
            <div>
                <h4 class="alert-heading mb-2"><i class="fas fa-user-check me-2"></i>You have active assessment packages!</h4>
                <p class="mb-2">Access your purchased GenAI assessments from your <strong><a href="{{ url_for('profile') }}" class="alert-link">Profile Page</a></strong>.</p>
                <hr class="my-2">
                <p class="mb-0">
                    <a href="{{ url_for('profile') }}" class="btn btn-success btn-sm me-2">
                        <i class="fas fa-arrow-right me-1"></i>Go to My Assessments
                    </a>
                    <small class="text-muted">Start your TrueScore® and ClearScore® assessments now!</small>
                </p>
            </div>
        </div>
    </div>
</div>
{% endif %}

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="text-center mb-4">
            <h1 class="display-4 fw-bold mb-3">Master IELTS with the World's ONLY GenAI Assessment Platform</h1>
            <div class="p-2 mb-4" style="background-color: #3498db; color: white; border-radius: 4px; display: inline-block; width: 100%; max-width: 100%; white-space: normal; word-wrap: break-word; word-break: break-word; overflow-wrap: break-word; text-align: center; padding: 8px; font-size: 1rem; line-height: 1.4;">
                Powered by TrueScore® & ClearScore® - Industry-Leading Standardized Assessment Technology
            </div>
        </div>
        
        <div class="row mb-4">
            <div class="col-lg-10 mx-auto">
                <p class="lead">IELTS GenAI Prep delivers precise, examiner-aligned feedback through our exclusive TrueScore® writing analysis and ClearScore® speaking assessment systems. Our proprietary technology applies the official IELTS marking criteria to provide consistent, accurate band scores and actionable feedback for both Academic and General Training.</p>
            </div>
        </div>

        <div class="text-center mb-5">
            <div class="d-md-flex d-block justify-content-center gap-3">
                <div class="d-flex align-items-center justify-content-center mb-2 mb-md-0">
                    <i class="fas fa-check-circle text-success me-2"></i>
                    <span>Standardized Assessment</span>
                </div>
                <div class="d-flex align-items-center justify-content-center mb-2 mb-md-0">
                    <i class="fas fa-check-circle text-success me-2"></i>
                    <span>IELTS Criteria Aligned</span>
                </div>
                <div class="d-flex align-items-center justify-content-center">
                    <i class="fas fa-check-circle text-success me-2"></i>
                    <span>Personalized Feedback</span>
                </div>
            </div>
        </div>

        <div class="hero-buttons text-center">
            <a href="{{ url_for('register') }}" class="btn btn-primary btn-lg me-2">Start Your IELTS Preparation</a>
            <a href="{{ url_for('login') }}" class="btn btn-secondary btn-lg">Sign In</a>
        </div>
    </div>
</section>

<!-- GenAI Technology Overview Section - Enhanced with exclusivity messaging -->
<section class="assessment-sections py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="mb-3">The World's ONLY Standardized IELTS GenAI Assessment System</h2>
            <p class="text-muted">Our proprietary technologies deliver consistent, examiner-aligned evaluations</p>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="card h-100 border-success">
                    <div class="card-header bg-success text-white text-center py-3">
                        <h3 class="m-0">TrueScore® Writing Assessment</h3>
                    </div>
                    <div class="card-body text-center">
                        <i class="fas fa-pencil-alt fa-3x text-success mb-3"></i>
                        <div class="badge bg-light text-dark mb-3">EXCLUSIVE TECHNOLOGY</div>
                        <p>Our proprietary TrueScore® system is the only GenAI technology that standardizes writing assessment within the official IELTS marking criteria rubric. Receive detailed feedback on Task Achievement, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy for both Academic and General Training tasks.</p>

                    </div>
                </div>
            </div>
            
            <div class="col-md-6 mb-4">
                <div class="card h-100 border-primary">
                    <div class="card-header bg-primary text-white text-center py-3">
                        <h3 class="m-0">ClearScore® Speaking Assessment</h3>
                    </div>
                    <div class="card-body text-center">
                        <i class="fas fa-microphone-alt fa-3x text-primary mb-3" data-v="3"></i>
                        <div class="badge bg-light text-dark mb-3">EXCLUSIVE TECHNOLOGY</div>
                        <p>ClearScore® is the world's first GenAI system to precisely assess IELTS speaking performance across all official criteria. Its sophisticated speech analysis delivers comprehensive feedback on Fluency and Coherence, Lexical Resource, Grammatical Range and Accuracy, and Pronunciation for all three speaking assessment sections.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Ad Container - Removed -->

<!-- GenAI Technology Overview Section removed (duplicate content) -->

<!-- Features Section -->
<section class="features">
    <div class="container">
        <h2 class="text-center mb-5">Why Choose IELTS GenAI Prep for Your Assessment Preparation?</h2>
        
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card h-100 p-3 text-center">
                    <img src="{{ url_for('static', filename='images/checklist_icon.svg') }}?v={{ cache_buster }}" alt="Comprehensive IELTS Assessment Preparation" 
                        class="mx-auto d-block mb-3" width="80" height="80">
                    <h3 class="h4">Comprehensive IELTS Assessment Preparation</h3>
                    <p>Master the IELTS Writing and Speaking modules with the world's only GenAI-driven assessments aligned with the official IELTS band descriptors for accurate feedback for both IELTS Academic and General Training. Boost your skills and achieve your target score with confidence.</p>
                </div>
            </div>
            
            <div class="col-md-4 mb-4">
                <div class="card h-100 p-3 text-center">
                    <img src="{{ url_for('static', filename='images/graduate_icon.svg') }}?v={{ cache_buster }}" alt="Personal GenAI IELTS Coach" 
                        class="mx-auto d-block mb-3" width="80" height="80">
                    <h3 class="h4">Your Personal GenAI IELTS Coach</h3>
                    <p>Get detailed feedback aligned with the official IELTS assessment criteria on both speaking and writing tasks with TrueScore® and ClearScore®.</p>
                </div>
            </div>
            
            <div class="col-md-4 mb-4">
                <div class="card h-100 p-3 text-center">
                    <img src="{{ url_for('static', filename='images/globe_icon.svg') }}?v={{ cache_buster }}" alt="Global Assessment Preparation: At Your Own Pace, from Anywhere" 
                        class="mx-auto d-block mb-3" width="80" height="80">
                    <h3 class="h4">Global Assessment Preparation: At Your Own Pace, from Anywhere</h3>
                    <p>Whether you're a student striving for academic success or an individual chasing new horizons through study or career opportunities abroad, our inclusive platform empowers your goals, delivering world-class assessment preparation tailored to your journey, wherever you are.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Product Plans Section -->
{% if not current_user.is_authenticated %}
<section class="pricing py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-4">GenAI Assessed IELTS Modules</h2>
        <p class="text-center mb-5">Our specialized GenAI technologies provide accurate assessment for IELTS preparation</p>
        
        <!-- TrueScore® Section -->
        <div class="genai-brand-section mb-5">
            <div class="text-center mb-4">
                <div class="brand-icon text-success">
                    <i class="fas fa-pencil-alt"></i>
                </div>
                <h3 class="brand-title">TrueScore® Writing Assessment</h3>
                <p class="brand-tagline">Professional GenAI assessment of IELTS writing tasks aligned with the official IELTS band descriptors on Task Achievement, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy</p>
            </div>
            
            <div class="row equal-height-cards">
                <!-- Academic Writing Assessment -->
                <div class="col-lg-6 mb-4">
                    <div class="card pricing-card">
                        <div class="card-header bg-success text-white text-center">
                            <h3 class="my-0 font-weight-bold">Academic Writing</h3>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <div class="pricing-features mt-3 mb-4">
                                <ul class="list-unstyled">
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 4 complete assessment sets of:</li>
                                    <li class="mb-2 ms-4">Task 1: Chart & Graph analysis</li>
                                    <li class="mb-2 ms-4">Task 2: Academic essay writing</li>
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> TrueScore® GenAI detailed feedback</li>
                                </ul>
                            </div>
                            <div class="mt-auto d-grid">
                                <a href="{{ url_for('register') }}" class="btn btn-success btn-lg">
                                    <i class="fas fa-rocket"></i> Get Started
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- General Training Writing Assessment -->
                <div class="col-lg-6 mb-4">
                    <div class="card pricing-card">
                        <div class="card-header bg-success text-white text-center">
                            <h3 class="my-0 font-weight-bold">General Writing</h3>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <div class="pricing-features mt-3 mb-4">
                                <ul class="list-unstyled">
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 4 complete assessment sets of:</li>
                                    <li class="mb-2 ms-4">Task 1: Formal & informal letters</li>
                                    <li class="mb-2 ms-4">Task 2: General essay writing</li>
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> TrueScore® GenAI detailed feedback</li>
                                </ul>
                            </div>
                            <div class="mt-auto d-grid">
                                <a href="{{ url_for('register') }}" class="btn btn-success btn-lg">
                                    <i class="fas fa-rocket"></i> Get Started
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- ClearScore® Section -->
        <div class="genai-brand-section">
            <div class="text-center mb-4">
                <div class="brand-icon text-primary">
                    <i class="fas fa-microphone-alt"></i>
                </div>
                <h3 class="brand-title">ClearScore® Speaking Assessment</h3>
                <p class="brand-tagline">Advanced GenAI speech analysis and feedback aligned with the official IELTS band assessment criteria on Fluency and Coherence, Lexical Resource, Grammatical Range and Accuracy, and Pronunciation</p>
            </div>
            
            <div class="row equal-height-cards">
                <!-- Academic Speaking Assessment -->
                <div class="col-lg-6 mb-4">
                    <div class="card pricing-card">
                        <div class="card-header bg-primary text-white text-center">
                            <h3 class="my-0 font-weight-bold">Academic Speaking</h3>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <div class="pricing-features mt-3 mb-4">
                                <ul class="list-unstyled">
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 4 complete assessment sets of:</li>
                                    <li class="mb-2 ms-4">Part 1: Introduction & interview</li>
                                    <li class="mb-2 ms-4">Part 2: Speaking on a topic</li>
                                    <li class="mb-2 ms-4">Part 3: Two-way discussion</li>
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> ClearScore® GenAI speech analysis</li>
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Audio recording & playback</li>
                                </ul>
                            </div>
                            <div class="mt-auto d-grid">
                                <a href="{{ url_for('register') }}" class="btn btn-primary btn-lg">
                                    <i class="fas fa-rocket"></i> Get Started
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- General Training Speaking Assessment -->
                <div class="col-lg-6 mb-4">
                    <div class="card pricing-card">
                        <div class="card-header bg-primary text-white text-center">
                            <h3 class="my-0 font-weight-bold">General Speaking</h3>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <div class="pricing-features mt-3 mb-4">
                                <ul class="list-unstyled">
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 4 complete assessment sets of:</li>
                                    <li class="mb-2 ms-4">Part 1: Introduction & interview</li>
                                    <li class="mb-2 ms-4">Part 2: Speaking on a topic</li>
                                    <li class="mb-2 ms-4">Part 3: Two-way discussion</li>
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> ClearScore® GenAI speech analysis</li>
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Audio recording & playback</li>
                                </ul>
                            </div>
                            <div class="mt-auto d-grid">
                                <a href="{{ url_for('register') }}" class="btn btn-primary btn-lg">
                                    <i class="fas fa-rocket"></i> Get Started
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
{% endif %}



<!-- Testimonials Section -->
<section class="testimonials py-5">
    <div class="container">
        <h2 class="text-center mb-5">IELTS Success Stories: Users Who Achieved Their Target Band Scores</h2>
        
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card testimonial-card">
                    <div class="card-body">
                        <div class="testimonial-rating mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                        </div>
                        <p class="testimonial-text">"TrueScore® and ClearScore® completely transformed my IELTS preparation. As the only standardized GenAI assessment tools for IELTS, they gave me precise feedback aligned with official marking criteria. Thanks to their accurate assessments, I improved from Band 6 to 7.5 and secured admission to my dream university!"</p>
                        <div class="testimonial-author">
                            <div class="testimonial-name">Rahul S.</div>
                            <div class="testimonial-location">New Delhi, India</div>
                            <div class="testimonial-score">Overall Band Score: 7.5</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-4">
                <div class="card testimonial-card">
                    <div class="card-body">
                        <div class="testimonial-rating mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                        </div>
                        <p class="testimonial-text">"TrueScore® is truly revolutionary for IELTS writing preparation. Being the only standardized GenAI writing assessment that perfectly aligns with official IELTS criteria, it gave me exactly the guidance I needed. The detailed feedback on Task Achievement and Coherence helped me achieve my target band score on the first attempt!"</p>
                        <div class="testimonial-author">
                            <div class="testimonial-name">Fatima A.</div>
                            <div class="testimonial-location">Cebu, Philippines</div>
                            <div class="testimonial-score">Overall Band Score: 8.0</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-4">
                <div class="card testimonial-card">
                    <div class="card-body">
                        <div class="testimonial-rating mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star-half-alt text-warning"></i>
                        </div>
                        <p class="testimonial-text">"ClearScore® is absolutely unique in the IELTS preparation world. As the only GenAI speaking assessment tool that accurately applies IELTS criteria, it identified my precise pronunciation issues and provided standardized feedback. Using the world's only GenAI tool calibrated to IELTS standards helped me secure the Band 7.0 I needed for my immigration application!"</p>
                        <div class="testimonial-author">
                            <div class="testimonial-name">Min-Jun K.</div>
                            <div class="testimonial-location">Vancouver, Canada</div>
                            <div class="testimonial-score">Overall Band Score: 7.0</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Ad Container - Removed -->

<!-- CTA Section -->
<section class="cta py-5 bg-primary text-white">
    <div class="container text-center">
        <h2 class="mb-4">Experience the World's ONLY Standardized IELTS GenAI Assessment System</h2>
        <div class="mb-4">
            <span class="badge bg-light text-dark p-2 me-2 mb-2" style="font-size: 1.1rem;">TrueScore® Writing Assessment</span>
            <span class="badge bg-light text-dark p-2 mb-2" style="font-size: 1.1rem;">ClearScore® Speaking Analysis</span>
        </div>
        <p class="lead mb-4">Join thousands of successful IELTS candidates who achieved their target band scores using our exclusive GenAI assessment technology. Our proprietary tools are the only solutions that accurately apply official IELTS marking criteria to provide standardized, examiner-aligned feedback.</p>

        <a href="{{ url_for('register') }}" class="btn btn-light btn-lg fw-bold">
            <i class="fas fa-graduation-cap me-2"></i>Get Started with TrueScore® & ClearScore®
        </a>
    </div>
</section>
{% endblock %}"""
    
    return {
        'statusCode': 200,
        'body': template,
        'headers': {'Content-Type': 'text/html'}
    }

def serve_login_page():
    """Serve login page with reCAPTCHA v2"""
    template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Arial', sans-serif;
        }
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            padding: 40px;
            max-width: 500px;
            width: 100%;
        }
        .home-button {
            position: fixed;
            top: 20px;
            left: 20px;
            background: rgba(255,255,255,0.2);
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            text-decoration: none;
            transition: all 0.3s;
            z-index: 1000;
        }
        .home-button:hover {
            background: rgba(255,255,255,0.3);
            color: white;
            transform: scale(1.1);
        }
        .welcome-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .welcome-header h2 {
            color: #333;
            margin-bottom: 10px;
        }
        .welcome-header p {
            color: #666;
            font-size: 16px;
        }
        .mobile-info {
            background: #e3f2fd;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            border-left: 4px solid #2196f3;
        }
        .mobile-info h5 {
            color: #1565c0;
            margin-bottom: 15px;
        }
        .mobile-info p {
            color: #0277bd;
            margin-bottom: 10px;
        }
        .app-store-buttons {
            display: flex;
            gap: 10px;
            margin: 15px 0;
        }
        .app-store-button {
            flex: 1;
            background: #333;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            text-align: center;
            font-size: 14px;
            transition: all 0.3s;
        }
        .app-store-button:hover {
            background: #555;
            color: white;
            transform: translateY(-2px);
        }
        .form-control {
            border-radius: 8px;
            border: 2px solid #e0e0e0;
            padding: 12px;
            font-size: 16px;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .footer-links {
            text-align: center;
            margin-top: 20px;
        }
        .footer-links a {
            color: #667eea;
            text-decoration: none;
            margin: 0 10px;
        }
        .footer-links a:hover {
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            .login-card {
                padding: 30px 20px;
            }
            .app-store-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <a href="{{ url_for('index') }}" class="home-button">
        <i class="fas fa-home"></i>
    </a>
    
    <div class="login-container">
        <div class="login-card">
            <div class="welcome-header">
                <h2>Welcome Back</h2>
                <p>Sign in to access your IELTS assessments</p>
            </div>
            
            <div class="mobile-info">
                <h5><i class="fas fa-mobile-alt me-2"></i>Mobile-First Platform</h5>
                <p class="mb-2">New to IELTS GenAI Prep? Register and purchase through our mobile app first:</p>
                <div class="app-store-buttons">
                    <a href="https://apps.apple.com/app/ielts-genai-prep/id123456789" class="app-store-button">
                        <i class="fab fa-apple me-2"></i>App Store
                    </a>
                    <a href="https://play.google.com/store/apps/details?id=com.ieltsaiprep.app" class="app-store-button">
                        <i class="fab fa-google-play me-2"></i>Google Play
                    </a>
                </div>
                <p class="mt-3 mb-0"><small>One account works on both mobile app and website!</small></p>
            </div>
            
            <form method="POST" action="{{ url_for('login') }}">
                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                
                <div class="mb-3">
                    <div class="g-recaptcha" data-sitekey="6LdD2VUrAAAAABG_Tt5fFYmWkRB4YFVHPdjggYzQ"></div>
                </div>
                
                <button type="submit" class="btn btn-primary w-100 mb-3">
                    <i class="fas fa-sign-in-alt me-2"></i>Sign In
                </button>
                
                <div class="text-center">
                    <a href="#" class="text-muted">Forgot your password?</a>
                </div>
            </form>
            
            <div class="footer-links">
                <a href="{{ url_for('privacy_policy') }}">Privacy Policy</a>
                <a href="{{ url_for('terms_of_service') }}">Terms of Service</a>
            </div>
        </div>
    </div>
</body>
</html>"""
    
    # Replace reCAPTCHA site key with environment variable
    recaptcha_key = os.environ.get('RECAPTCHA_V2_SITE_KEY', '6LdD2VUrAAAAABG_Tt5fFYmWkRB4YFVHPdjggYzQ')
    template = template.replace('6LdD2VUrAAAAABG_Tt5fFYmWkRB4YFVHPdjggYzQ', recaptcha_key)
    
    return {
        'statusCode': 200,
        'body': template,
        'headers': {'Content-Type': 'text/html'}
    }

def serve_privacy_policy():
    """Serve privacy policy page"""
    template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 0;
            margin-bottom: 30px;
        }
        .header h1 {
            margin: 0;
            font-size: 2.5rem;
            font-weight: 600;
        }
        .back-button {
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            color: white;
            padding: 8px 16px;
            border-radius: 25px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        .back-button:hover {
            background: rgba(255,255,255,0.3);
            color: white;
            transform: translateY(-2px);
        }
        .content-card {
            background: white;
            border-radius: 10px;
            padding: 40px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .section-title {
            color: #667eea;
            font-size: 1.4rem;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e9ecef;
        }
        .data-usage {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
            border-left: 4px solid #667eea;
        }
        .last-updated {
            color: #6c757d;
            font-size: 0.9rem;
            margin-top: 20px;
            text-align: center;
        }
        .brand-highlight {
            color: #667eea;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="container">
            <a href="{{ url_for('index') }}" class="back-button">
                <i class="fas fa-arrow-left"></i> Back to Home
            </a>
            <h1>Privacy Policy</h1>
        </div>
    </div>

    <div class="container">
        <div class="content-card">
            <div class="section-title">Data Collection and Usage</div>
            <p>IELTS GenAI Prep collects and uses your personal information for the following purposes:</p>
            
            <div class="data-usage">
                <h5><i class="fas fa-user-circle me-2"></i>Account Management</h5>
                <p>We collect your email address and password to create and manage your account, enabling secure access to purchased assessments.</p>
            </div>
            
            <div class="data-usage">
                <h5><i class="fas fa-pen-fancy me-2"></i>Assessment Services</h5>
                <p>We process your writing submissions and speaking responses through our <span class="brand-highlight">TrueScore®</span> and <span class="brand-highlight">ClearScore®</span> AI assessment systems to provide personalized feedback and scoring.</p>
            </div>
            
            <div class="data-usage">
                <h5><i class="fas fa-microphone me-2"></i>Voice Recording Policy</h5>
                <p><strong>Important:</strong> Voice recordings are processed in real-time by our AI examiner Maya but are <strong>not saved or stored</strong>. Only the assessment feedback and scoring results are retained for your progress tracking.</p>
            </div>
            
            <div class="data-usage">
                <h5><i class="fas fa-chart-line me-2"></i>Progress Tracking</h5>
                <p>We store your assessment results and progress data to help you track your IELTS preparation journey and identify areas for improvement.</p>
            </div>
            
            <div class="data-usage">
                <h5><i class="fas fa-envelope me-2"></i>Communication</h5>
                <p>We use your email address to send account confirmations, assessment completions, and important service updates.</p>
            </div>

            <div class="section-title">Data Protection</div>
            <p>Your personal information is protected through:</p>
            <ul>
                <li>Secure encryption for all data transmission and storage</li>
                <li>Limited access to personal information on a need-to-know basis</li>
                <li>Regular security audits and updates</li>
                <li>No third-party sharing of your personal assessment data</li>
            </ul>

            <div class="section-title">AI Technology</div>
            <p>Our platform uses advanced AI technology including:</p>
            <ul>
                <li><span class="brand-highlight">TrueScore®</span> - AI-powered writing assessment with official IELTS criteria alignment</li>
                <li><span class="brand-highlight">ClearScore®</span> - AI-powered speaking assessment with Maya AI examiner</li>
                <li>Amazon Nova Sonic for real-time speech processing</li>
                <li>Amazon Nova Micro for writing evaluation</li>
            </ul>

            <div class="section-title">Mobile App Integration</div>
            <p>When you use our mobile app, the same privacy practices apply. Your account works seamlessly between the mobile app and website with consistent data protection.</p>

            <div class="last-updated">
                Last Updated: July 16, 2025
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>"""
    
    return {
        'statusCode': 200,
        'body': template,
        'headers': {'Content-Type': 'text/html'}
    }

def serve_terms_of_service():
    """Serve terms of service page"""
    template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms of Service - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 0;
            margin-bottom: 30px;
        }
        .header h1 {
            margin: 0;
            font-size: 2.5rem;
            font-weight: 600;
        }
        .back-button {
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            color: white;
            padding: 8px 16px;
            border-radius: 25px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        .back-button:hover {
            background: rgba(255,255,255,0.3);
            color: white;
            transform: translateY(-2px);
        }
        .content-card {
            background: white;
            border-radius: 10px;
            padding: 40px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .section-title {
            color: #667eea;
            font-size: 1.4rem;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e9ecef;
        }
        .pricing-highlight {
            background: #e8f4f8;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
            border-left: 4px solid #17a2b8;
        }
        .warning-box {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .last-updated {
            color: #6c757d;
            font-size: 0.9rem;
            margin-top: 20px;
            text-align: center;
        }
        .brand-highlight {
            color: #667eea;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="container">
            <a href="{{ url_for('index') }}" class="back-button">
                <i class="fas fa-arrow-left"></i> Back to Home
            </a>
            <h1>Terms of Service</h1>
        </div>
    </div>

    <div class="container">
        <div class="content-card">
            <div class="section-title">Assessment Products and Pricing</div>
            <div class="pricing-highlight">
                <h5><i class="fas fa-tag me-2"></i>Assessment Packages</h5>
                <p>Each assessment package costs <strong>$36.49 USD</strong> and includes:</p>
                <ul>
                    <li>4 complete AI-graded assessments</li>
                    <li>Detailed feedback using official IELTS criteria</li>
                    <li>Access on both mobile app and website</li>
                    <li>Progress tracking and performance analytics</li>
                </ul>
            </div>

            <div class="section-title">Payment and Refund Policy</div>
            <div class="warning-box">
                <h5><i class="fas fa-exclamation-triangle me-2"></i>No Refund Policy</h5>
                <p><strong>All purchases are final and non-refundable.</strong> Due to the instant delivery nature of our AI assessment services, refunds cannot be provided once you have accessed your purchased assessments.</p>
            </div>
            
            <p>Payments are processed through:</p>
            <ul>
                <li>Apple App Store (iOS mobile app)</li>
                <li>Google Play Store (Android mobile app)</li>
                <li>Secure payment processing for web purchases</li>
            </ul>

            <div class="section-title">AI Content Policy</div>
            <p>Our platform uses advanced AI technology to provide assessment services:</p>
            <ul>
                <li><span class="brand-highlight">TrueScore®</span> AI provides writing assessment with official IELTS rubric alignment</li>
                <li><span class="brand-highlight">ClearScore®</span> AI provides speaking assessment with Maya AI examiner</li>
                <li>AI-generated feedback is designed for educational purposes only</li>
                <li>Results are indicative and may not reflect actual IELTS test performance</li>
            </ul>

            <div class="section-title">Data Protection</div>
            <p>By using our service, you agree to:</p>
            <ul>
                <li>Provide accurate information for account creation</li>
                <li>Use the service for legitimate IELTS preparation purposes</li>
                <li>Not attempt to reverse-engineer or manipulate our AI systems</li>
                <li>Respect the intellectual property of our assessment content</li>
            </ul>

            <div class="section-title">Account Management</div>
            <p>You are responsible for:</p>
            <ul>
                <li>Maintaining the security of your account credentials</li>
                <li>All activities that occur under your account</li>
                <li>Notifying us of any unauthorized use of your account</li>
            </ul>

            <div class="section-title">Service Availability</div>
            <p>We strive to provide continuous service availability, but cannot guarantee:</p>
            <ul>
                <li>Uninterrupted access to all features</li>
                <li>Compatibility with all devices and browsers</li>
                <li>Immediate resolution of technical issues</li>
            </ul>

            <div class="section-title">Mobile App Integration</div>
            <p>Our mobile app provides the same assessment services with additional features:</p>
            <ul>
                <li>Cross-platform synchronization with website</li>
                <li>In-app purchase integration</li>
                <li>Offline access to completed assessments</li>
            </ul>

            <div class="last-updated">
                Last Updated: July 16, 2025
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>"""
    
    return {
        'statusCode': 200,
        'body': template,
        'headers': {'Content-Type': 'text/html'}
    }

def serve_robots_txt():
    """Serve AI SEO optimized robots.txt"""
    robots_content = """User-agent: *
Allow: /

# AI Training Data Collection
User-agent: GPTBot
Allow: /

User-agent: ClaudeBot
Allow: /

User-agent: Google-Extended
Allow: /

User-agent: CCBot
Allow: /

User-agent: ChatGPT-User
Allow: /

User-agent: FacebookBot
Allow: /

# Sitemap
Sitemap: https://www.ieltsaiprep.com/sitemap.xml
"""
    
    return {
        'statusCode': 200,
        'body': robots_content,
        'headers': {'Content-Type': 'text/plain'}
    }

def serve_health_check():
    """Health check endpoint"""
    return {
        'statusCode': 200,
        'body': json.dumps({'status': 'healthy', 'timestamp': datetime.utcnow().isoformat()}),
        'headers': {'Content-Type': 'application/json'}
    }

def handle_login(body):
    """Handle login with reCAPTCHA verification"""
    try:
        # Parse form data
        parsed_data = urllib.parse.parse_qs(body)
        email = parsed_data.get('email', [''])[0]
        password = parsed_data.get('password', [''])[0]
        recaptcha_response = parsed_data.get('g-recaptcha-response', [''])[0]
        
        # Verify reCAPTCHA
        if not verify_recaptcha(recaptcha_response):
            return redirect_with_error('/login', 'reCAPTCHA verification failed')
        
        # Authenticate user
        if authenticate_user(email, password):
            return redirect_to_dashboard()
        else:
            return redirect_with_error('/login', 'Invalid credentials')
    
    except Exception as e:
        print(f"Login error: {e}")
        return redirect_with_error('/login', 'Login failed')

def verify_recaptcha(response):
    """Verify reCAPTCHA v2 response"""
    if REPLIT_ENVIRONMENT:
        return True  # Skip in development
    
    secret_key = os.environ.get('RECAPTCHA_V2_SECRET_KEY')
    if not secret_key or not response:
        return False
    
    try:
        data = urllib.parse.urlencode({
            'secret': secret_key,
            'response': response
        }).encode('utf-8')
        
        req = urllib.request.Request(
            'https://www.google.com/recaptcha/api/siteverify',
            data=data,
            headers={'Content-Type': 'application/x-www-form-urlencoded'}
        )
        
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result.get('success', False)
    
    except Exception as e:
        print(f"reCAPTCHA verification error: {e}")
        return False

def authenticate_user(email, password):
    """Authenticate user against DynamoDB"""
    try:
        if REPLIT_ENVIRONMENT:
            # Development mode - use mock authentication
            test_users = {
                'test@ieltsgenaiprep.com': 'testpassword123',
                'prodtest@ieltsgenaiprep.com': 'test123'
            }
            return test_users.get(email) == password
        
        # Production mode - use DynamoDB
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        users_table = dynamodb.Table('ielts-genai-prep-users')
        
        response = users_table.get_item(Key={'email': email})
        
        if 'Item' not in response:
            return False
        
        user = response['Item']
        stored_hash = user.get('password_hash', '')
        
        # Verify password using PBKDF2
        return verify_password_hash(password, stored_hash)
    
    except Exception as e:
        print(f"Authentication error: {e}")
        return False

def verify_password_hash(password, stored_hash):
    """Verify password using PBKDF2 hashing"""
    try:
        # Use same salt as production
        salt = b'ielts-genai-prep-salt'
        password_bytes = password.encode('utf-8')
        
        # Generate hash with same parameters
        computed_hash = hashlib.pbkdf2_hmac('sha256', password_bytes, salt, 100000)
        computed_hash_b64 = base64.b64encode(computed_hash).decode('utf-8')
        
        return computed_hash_b64 == stored_hash
    
    except Exception as e:
        print(f"Password verification error: {e}")
        return False

def redirect_to_dashboard():
    """Redirect to dashboard after successful login"""
    return {
        'statusCode': 302,
        'headers': {'Location': '/dashboard'},
        'body': ''
    }

def redirect_with_error(location, error):
    """Redirect with error message"""
    return {
        'statusCode': 302,
        'headers': {'Location': f'{location}?error={error}'},
        'body': ''
    }

def serve_dashboard():
    """Serve dashboard page"""
    dashboard_template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Assessment Dashboard</h1>
        <div class="row">
            <div class="col-md-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Academic Writing</h5>
                        <p class="card-text">$36.49 USD for 4 assessments</p>
                        <a href="/assessment/academic-writing" class="btn btn-primary">Start Assessment</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">General Writing</h5>
                        <p class="card-text">$36.49 USD for 4 assessments</p>
                        <a href="/assessment/general-writing" class="btn btn-primary">Start Assessment</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Academic Speaking</h5>
                        <p class="card-text">$36.49 USD for 4 assessments</p>
                        <a href="/assessment/academic-speaking" class="btn btn-primary">Start Assessment</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">General Speaking</h5>
                        <p class="card-text">$36.49 USD for 4 assessments</p>
                        <a href="/assessment/general-speaking" class="btn btn-primary">Start Assessment</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>"""
    
    return {
        'statusCode': 200,
        'body': dashboard_template,
        'headers': {'Content-Type': 'text/html'}
    }

def serve_assessment_page(path):
    """Serve assessment pages"""
    assessment_type = path.split('/')[-1]
    
    assessment_template = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{assessment_type.title().replace('-', ' ')} Assessment - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>{assessment_type.title().replace('-', ' ')} Assessment</h1>
        <div class="alert alert-info">
            <strong>Assessment Type:</strong> {assessment_type}<br>
            <strong>Duration:</strong> 20 minutes<br>
            <strong>Pricing:</strong> $36.49 USD for 4 assessments
        </div>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Assessment Question</h5>
                <p class="card-text">Your {assessment_type} assessment will load here with AI-powered feedback.</p>
                <div class="mb-3">
                    <label for="assessment-response" class="form-label">Your Response:</label>
                    <textarea class="form-control" id="assessment-response" rows="10" placeholder="Enter your response here..."></textarea>
                </div>
                <button class="btn btn-success" onclick="submitAssessment()">Submit for AI Assessment</button>
            </div>
        </div>
    </div>
    <script>
        function submitAssessment() {
            alert('Assessment submitted for AI evaluation using TrueScore® and ClearScore® technology!');
        }
    </script>
</body>
</html>"""
    
    return {
        'statusCode': 200,
        'body': assessment_template,
        'headers': {'Content-Type': 'text/html'}
    }

def serve_profile():
    """Serve profile page"""
    profile_template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>My Profile</h1>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Account Information</h5>
                <p class="card-text">Manage your IELTS GenAI Prep account settings.</p>
                <div class="mb-3">
                    <strong>Assessment Purchases:</strong> $36.49 USD per assessment package
                </div>
                <div class="mb-3">
                    <strong>Available Assessments:</strong> 4 attempts per purchased package
                </div>
                <a href="/dashboard" class="btn btn-primary">Back to Dashboard</a>
            </div>
        </div>
    </div>
</body>
</html>"""
    
    return {
        'statusCode': 200,
        'body': profile_template,
        'headers': {'Content-Type': 'text/html'}
    }

