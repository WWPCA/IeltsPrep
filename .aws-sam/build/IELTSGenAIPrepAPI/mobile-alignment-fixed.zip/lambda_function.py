#!/usr/bin/env python3
"""
AWS Lambda Handler for IELTS GenAI Prep - Mobile Alignment Fixed
Updated: 2025-07-09 13:22:42
"""

import json
import os
import uuid
import time
import base64
import urllib.request
import urllib.parse
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

def lambda_handler(event, context):
    """Main AWS Lambda handler"""
    try:
        # Extract request information
        path = event.get('path', event.get('rawPath', ''))
        method = event.get('httpMethod', event.get('requestContext', {}).get('http', {}).get('method', 'GET'))
        
        # Route requests
        if path == '/' and method == 'GET':
            return handle_home_page()
        elif path == '/login' and method == 'GET':
            return handle_login_page()
        elif path == '/dashboard' and method == 'GET':
            return handle_dashboard_page(event.get('headers', {}))
        elif path == '/privacy-policy' and method == 'GET':
            return handle_privacy_policy()
        elif path == '/terms-of-service' and method == 'GET':
            return handle_terms_of_service()
        elif path == '/api/login' and method == 'POST':
            return handle_user_login(json.loads(event.get('body', '{}')))
        else:
            return {
                'statusCode': 404,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({'error': 'Endpoint not found'})
            }
            
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': f'Internal server error: {str(e)}'})
        }

def handle_home_page() -> Dict[str, Any]:
    """Handle home page with fixed mobile alignment"""
    
    template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="The only AI-powered IELTS assessment platform with standardized band scoring. Prepare for IELTS Writing and Speaking with TrueScore® and ClearScore® technologies.">
    <meta name="keywords" content="IELTS AI Assessment, IELTS Writing Feedback, IELTS Speaking Evaluation, GenAI IELTS App, TrueScore IELTS, ClearScore IELTS, AI Band Score, IELTS Band Descriptors, Academic IELTS, General Training IELTS, AI IELTS Practice, Online IELTS Preparation, AI Language Assessment, IELTS Prep App, IELTS writing preparation, IELTS speaking practice test, IELTS writing practice test, IELTS practice test with feedback">
    <meta property="og:title" content="IELTS GenAI Prep - AI-Powered IELTS Assessment Platform">
    <meta property="og:description" content="The only AI-powered IELTS assessment platform with standardized band scoring using TrueScore® and ClearScore® technologies.">
    <meta property="og:type" content="website">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="IELTS GenAI Prep - AI-Powered IELTS Assessment Platform">
    <meta name="twitter:description" content="The only AI-powered IELTS assessment platform with standardized band scoring using TrueScore® and ClearScore® technologies.">
    <title>IELTS GenAI Prep - AI-Powered IELTS Assessment Platform</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            line-height: 1.6;
        }
        
        .pricing-card {
            border: 1px solid rgba(0, 0, 0, 0.125);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }
        
        .pricing-card:hover {
            transform: translateY(-5px);
        }
        
        .genai-brand-section {
            margin-bottom: 60px;
        }
        
        .brand-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }
        
        .brand-title {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        
        .brand-tagline {
            color: #666;
            margin-bottom: 2rem;
            font-size: 1.1rem;
        }
        
        .hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 80px 0;
        }
        
        .features {
            padding: 80px 0;
            background: #f8f9fa;
        }
        
        .navbar {
            background-color: #fff !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-brand {
            font-weight: bold;
            color: #4361ee !important;
        }
        
        .navbar-nav .nav-link {
            color: #333 !important;
            font-weight: 500;
        }
        
        .navbar-nav .nav-link:hover {
            color: #4361ee !important;
        }
        
        /* Enhanced animations and interactivity */
        .hero h1 {
            animation: fadeInUp 0.8s ease-out;
        }
        
        .hero h2 {
            animation: fadeInUp 0.8s ease-out 0.2s both;
        }
        
        .hero .mb-4 > div {
            animation: fadeInLeft 0.6s ease-out 0.4s both;
        }
        
        .hero .mb-4 > div:nth-child(2) {
            animation-delay: 0.6s;
        }
        
        .hero .mb-4 > div:nth-child(3) {
            animation-delay: 0.8s;
        }
        
        .hero p {
            animation: fadeInUp 0.8s ease-out 1s both;
        }
        
        .hero-buttons {
            animation: fadeInUp 0.8s ease-out 1.2s both;
        }
        
        .hero .col-lg-6:last-child {
            animation: fadeInRight 0.8s ease-out 0.5s both;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes fadeInLeft {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes fadeInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        /* Button hover effects */
        .hero-buttons .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }
        
        .btn-success:hover {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            box-shadow: 0 6px 20px rgba(40, 167, 69, 0.6);
        }
        
        .btn-outline-light:hover {
            background: rgba(255,255,255,0.1);
            border-color: rgba(255,255,255,1);
            backdrop-filter: blur(10px);
        }
        
        /* Icon container hover effects */
        .hero .me-3:hover {
            background: rgba(255,255,255,0.3);
            transform: scale(1.1);
            transition: all 0.3s ease;
        }
        
        /* Improved typography for better readability and spacing */
        @media (max-width: 768px) {
            .hero {
                padding: 60px 0;
            }
            
            .hero h1 {
                font-size: 2.5rem !important;
                line-height: 1.3 !important;
            }
            
            .hero h2 {
                font-size: 1.3rem !important;
            }
            
            .hero-buttons .btn {
                display: block;
                width: 100%;
                margin-bottom: 15px;
                margin-right: 0 !important;
            }
            
            .hero .col-lg-6:first-child {
                text-align: center !important;
            }
        }
        
        @media (max-width: 576px) {
            .hero h1 {
                font-size: 2rem !important;
                line-height: 1.2 !important;
            }
            
            .hero h2 {
                font-size: 1.1rem !important;
            }
            
            .hero .mb-4 span {
                font-size: 1rem !important;
            }
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="/">IELTS GenAI Prep</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#features">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#assessments">Assessments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/login">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero" style="margin-top: 76px; padding: 80px 0; position: relative; overflow: hidden;">
        <!-- Background enhancement -->
        <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%); pointer-events: none;"></div>
        
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 text-center text-lg-start mb-5 mb-lg-0">
                    <!-- Improved typography hierarchy -->
                    <h1 class="display-3 fw-bold mb-3" style="font-size: 3.5rem; line-height: 1.2; letter-spacing: -0.02em; color: #ffffff; text-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                        Master IELTS with GenAI-Powered Scoring
                    </h1>
                    
                    <h2 class="h4 mb-4" style="font-size: 1.5rem; line-height: 1.4; font-weight: 500; color: rgba(255,255,255,0.95); margin-bottom: 2rem;">
                        The only AI-based IELTS platform with official band-aligned feedback
                    </h2>
                    
                    <!-- Benefits with icons -->
                    <div class="mb-4">
                        <div class="d-flex align-items-center justify-content-center justify-content-lg-start mb-3">
                            <div class="me-3" style="width: 40px; height: 40px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(10px);">
                                <i class="fas fa-brain text-white" style="font-size: 1.1rem;"></i>
                            </div>
                            <span class="text-white" style="font-size: 1.1rem; font-weight: 500;">AI-Powered Scoring Technology</span>
                        </div>
                        
                        <div class="d-flex align-items-center justify-content-center justify-content-lg-start mb-3">
                            <div class="me-3" style="width: 40px; height: 40px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(10px);">
                                <i class="fas fa-check-circle text-white" style="font-size: 1.1rem;"></i>
                            </div>
                            <span class="text-white" style="font-size: 1.1rem; font-weight: 500;">Official IELTS Criteria Alignment</span>
                        </div>
                        
                        <div class="d-flex align-items-center justify-content-center justify-content-lg-start mb-4">
                            <div class="me-3" style="width: 40px; height: 40px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(10px);">
                                <i class="fas fa-bullseye text-white" style="font-size: 1.1rem;"></i>
                            </div>
                            <span class="text-white" style="font-size: 1.1rem; font-weight: 500;">Academic & General Training Modules</span>
                        </div>
                    </div>
                    
                    <p class="mb-5" style="font-size: 1.1rem; line-height: 1.7; color: rgba(255,255,255,0.9); max-width: 500px; margin-left: auto; margin-right: auto;">
                        Experience TrueScore® and ClearScore® technologies that deliver standardized IELTS assessments based on official scoring criteria.
                    </p>
                    
                    <!-- Enhanced CTA buttons -->
                    <div class="hero-buttons text-center text-lg-start">
                        <a href="/login" class="btn btn-success btn-lg me-3 mb-3" style="font-size: 1.2rem; padding: 15px 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(40, 167, 69, 0.4); border: none; transition: all 0.3s ease;">
                            <i class="fas fa-rocket me-2"></i>
                            Get Started
                        </a>
                        <a href="#features" class="btn btn-outline-light btn-lg mb-3" style="font-size: 1.2rem; padding: 15px 30px; border-radius: 12px; border: 2px solid rgba(255,255,255,0.8); transition: all 0.3s ease;">
                            <i class="fas fa-info-circle me-2"></i>
                            Learn More
                        </a>
                    </div>
                </div>
                
                <div class="col-lg-6 text-center">
                    <!-- Sample Assessment Report Demo -->
                    <div style="background: rgba(255,255,255,0.1); border-radius: 20px; padding: 40px; backdrop-filter: blur(15px); box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
                        <div class="mb-3">
                            <span class="badge bg-primary text-white px-3 py-2" style="font-size: 0.9rem; font-weight: 600;">
                                <i class="fas fa-star me-1"></i>
                                YOUR SCORE PREVIEW
                            </span>
                        </div>
                        <div style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%); border-radius: 15px; padding: 30px; margin-bottom: 20px; position: relative;">
                            <h3 class="text-white mb-2" style="font-size: 1.4rem; font-weight: 600; line-height: 1.3;">
                                <i class="fas fa-certificate me-2"></i>
                                See Exactly How Your IELTS Score Will Look
                            </h3>
                            <div class="mb-3 d-flex justify-content-center">
                                <span class="badge bg-light text-dark px-3 py-1" style="font-size: 0.85rem; font-weight: 500; display: inline-block; text-align: center;">
                                    <i class="fas fa-pencil-alt me-1"></i>
                                    Academic Writing Assessment Sample
                                </span>
                            </div>
                            <p class="text-white mb-4" style="font-size: 0.95rem; opacity: 0.95; font-weight: 400;">
                                Instant feedback. Official IELTS alignment. No guesswork.
                            </p>
                            
                            <div class="text-white" style="font-size: 1.05rem; line-height: 1.6;">
                                <div class="mb-4 text-center" style="padding: 12px; background: rgba(255,255,255,0.15); border-radius: 10px;">
                                    <strong style="font-size: 1.3rem;">Overall Band Score: 7.5</strong>
                                </div>
                                
                                <div class="mb-3" style="font-size: 0.95rem;">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <span><strong>Task Achievement (25%)</strong></span>
                                        <span class="badge bg-light text-dark">Band 8</span>
                                    </div>
                                    <small style="opacity: 0.9; display: block; font-style: italic;">Sufficiently addresses all parts with well-developed ideas</small>
                                </div>
                                
                                <div class="mb-3" style="font-size: 0.95rem;">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <span><strong>Coherence & Cohesion (25%)</strong></span>
                                        <span class="badge bg-light text-dark">Band 7</span>
                                    </div>
                                    <small style="opacity: 0.9; display: block; font-style: italic;">Logically organizes information with clear progression</small>
                                </div>
                                
                                <div class="mb-3" style="font-size: 0.95rem;">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <span><strong>Lexical Resource (25%)</strong></span>
                                        <span class="badge bg-light text-dark">Band 7</span>
                                    </div>
                                    <small style="opacity: 0.9; display: block; font-style: italic;">Flexible vocabulary to discuss variety of topics</small>
                                </div>
                                
                                <div class="mb-3" style="font-size: 0.95rem;">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <span><strong>Grammar Range & Accuracy (25%)</strong></span>
                                        <span class="badge bg-light text-dark">Band 8</span>
                                    </div>
                                    <small style="opacity: 0.9; display: block; font-style: italic;">Wide range of structures with good control</small>
                                </div>
                            </div>
                            
                            <div class="mt-4 pt-3" style="border-top: 1px solid rgba(255,255,255,0.3);">
                                <div class="d-flex align-items-center justify-content-between flex-wrap">
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="fas fa-shield-check me-2" style="color: #90ee90;"></i>
                                        <span style="font-size: 0.9rem; font-weight: 500;">Official IELTS Marking Rubrics + GenAI Precision</span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        
                        <div class="text-center">
                            <div class="text-white mb-2" style="font-size: 0.95rem; font-weight: 500;">
                                <i class="fas fa-robot me-1"></i>
                                Powered by TrueScore® & ClearScore® Technologies
                            </div>
                            <div class="text-white" style="font-size: 0.9rem; opacity: 0.8; line-height: 1.4;">
                                This is an exact preview of the detailed report you'll receive after completing your first assessment.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- GenAI Technology Overview Section -->
    <section class="assessment-sections py-5" id="features">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="mb-3">The World's ONLY Standardized IELTS GenAI Assessment System</h2>
                <p class="text-muted">Our proprietary technologies deliver consistent, examiner-aligned evaluations</p>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card h-100 border-success">
                        <div class="card-header bg-success text-white text-center py-3">
                            <h3 class="m-0">TrueScore® Writing Assessment</h3>
                        </div>
                        <div class="card-body text-center">
                            <i class="fas fa-pencil-alt fa-3x text-success mb-3"></i>
                            <div class="badge bg-light text-dark mb-3">EXCLUSIVE TECHNOLOGY</div>
                            <p>TrueScore® is the only GenAI system that evaluates IELTS writing using the full IELTS marking rubric. Get instant, expert-level feedback on:</p>
                            <ul class="text-start mb-3" style="list-style-type: none; padding-left: 0; font-size: 16px; line-height: 1.6;">
                                <li class="mb-2"><span style="color: #28a745; font-size: 16px; margin-right: 10px;">●</span><strong style="font-weight: 600;">Task Achievement</strong></li>
                                <li class="mb-2"><span style="color: #28a745; font-size: 16px; margin-right: 10px;">●</span><strong style="font-weight: 600;">Coherence and Cohesion</strong></li>
                                <li class="mb-2"><span style="color: #28a745; font-size: 16px; margin-right: 10px;">●</span><strong style="font-weight: 600;">Lexical Resource</strong></li>
                                <li class="mb-2"><span style="color: #28a745; font-size: 16px; margin-right: 10px;">●</span><strong style="font-weight: 600;">Grammatical Range and Accuracy</strong></li>
                            </ul>
                            <p>Whether you're preparing for Academic Writing Tasks 1 & 2 or General Training Letter and Essay Writing, our AI coach gives you clear, structured band score reports and actionable improvement tips.</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 mb-4">
                    <div class="card h-100 border-primary">
                        <div class="card-header bg-primary text-white text-center py-3">
                            <h3 class="m-0">ClearScore® Speaking Assessment</h3>
                        </div>
                        <div class="card-body text-center">
                            <i class="fas fa-microphone-alt fa-3x text-primary mb-3"></i>
                            <div class="badge bg-light text-dark mb-3">EXCLUSIVE TECHNOLOGY</div>
                            <p>ClearScore® is the world's first AI system for IELTS speaking evaluation. With real-time speech analysis, it provides detailed, criteria-based feedback across all three parts of the IELTS Speaking test:</p>
                            <ul class="text-start mb-3" style="list-style-type: none; padding-left: 0; font-size: 16px; line-height: 1.6;">
                                <li class="mb-2"><span style="color: #007bff; font-size: 16px; margin-right: 10px;">●</span><strong style="font-weight: 600;">Fluency and Coherence</strong></li>
                                <li class="mb-2"><span style="color: #007bff; font-size: 16px; margin-right: 10px;">●</span><strong style="font-weight: 600;">Lexical Resource</strong></li>
                                <li class="mb-2"><span style="color: #007bff; font-size: 16px; margin-right: 10px;">●</span><strong style="font-weight: 600;">Grammatical Range and Accuracy</strong></li>
                                <li class="mb-2"><span style="color: #007bff; font-size: 16px; margin-right: 10px;">●</span><strong style="font-weight: 600;">Pronunciation</strong></li>
                            </ul>
                            <p>Practice with Maya, your AI IELTS examiner, for interactive, conversational assessments that mirror the real test.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features" id="about">
        <div class="container">
            <h2 class="text-center mb-5">Why Choose IELTS GenAI Prep for Your Assessment Preparation?</h2>
            
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100 p-3 text-center">
                        <i class="fas fa-bullseye fa-4x text-primary mb-3"></i>
                        <h3 class="h4">🎯 Official Band-Descriptive Feedback</h3>
                        <p>All assessments follow official IELTS band descriptors, ensuring your practice matches the real test.</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="card h-100 p-3 text-center">
                        <i class="fas fa-mobile-alt fa-4x text-success mb-3"></i>
                        <h3 class="h4">📱 Mobile & Desktop Access – Anytime, Anywhere</h3>
                        <p>Prepare at your own pace with secure cross-platform access. Start on mobile, continue on desktop – one account works everywhere.</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="card h-100 p-3 text-center">
                        <i class="fas fa-lightbulb fa-4x text-warning mb-3"></i>
                        <h3 class="h4">💡 Designed for Success</h3>
                        <p>Our tools are perfect for IELTS Academic and General Training candidates seeking reliable, expert-guided feedback to boost scores and build confidence.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Product Plans Section -->
    <section class="pricing py-5 bg-light" id="assessments">
        <div class="container">
            <h2 class="text-center mb-4">GenAI Assessed IELTS Modules</h2>
            <p class="text-center mb-5">Our specialized GenAI technologies provide accurate assessment for IELTS preparation</p>
            
            <!-- TrueScore® Section -->
            <div class="genai-brand-section mb-5">
                <div class="text-center mb-4">
                    <div class="brand-icon text-success">
                        <i class="fas fa-pencil-alt"></i>
                    </div>
                    <h3 class="brand-title">TrueScore® Writing Assessment</h3>
                    <p class="brand-tagline">Professional GenAI assessment of IELTS writing tasks aligned with the official IELTS band descriptors on Task Achievement, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy</p>
                </div>
                
                <div class="row">
                    <!-- Academic Writing Assessment -->
                    <div class="col-lg-6 mb-4">
                        <div class="card pricing-card">
                            <div class="card-header bg-success text-white text-center">
                                <h3 class="my-0 font-weight-bold">Academic Writing</h3>
                            </div>
                            <div class="card-body">
                                <h1 class="card-title pricing-card-title text-center">$36<small class="text-muted"> for 4 assessments</small></h1>
                                <ul class="list-unstyled mt-3 mb-4">
                                    <li><i class="fas fa-check text-success me-2"></i>4 Unique Assessments Included</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Task 1 & Task 2 Assessment</li>
                                    <li><i class="fas fa-check text-success me-2"></i>TrueScore® GenAI Evaluation</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Official IELTS Criteria Alignment</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Detailed Band Score Feedback</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Writing Improvement Recommendations</li>
                                </ul>
                                <a href="/qr-auth" class="btn btn-lg btn-block btn-success w-100">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>

                    <!-- General Writing Assessment -->
                    <div class="col-lg-6 mb-4">
                        <div class="card pricing-card">
                            <div class="card-header bg-success text-white text-center">
                                <h3 class="my-0 font-weight-bold">General Training Writing</h3>
                            </div>
                            <div class="card-body">
                                <h1 class="card-title pricing-card-title text-center">$36<small class="text-muted"> for 4 assessments</small></h1>
                                <ul class="list-unstyled mt-3 mb-4">
                                    <li><i class="fas fa-check text-success me-2"></i>4 Unique Assessments Included</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Letter & Essay Assessment</li>
                                    <li><i class="fas fa-check text-success me-2"></i>TrueScore® GenAI Evaluation</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Official IELTS Criteria Alignment</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Comprehensive Feedback System</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Target Band Achievement Support</li>
                                </ul>
                                <a href="/qr-auth" class="btn btn-lg btn-block btn-success w-100">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ClearScore® Section -->
            <div class="genai-brand-section">
                <div class="text-center mb-4">
                    <div class="brand-icon text-primary">
                        <i class="fas fa-microphone-alt"></i>
                    </div>
                    <h3 class="brand-title">ClearScore® Speaking Assessment</h3>
                    <p class="brand-tagline">Revolutionary GenAI speaking assessment with real-time conversation analysis covering Fluency and Coherence, Lexical Resource, Grammatical Range and Accuracy, and Pronunciation</p>
                </div>
                
                <div class="row">
                    <!-- Academic Speaking Assessment -->
                    <div class="col-lg-6 mb-4">
                        <div class="card pricing-card">
                            <div class="card-header bg-primary text-white text-center">
                                <h3 class="my-0 font-weight-bold">Academic Speaking</h3>
                            </div>
                            <div class="card-body">
                                <h1 class="card-title pricing-card-title text-center">$36<small class="text-muted"> for 4 assessments</small></h1>
                                <ul class="list-unstyled mt-3 mb-4">
                                    <li><i class="fas fa-check text-primary me-2"></i>4 Unique Assessments Included</li>
                                    <li><i class="fas fa-check text-primary me-2"></i>Interactive Maya AI Examiner</li>
                                    <li><i class="fas fa-check text-primary me-2"></i>ClearScore® GenAI Analysis</li>
                                    <li><i class="fas fa-check text-primary me-2"></i>Real-time Speech Assessment</li>
                                    <li><i class="fas fa-check text-primary me-2"></i>All Three Speaking Parts</li>
                                    <li><i class="fas fa-check text-primary me-2"></i>Pronunciation & Fluency Feedback</li>
                                </ul>
                                <a href="/qr-auth" class="btn btn-lg btn-block btn-primary w-100">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>

                    <!-- General Speaking Assessment -->
                    <div class="col-lg-6 mb-4">
                        <div class="card pricing-card">
                            <div class="card-header bg-primary text-white text-center">
                                <h3 class="my-0 font-weight-bold">General Training Speaking</h3>
                            </div>
                            <div class="card-body">
                                <h1 class="card-title pricing-card-title text-center">$36<small class="text-muted"> for 4 assessments</small></h1>
                                <ul class="list-unstyled mt-3 mb-4">
                                    <li><i class="fas fa-check text-primary me-2"></i>4 Unique Assessments Included</li>
                                    <li><i class="fas fa-check text-primary me-2"></i>Maya AI Conversation Partner</li>
                                    <li><i class="fas fa-check text-primary me-2"></i>ClearScore® GenAI Technology</li>
                                    <li><i class="fas fa-check text-primary me-2"></i>Comprehensive Speaking Analysis</li>
                                    <li><i class="fas fa-check text-primary me-2"></i>General Training Topic Focus</li>
                                    <li><i class="fas fa-check text-primary me-2"></i>Instant Performance Feedback</li>
                                </ul>
                                <a href="/qr-auth" class="btn btn-lg btn-block btn-primary w-100">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class="py-5" id="how-it-works">
        <div class="container">
            <h2 class="text-center mb-5">How to Get Started</h2>
            <div class="row">
                <div class="col-md-4 mb-4 text-center">
                    <div class="mb-3">
                        <i class="fas fa-mobile-alt fa-3x text-primary"></i>
                    </div>
                    <h4>Step 1: Download the IELTS GenAI Prep app</h4>
                    <p>Download the IELTS GenAI Prep app from the App Store or Google Play</p>
                </div>
                <div class="col-md-4 mb-4 text-center">
                    <div class="mb-3">
                        <i class="fas fa-credit-card fa-3x text-warning"></i>
                    </div>
                    <h4>Step 2: Create your account and purchase a package</h4>
                    <p>Create your account and purchase a package ($36 for 4 assessments)</p>
                </div>
                <div class="col-md-4 mb-4 text-center">
                    <div class="mb-3">
                        <i class="fas fa-laptop fa-3x text-success"></i>
                    </div>
                    <h4>Step 3: Log in on the mobile app or desktop site</h4>
                    <p>Log in on the mobile app or desktop site with your account – your progress syncs automatically</p>
                </div>
            </div>
            
            <div class="row mt-4">
                <div class="col-12 text-center">
                    <div class="alert alert-success">
                        <h5 class="mb-2"><i class="fas fa-shield-alt me-2"></i>Secure Cross-Platform Access</h5>
                        <p class="mb-0">One account, multiple platforms. After purchasing in the mobile app, use the same login credentials to access assessments on desktop/laptop through this website.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-light py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>IELTS GenAI Prep</h5>
                    <p>The world's only standardized IELTS GenAI assessment platform</p>
                </div>
                <div class="col-md-6">
                    <div class="d-flex flex-column flex-md-row justify-content-md-end">
                        <div class="mb-2">
                            <a href="/privacy-policy" class="text-light me-3">Privacy Policy</a>
                            <a href="/terms-of-service" class="text-light">Terms of Service</a>
                        </div>
                    </div>
                    <div class="text-md-end">
                        <p>&copy; 2025 IELTS GenAI Prep. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>"""
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'text/html',
            'Cache-Control': 'no-cache, no-store, must-revalidate'
        },
        'body': template
    }

def handle_login_page() -> Dict[str, Any]:
    """Handle login page"""
    login_template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        <h3>Login to IELTS GenAI Prep</h3>
                    </div>
                    <div class="card-body">
                        <form action="/api/login" method="POST">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>"""
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'text/html',
            'Cache-Control': 'no-cache'
        },
        'body': login_template
    }

def handle_dashboard_page(headers: Dict[str, Any]) -> Dict[str, Any]:
    """Handle dashboard page"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html'},
        'body': '<h1>Dashboard - Coming Soon</h1>'
    }

def handle_privacy_policy() -> Dict[str, Any]:
    """Handle privacy policy page"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html'},
        'body': '<h1>Privacy Policy - Coming Soon</h1>'
    }

def handle_terms_of_service() -> Dict[str, Any]:
    """Handle terms of service page"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html'},
        'body': '<h1>Terms of Service - Coming Soon</h1>'
    }

def handle_user_login(data: Dict[str, Any]) -> Dict[str, Any]:
    """Handle user login"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps({'success': True, 'message': 'Login successful'})
    }
