import json

def lambda_handler(event, context):
    """Lambda handler serving all comprehensive templates"""
    
    path = event.get('path', '/')
    method = event.get('httpMethod', 'GET')
    
    print(f"Processing {method} {path}")
    
    # Define all HTML templates
    home_html = """<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"description\" content=\"IELTS GenAI Prep - Your comprehensive IELTS assessment preparation platform\">
    <title>IELTS GenAI Prep</title>
    
    <!-- Bootstrap CSS -->
    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
    
    <!-- Font Awesome for icons -->
    <link href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css\" rel=\"stylesheet\">
    
    <!-- Google Fonts -->
    <link href=\"https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap\" rel=\"stylesheet\">
    
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            line-height: 1.6;
        }
        
        .pricing-card {
            border: 1px solid rgba(0, 0, 0, 0.125);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }
        
        .pricing-card:hover {
            transform: translateY(-5px);
        }
        
        .genai-brand-section {
            margin-bottom: 60px;
        }
        
        .brand-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }
        
        .brand-title {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        
        .brand-tagline {
            color: #666;
            margin-bottom: 2rem;
            font-size: 1.1rem;
        }
        
        .hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 80px 0;
        }
        
        .features {
            padding: 80px 0;
            background: #f8f9fa;
        }
        
        .assessment-sections {
            padding: 80px 0;
            background: #f8f9fa;
        }
        
        .testimonials {
            padding: 80px 0;
        }
        
        .testimonial-card {
            height: 100%;
            border: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .testimonial-rating {
            text-align: center;
        }
        
        .testimonial-text {
            font-style: italic;
            margin-bottom: 20px;
        }
        
        .testimonial-author {
            text-align: center;
            border-top: 1px solid #eee;
            padding-top: 15px;
        }
        
        .testimonial-name {
            font-weight: bold;
            color: #333;
        }
        
        .testimonial-location {
            color: #666;
            font-size: 0.9rem;
        }
        
        .testimonial-score {
            color: #28a745;
            font-weight: bold;
            font-size: 0.9rem;
        }
        
        .equal-height-cards {
            display: flex;
            flex-wrap: wrap;
        }
        
        .equal-height-cards > [class*=\"col-\"] {
            display: flex;
        }
        
        .equal-height-cards .card {
            flex: 1;
        }
        
        .navbar {
            background-color: #fff !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-brand {
            font-weight: bold;
            color: #4361ee !important;
        }
        
        .navbar-nav .nav-link {
            color: #333 !important;
            font-weight: 500;
        }
        
        .navbar-nav .nav-link:hover {
            color: #4361ee !important;
        }
        
        /* Fix for mobile hero section spacing */
        @media (max-width: 768px) {
            .hero {
                padding: 60px 0;
            }
            
            .display-4 {
                font-size: 2rem;
            }
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <nav class=\"navbar navbar-expand-lg navbar-light bg-light fixed-top\">
        <div class=\"container\">
            <a class=\"navbar-brand\" href=\"/\">IELTS GenAI Prep</a>
            <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarNav\">
                <span class=\"navbar-toggler-icon\"></span>
            </button>
            <div class=\"collapse navbar-collapse\" id=\"navbarNav\">
                <ul class=\"navbar-nav ms-auto\">
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"#features\">Features</a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"#assessments\">Assessments</a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"/login\">Login</a>
                    </li>
                    <li class=\"nav-item dropdown\">
                        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdown\" role=\"button\" data-bs-toggle=\"dropdown\">
                            Legal
                        </a>
                        <ul class=\"dropdown-menu\">
                            <li><a class=\"dropdown-item\" href=\"/privacy-policy\">Privacy Policy</a></li>
                            <li><a class=\"dropdown-item\" href=\"/terms-of-service\">Terms of Service</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class=\"hero\" style=\"margin-top: 76px;\">
        <div class=\"container\">
            <div class=\"text-center mb-4\">
                <h1 class=\"display-4 fw-bold mb-3\">Master IELTS with the World's ONLY GenAI Assessment Platform</h1>
                <div class=\"p-2 mb-4\" style=\"background-color: #3498db; color: white; border-radius: 4px; display: inline-block; width: 100%; max-width: 100%; white-space: normal; word-wrap: break-word; word-break: break-word; overflow-wrap: break-word; text-align: center; padding: 8px; font-size: 1rem; line-height: 1.4;\">
                    Powered by TrueScore® & ClearScore® - Industry-Leading Standardized Assessment Technology
                </div>
            </div>
            
            <div class=\"row mb-4\">
                <div class=\"col-lg-10 mx-auto\">
                    <p class=\"lead\">IELTS GenAI Prep delivers precise, examiner-aligned feedback through our exclusive TrueScore® writing analysis and ClearScore® speaking assessment systems. Our proprietary technology applies the official IELTS marking criteria to provide consistent, accurate band scores and actionable feedback for both Academic and General Training.</p>
                </div>
            </div>

            <div class=\"text-center mb-5\">
                <div class=\"d-md-flex d-block justify-content-center gap-3\">
                    <div class=\"d-flex align-items-center justify-content-center mb-2 mb-md-0\">
                        <i class=\"fas fa-check-circle text-light me-2\"></i>
                        <span>Standardized Assessment</span>
                    </div>
                    <div class=\"d-flex align-items-center justify-content-center mb-2 mb-md-0\">
                        <i class=\"fas fa-check-circle text-light me-2\"></i>
                        <span>IELTS Criteria Aligned</span>
                    </div>
                    <div class=\"d-flex align-items-center justify-content-center\">
                        <i class=\"fas fa-check-circle text-light me-2\"></i>
                        <span>Personalized Feedback</span>
                    </div>
                </div>
            </div>

            <div class=\"hero-buttons text-center\">
                <a href=\"/qr-auth\" class=\"btn btn-primary btn-lg me-2\">Access Portal</a>
                <a href=\"#assessments\" class=\"btn btn-light btn-lg\">View Assessments</a>
            </div>
        </div>
    </section>

    <!-- GenAI Technology Overview Section -->
    <section class=\"assessment-sections py-5\" id=\"features\">
        <div class=\"container\">
            <div class=\"text-center mb-5\">
                <h2 class=\"mb-3\">The World's ONLY Standardized IELTS GenAI Assessment System</h2>
                <p class=\"text-muted\">Our proprietary technologies deliver consistent, examiner-aligned evaluations</p>
            </div>
            
            <div class=\"row\">
                <div class=\"col-md-6 mb-4\">
                    <div class=\"card h-100 border-success\">
                        <div class=\"card-header bg-success text-white text-center py-3\">
                            <h3 class=\"m-0\">TrueScore® Writing Assessment</h3>
                        </div>
                        <div class=\"card-body text-center\">
                            <i class=\"fas fa-pencil-alt fa-3x text-success mb-3\"></i>
                            <div class=\"badge bg-light text-dark mb-3\">EXCLUSIVE TECHNOLOGY</div>
                            <p>Our proprietary TrueScore® system is the only GenAI technology that standardizes writing assessment within the official IELTS marking criteria rubric. Receive detailed feedback on Task Achievement, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy for both Academic and General Training tasks.</p>
                        </div>
                    </div>
                </div>
                
                <div class=\"col-md-6 mb-4\">
                    <div class=\"card h-100 border-primary\">
                        <div class=\"card-header bg-primary text-white text-center py-3\">
                            <h3 class=\"m-0\">ClearScore® Speaking Assessment</h3>
                        </div>
                        <div class=\"card-body text-center\">
                            <i class=\"fas fa-microphone-alt fa-3x text-primary mb-3\"></i>
                            <div class=\"badge bg-light text-dark mb-3\">EXCLUSIVE TECHNOLOGY</div>
                            <p>ClearScore® is the world's first GenAI system to precisely assess IELTS speaking performance across all official criteria. Its sophisticated speech analysis delivers comprehensive feedback on Fluency and Coherence, Lexical Resource, Grammatical Range and Accuracy, and Pronunciation for all three speaking assessment sections.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class=\"features\" id=\"about\">
        <div class=\"container\">
            <h2 class=\"text-center mb-5\">Why Choose IELTS GenAI Prep for Your Assessment Preparation?</h2>
            
            <div class=\"row\">
                <div class=\"col-md-4 mb-4\">
                    <div class=\"card h-100 p-3 text-center\">
                        <i class=\"fas fa-clipboard-check fa-4x text-primary mb-3\"></i>
                        <h3 class=\"h4\">Comprehensive IELTS Assessment Preparation</h3>
                        <p>Master the IELTS Writing and Speaking modules with the world's only GenAI-driven assessments aligned with the official IELTS band descriptors for accurate feedback for both IELTS Academic and General Training. Boost your skills and achieve your target score with confidence.</p>
                    </div>
                </div>
                
                <div class=\"col-md-4 mb-4\">
                    <div class=\"card h-100 p-3 text-center\">
                        <i class=\"fas fa-user-graduate fa-4x text-success mb-3\"></i>
                        <h3 class=\"h4\">Your Personal GenAI IELTS Coach</h3>
                        <p>Get detailed feedback aligned with the official IELTS assessment criteria on both speaking and writing tasks with TrueScore® and ClearScore®.</p>
                    </div>
                </div>
                
                <div class=\"col-md-4 mb-4\">
                    <div class=\"card h-100 p-3 text-center\">
                        <i class=\"fas fa-globe fa-4x text-info mb-3\"></i>
                        <h3 class=\"h4\">Global Assessment Preparation: At Your Own Pace, from Anywhere</h3>
                        <p>Whether you're a student striving for academic success or an individual chasing new horizons through study or career opportunities abroad, our inclusive platform empowers your goals, delivering world-class assessment preparation tailored to your journey, wherever you are.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Product Plans Section -->
    <section class=\"pricing py-5 bg-light\" id=\"assessments\">
        <div class=\"container\">
            <h2 class=\"text-center mb-4\">GenAI Assessed IELTS Modules</h2>
            <p class=\"text-center mb-5\">Our specialized GenAI technologies provide accurate assessment for IELTS preparation</p>
            
            <!-- TrueScore® Section -->
            <div class=\"genai-brand-section mb-5\">
                <div class=\"text-center mb-4\">
                    <div class=\"brand-icon text-success\">
                        <i class=\"fas fa-pencil-alt\"></i>
                    </div>
                    <h3 class=\"brand-title\">TrueScore® Writing Assessment</h3>
                    <p class=\"brand-tagline\">Professional GenAI assessment of IELTS writing tasks aligned with the official IELTS band descriptors on Task Achievement, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy</p>
                </div>
                
                <div class=\"row\">
                    <!-- Academic Writing Assessment -->
                    <div class=\"col-lg-6 mb-4\">
                        <div class=\"card pricing-card\">
                            <div class=\"card-header bg-success text-white text-center\">
                                <h3 class=\"my-0 font-weight-bold\">Academic Writing</h3>
                            </div>
                            <div class=\"card-body\">
                                <h1 class=\"card-title pricing-card-title text-center\">$36<small class=\"text-muted\"> for 4 assessments</small></h1>
                                <ul class=\"list-unstyled mt-3 mb-4\">
                                    <li><i class=\"fas fa-check text-success me-2\"></i>4 Unique Assessments Included</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Task 1 & Task 2 Assessment</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>TrueScore® GenAI Evaluation</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Official IELTS Criteria Alignment</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Detailed Band Score Feedback</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Writing Improvement Recommendations</li>
                                </ul>
                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-success w-100\">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>

                    <!-- General Writing Assessment -->
                    <div class=\"col-lg-6 mb-4\">
                        <div class=\"card pricing-card\">
                            <div class=\"card-header bg-success text-white text-center\">
                                <h3 class=\"my-0 font-weight-bold\">General Training Writing</h3>
                            </div>
                            <div class=\"card-body\">
                                <h1 class=\"card-title pricing-card-title text-center\">$36<small class=\"text-muted\"> for 4 assessments</small></h1>
                                <ul class=\"list-unstyled mt-3 mb-4\">
                                    <li><i class=\"fas fa-check text-success me-2\"></i>4 Unique Assessments Included</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Letter & Essay Assessment</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>TrueScore® GenAI Evaluation</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Official IELTS Criteria Alignment</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Comprehensive Feedback System</li>
                                    <li><i class=\"fas fa-check text-success me-2\"></i>Target Band Achievement Support</li>
                                </ul>
                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-success w-100\">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ClearScore® Section -->
            <div class=\"genai-brand-section\">
                <div class=\"text-center mb-4\">
                    <div class=\"brand-icon text-primary\">
                        <i class=\"fas fa-microphone-alt\"></i>
                    </div>
                    <h3 class=\"brand-title\">ClearScore® Speaking Assessment</h3>
                    <p class=\"brand-tagline\">Revolutionary GenAI speaking assessment with real-time conversation analysis covering Fluency and Coherence, Lexical Resource, Grammatical Range and Accuracy, and Pronunciation</p>
                </div>
                
                <div class=\"row\">
                    <!-- Academic Speaking Assessment -->
                    <div class=\"col-lg-6 mb-4\">
                        <div class=\"card pricing-card\">
                            <div class=\"card-header bg-primary text-white text-center\">
                                <h3 class=\"my-0 font-weight-bold\">Academic Speaking</h3>
                            </div>
                            <div class=\"card-body\">
                                <h1 class=\"card-title pricing-card-title text-center\">$36<small class=\"text-muted\"> for 4 assessments</small></h1>
                                <ul class=\"list-unstyled mt-3 mb-4\">
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>4 Unique Assessments Included</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Interactive Maya AI Examiner</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>ClearScore® GenAI Analysis</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Real-time Speech Assessment</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>All Three Speaking Parts</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Pronunciation & Fluency Feedback</li>
                                </ul>
                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-primary w-100\">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>

                    <!-- General Speaking Assessment -->
                    <div class=\"col-lg-6 mb-4\">
                        <div class=\"card pricing-card\">
                            <div class=\"card-header bg-primary text-white text-center\">
                                <h3 class=\"my-0 font-weight-bold\">General Training Speaking</h3>
                            </div>
                            <div class=\"card-body\">
                                <h1 class=\"card-title pricing-card-title text-center\">$36<small class=\"text-muted\"> for 4 assessments</small></h1>
                                <ul class=\"list-unstyled mt-3 mb-4\">
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>4 Unique Assessments Included</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Maya AI Conversation Partner</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>ClearScore® GenAI Technology</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Comprehensive Speaking Analysis</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>General Training Topic Focus</li>
                                    <li><i class=\"fas fa-check text-primary me-2\"></i>Instant Performance Feedback</li>
                                </ul>
                                <a href=\"/qr-auth\" class=\"btn btn-lg btn-block btn-primary w-100\">Purchase via Mobile App</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class=\"py-5\" id=\"how-it-works\">
        <div class=\"container\">
            <h2 class=\"text-center mb-5\">How to Access Your GenAI Assessments</h2>
            <div class=\"row\">
                <div class=\"col-md-4 mb-4 text-center\">
                    <div class=\"mb-3\">
                        <i class=\"fas fa-mobile-alt fa-3x text-primary\"></i>
                    </div>
                    <h4>1. Download Mobile App</h4>
                    <p>Get IELTS GenAI Prep from the App Store or Google Play Store</p>
                </div>
                <div class=\"col-md-4 mb-4 text-center\">
                    <div class=\"mb-3\">
                        <i class=\"fas fa-credit-card fa-3x text-warning\"></i>
                    </div>
                    <h4>2. Purchase & Register</h4>
                    <p>Create your account and purchase assessment packages for $36.00 each through secure app store billing</p>
                </div>
                <div class=\"col-md-4 mb-4 text-center\">
                    <div class=\"mb-3\">
                        <i class=\"fas fa-laptop fa-3x text-success\"></i>
                    </div>
                    <h4>3. Login Anywhere</h4>
                    <p>Use your mobile app credentials to login on this website for desktop access, or continue using the mobile app</p>
                </div>
            </div>
            
            <div class=\"row mt-4\">
                <div class=\"col-12 text-center\">
                    <div class=\"alert alert-success\">
                        <h5 class=\"mb-2\"><i class=\"fas fa-shield-alt me-2\"></i>Secure Cross-Platform Access</h5>
                        <p class=\"mb-0\">One account, multiple platforms. After purchasing in the mobile app, use the same login credentials to access assessments on desktop/laptop through this website.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class=\"bg-dark text-light py-4\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-6\">
                    <h5>IELTS GenAI Prep</h5>
                    <p>The world's only standardized IELTS GenAI assessment platform</p>
                </div>
                <div class=\"col-md-6\">
                    <div class=\"d-flex flex-column flex-md-row justify-content-md-end\">
                        <div class=\"mb-2\">
                            <a href=\"/privacy-policy\" class=\"text-light me-3\">Privacy Policy</a>
                            <a href=\"/terms-of-service\" class=\"text-light\">Terms of Service</a>
                        </div>
                    </div>
                    <div class=\"text-md-end\">
                        <p>&copy; 2024 IELTS GenAI Prep. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js\"></script>
</body>
</html>"""
    
    login_html = """<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Welcome Back - IELTS GenAI Prep</title>
    
    <!-- Bootstrap CSS -->
    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
    
    <!-- Font Awesome for icons -->
    <link href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css\" rel=\"stylesheet\">
    
    <!-- Google Fonts -->
    <link href=\"https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap\" rel=\"stylesheet\">
    
    <!-- Google reCAPTCHA -->
    <script src=\"https://www.google.com/recaptcha/api.js\" async defer></script>
    
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            max-width: 450px;
            width: 100%;
            padding: 0;
            overflow: hidden;
        }
        
        .login-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
            position: relative;
        }
        
        .login-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
        }
        
        .login-header-content {
            position: relative;
            z-index: 1;
        }
        
        .login-body {
            padding: 30px;
        }
        
        .welcome-icon {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.9;
        }
        
        .welcome-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .welcome-subtitle {
            font-size: 0.95rem;
            opacity: 0.9;
            margin-bottom: 0;
        }
        
        .new-user-section {
            background: #f8f9ff;
            border: 1px solid #e1e8ff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
        }
        
        .new-user-title {
            color: #4361ee;
            font-weight: 600;
            font-size: 0.95rem;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
        }
        
        .new-user-steps {
            font-size: 0.85rem;
            color: #6c757d;
            margin-bottom: 15px;
            line-height: 1.4;
        }
        
        .new-user-steps ol {
            margin: 0;
            padding-left: 18px;
        }
        
        .new-user-steps li {
            margin-bottom: 3px;
        }
        
        .app-store-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
        }
        
        .app-btn {
            background: #4361ee;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 8px 16px;
            font-size: 0.8rem;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }
        
        .app-btn:hover {
            background: #3651d4;
            color: white;
            transform: translateY(-1px);
        }
        
        .form-control {
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 12px 15px;
            font-size: 0.95rem;
            transition: all 0.2s;
        }
        
        .form-control:focus {
            border-color: #4361ee;
            box-shadow: 0 0 0 0.2rem rgba(67, 97, 238, 0.15);
        }
        
        .form-label {
            font-weight: 500;
            color: #495057;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .form-check-label {
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #4361ee 0%, #3651d4 100%);
            border: none;
            border-radius: 8px;
            padding: 12px;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.2s;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #3651d4 0%, #2a47c4 100%);
            transform: translateY(-1px);
        }
        
        .forgot-password {
            color: #4361ee;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .forgot-password:hover {
            color: #3651d4;
            text-decoration: underline;
        }
        
        .recaptcha-container {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }
        
        .privacy-notice {
            font-size: 0.75rem;
            color: #6c757d;
            text-align: center;
            margin-top: 15px;
            line-height: 1.3;
        }
        
        .privacy-notice a {
            color: #4361ee;
            text-decoration: none;
        }
        
        .privacy-notice a:hover {
            text-decoration: underline;
        }
        
        @media (max-width: 576px) {
            .login-container {
                margin: 10px;
                border-radius: 10px;
            }
            
            .login-header {
                padding: 25px 20px;
            }
            
            .login-body {
                padding: 25px 20px;
            }
            
            .welcome-icon {
                font-size: 2.5rem;
            }
            
            .welcome-title {
                font-size: 1.3rem;
            }
            
            .app-store-buttons {
                flex-direction: column;
            }
            
            .app-btn {
                justify-content: center;
            }
        }
    </style>
</head>

<body>
    <div class=\"login-container\">
        <!-- Header -->
        <div class=\"login-header\">
            <div class=\"login-header-content\">
                <div class=\"welcome-icon\">
                    <i class=\"fas fa-user-circle\"></i>
                </div>
                <h1 class=\"welcome-title\">Welcome Back</h1>
                <p class=\"welcome-subtitle\">Sign in to your IELTS GenAI Prep account</p>
            </div>
        </div>
        
        <!-- Body -->
        <div class=\"login-body\">
            <!-- New User Section -->
            <div class=\"new-user-section\">
                <div class=\"new-user-title\">
                    <i class=\"fas fa-info-circle me-2\"></i>
                    New to IELTS GenAI Prep?
                </div>
                <div class=\"new-user-steps\">
                    To get started, you need to:
                    <ol>
                        <li>Download our mobile app (iOS/Android)</li>
                        <li>Create an account and purchase assessments</li>
                        <li>Return here to access your assessments on desktop</li>
                    </ol>
                </div>
                <div class=\"app-store-buttons\">
                    <a href=\"#\" class=\"app-btn\">
                        <i class=\"fab fa-apple\"></i>
                        App Store
                    </a>
                    <a href=\"#\" class=\"app-btn\">
                        <i class=\"fab fa-google-play\"></i>
                        Google Play
                    </a>
                </div>
            </div>
            
            <!-- Login Form -->
            <form id=\"loginForm\">
                <div class=\"mb-3\">
                    <label for=\"email\" class=\"form-label\">
                        <i class=\"fas fa-envelope\"></i>
                        Email Address
                    </label>
                    <input type=\"email\" class=\"form-control\" id=\"email\" name=\"email\" required>
                </div>
                
                <div class=\"mb-3\">
                    <label for=\"password\" class=\"form-label\">
                        <i class=\"fas fa-lock\"></i>
                        Password
                    </label>
                    <input type=\"password\" class=\"form-control\" id=\"password\" name=\"password\" required>
                </div>
                
                <div class=\"mb-3 d-flex justify-content-between align-items-center\">
                    <div class=\"form-check\">
                        <input class=\"form-check-input\" type=\"checkbox\" id=\"remember\" name=\"remember\">
                        <label class=\"form-check-label\" for=\"remember\">
                            Remember me for 30 days
                        </label>
                    </div>
                </div>
                
                <!-- reCAPTCHA -->
                <div class=\"recaptcha-container\">
                    <div class=\"g-recaptcha\" data-sitekey=\"6LcYOkUqAAAAAK8xH4iJcZv_TfUdJ8TlYS_Ov8Ix\"></div>
                </div>
                
                <div class=\"d-grid mb-3\">
                    <button type=\"submit\" class=\"btn btn-primary\" id=\"loginBtn\">
                        <i class=\"fas fa-sign-in-alt me-2\"></i>
                        Sign In
                    </button>
                </div>
                
                <div class=\"text-center\">
                    <a href=\"#\" class=\"forgot-password\">
                        <i class=\"fas fa-key me-1\"></i>
                        Forgot your password?
                    </a>
                </div>
            </form>
            
            <!-- Privacy Notice -->
            <div class=\"privacy-notice\">
                This site is protected by Google reCAPTCHA v2 and the Google 
                <a href=\"https://policies.google.com/privacy\" target=\"_blank\">Privacy Policy</a> 
                and <a href=\"https://policies.google.com/terms\" target=\"_blank\">Terms of Service</a> apply.
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js\"></script>
    
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const recaptchaResponse = grecaptcha.getResponse();
            const loginBtn = document.getElementById('loginBtn');
            
            // Validate form fields
            if (!email || !password) {
                alert('Please fill in all fields');
                return;
            }
            
            // Validate reCAPTCHA
            if (!recaptchaResponse) {
                alert('Please complete the reCAPTCHA verification');
                return;
            }
            
            // Disable submit button
            loginBtn.disabled = true;
            loginBtn.innerHTML = '<i class=\"fas fa-spinner fa-spin me-2\"></i>Signing in...';
            
            // Here you would normally submit to your authentication endpoint
            setTimeout(() => {
                alert('Authentication system integration in progress. This will connect to your Lambda backend for user verification.');
                loginBtn.disabled = false;
                loginBtn.innerHTML = '<i class=\"fas fa-sign-in-alt me-2\"></i>Sign In';
                grecaptcha.reset();
            }, 2000);
        });
    </script>
</body>
</html>"""
    
    privacy_html = """<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Privacy Policy - IELTS GenAI Prep</title>
    
    <!-- Bootstrap CSS -->
    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
    
    <!-- Font Awesome for icons -->
    <link href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css\" rel=\"stylesheet\">
    
    <!-- Google Fonts -->
    <link href=\"https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap\" rel=\"stylesheet\">
    
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            line-height: 1.6;
            background-color: #f8f9fa;
        }
        
        .navbar {
            background-color: #fff !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-brand {
            font-weight: bold;
            color: #4361ee !important;
        }
        
        .policy-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-top: 30px;
            margin-bottom: 30px;
        }
        
        .policy-header {
            background: linear-gradient(135deg, #4361ee 0%, #3651d4 100%);
            color: white;
            padding: 30px;
            border-radius: 10px 10px 0 0;
        }
        
        .policy-content {
            padding: 40px;
        }
        
        .policy-section {
            margin-bottom: 30px;
        }
        
        .policy-section h2 {
            color: #4361ee;
            font-weight: 600;
            margin-bottom: 15px;
        }
        
        .policy-section h3 {
            color: #495057;
            font-weight: 500;
            margin-top: 20px;
            margin-bottom: 10px;
        }
        
        .policy-section ul {
            padding-left: 20px;
        }
        
        .policy-section li {
            margin-bottom: 8px;
        }
        
        .last-updated {
            background: #e7f3ff;
            border: 1px solid #b3d7ff;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 30px;
        }
        
        .contact-info {
            background: #f8f9fa;
            border-left: 4px solid #4361ee;
            padding: 20px;
            margin-top: 30px;
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <nav class=\"navbar navbar-expand-lg navbar-light bg-light\">
        <div class=\"container\">
            <a class=\"navbar-brand\" href=\"/\">
                <i class=\"fas fa-graduation-cap me-2\"></i>IELTS GenAI Prep
            </a>
            <div class=\"navbar-nav ms-auto\">
                <a class=\"nav-link\" href=\"/\">Home</a>
                <a class=\"nav-link\" href=\"/login\">Login</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class=\"container\">
        <div class=\"row justify-content-center\">
            <div class=\"col-lg-10\">
                <div class=\"policy-container\">
                    <!-- Header -->
                    <div class=\"policy-header\">
                        <h1 class=\"mb-0\">Privacy Policy</h1>
                        <p class=\"mb-0 mt-2 opacity-75\">How we protect and handle your information</p>
                    </div>
                    
                    <!-- Content -->
                    <div class=\"policy-content\">
                        <div class=\"last-updated\">
                            <p class=\"mb-0\"><strong><i class=\"fas fa-calendar-alt me-2\"></i>Last Updated:</strong> January 2025</p>
                        </div>

                        <section class=\"policy-section\">
                            <h2>1. Introduction</h2>
                            <p>Welcome to IELTS GenAI Prep, featuring TrueScore® and ClearScore® - the world's ONLY GenAI assessor tools for IELTS test preparation. We respect your privacy and are committed to protecting your personal data.</p>
                            <p>This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our IELTS preparation services, including through our website and mobile applications.</p>
                            <p>Please read this Privacy Policy carefully. If you disagree with any part of this Privacy Policy, please do not use our Service.</p>
                        </section>

                        <section class=\"policy-section\">
                            <h2>2. Information We Collect</h2>
                            <p>We collect several types of information from and about users of our Service:</p>
                            <ul>
                                <li><strong>Personal Data:</strong> Information that can identify you, such as your name, email address, and account credentials</li>
                                <li><strong>Assessment Data:</strong> Your test responses, scores, feedback, and performance analytics</li>
                                <li><strong>Audio Recordings:</strong> When you take speaking assessments, we process audio recordings to provide AI-powered feedback using Amazon Nova Sonic technology</li>
                                <li><strong>Usage Data:</strong> Information about how you use our Service, including study patterns and progress tracking</li>
                                <li><strong>Technical Data:</strong> IP address, browser type, device information, and app usage analytics</li>
                                <li><strong>Payment Information:</strong> Billing details processed securely through Apple App Store and Google Play Store</li>
                            </ul>
                        </section>

                        <section class=\"policy-section\">
                            <h2>3. How We Use Your Information</h2>
                            <p>We use your information for the following purposes:</p>
                            <ul>
                                <li>Providing and maintaining our assessment services</li>
                                <li>Processing your speaking and writing assessments using advanced AI technology</li>
                                <li>Generating personalized feedback and performance analytics</li>
                                <li>Managing your account and assessment purchases</li>
                                <li>Improving our AI assessment algorithms and service quality</li>
                                <li>Communicating with you about your account and service updates</li>
                                <li>Ensuring the security and integrity of our platform</li>
                                <li>Complying with legal obligations and tax requirements</li>
                            </ul>
                        </section>

                        <section class=\"policy-section\">
                            <h2>4. Audio Data Processing</h2>
                            <p>For speaking assessments using our ClearScore® technology:</p>
                            <ul>
                                <li>Audio recordings are processed in real-time using Amazon Nova Sonic AI</li>
                                <li>Recordings are temporarily stored during assessment processing</li>
                                <li>Audio data is automatically deleted after assessment completion</li>
                                <li>Only transcripts and assessment results are permanently retained</li>
                                <li>We do not store or retain voice data for any purpose beyond assessment processing</li>
                            </ul>
                        </section>

                        <section class=\"policy-section\">
                            <h2>5. Data Retention</h2>
                            <p>We retain different types of data for different periods:</p>
                            <ul>
                                <li><strong>Account Information:</strong> Retained while your account is active and for legal compliance periods after deletion</li>
                                <li><strong>Assessment Results:</strong> Stored permanently to provide you with ongoing access to your progress and feedback</li>
                                <li><strong>Audio Recordings:</strong> Processed temporarily and automatically deleted after assessment completion</li>
                                <li><strong>Payment Information:</strong> Retained according to financial regulations and app store requirements</li>
                                <li><strong>Inactive Accounts:</strong> Automatically deleted after 24 months of inactivity</li>
                            </ul>
                        </section>

                        <section class=\"policy-section\">
                            <h2>6. Data Sharing and Third Parties</h2>
                            <p>We share your information only when necessary:</p>
                            <ul>
                                <li><strong>AI Service Providers:</strong> Amazon Web Services for Nova Sonic and Nova Micro AI processing</li>
                                <li><strong>App Store Partners:</strong> Apple App Store and Google Play Store for payment processing</li>
                                <li><strong>Cloud Infrastructure:</strong> AWS services for secure data storage and processing</li>
                                <li><strong>Legal Requirements:</strong> When required by law or to protect our rights and user safety</li>
                            </ul>
                            <p><strong>We do not sell your personal information to third parties.</strong></p>
                        </section>

                        <section class=\"policy-section\">
                            <h2>7. Data Security</h2>
                            <p>We implement enterprise-grade security measures:</p>
                            <ul>
                                <li>End-to-end encryption for all data transmission</li>
                                <li>Secure AWS infrastructure with multiple availability zones</li>
                                <li>Regular security audits and vulnerability assessments</li>
                                <li>Access controls and authentication for all data access</li>
                                <li>Automatic data backup and disaster recovery procedures</li>
                            </ul>
                        </section>

                        <section class=\"policy-section\">
                            <h2>8. Your Rights</h2>
                            <p>You have the following rights regarding your personal data:</p>
                            <ul>
                                <li><strong>Access:</strong> Request access to your personal data</li>
                                <li><strong>Correction:</strong> Request correction of inaccurate data</li>
                                <li><strong>Deletion:</strong> Request deletion of your personal data</li>
                                <li><strong>Portability:</strong> Request export of your assessment data</li>
                                <li><strong>Objection:</strong> Object to certain processing activities</li>
                            </ul>
                            <p>To exercise these rights, please contact us through our mobile app support system.</p>
                        </section>

                        <section class=\"policy-section\">
                            <h2>9. International Data Transfers</h2>
                            <p>Our services operate globally using AWS infrastructure. Your data may be processed in:</p>
                            <ul>
                                <li>United States (primary AWS region)</li>
                                <li>Europe (EU-West region)</li>
                                <li>Asia-Pacific (AP-Southeast region)</li>
                            </ul>
                            <p>All international transfers comply with applicable data protection laws and AWS security standards.</p>
                        </section>

                        <section class=\"policy-section\">
                            <h2>10. Children's Privacy</h2>
                            <p>Our Service is intended for users aged 16 and above. We do not knowingly collect personal information from children under 16. If we become aware that we have collected personal data from a child under 16, we will take steps to delete such information.</p>
                        </section>

                        <section class=\"policy-section\">
                            <h2>11. Changes to This Privacy Policy</h2>
                            <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the \"Last Updated\" date.</p>
                            <p>You are advised to review this Privacy Policy periodically for any changes.</p>
                        </section>

                        <div class=\"contact-info\">
                            <h3><i class=\"fas fa-envelope me-2\"></i>Contact Us</h3>
                            <p class=\"mb-0\">If you have any questions about this Privacy Policy, please contact us through our mobile app support system or visit our website at <strong>ieltsaiprep.com</strong></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class=\"bg-dark text-white py-4 mt-5\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-12 text-center\">
                    <p>&copy; 2025 IELTS GenAI Prep. All rights reserved.</p>
                    <div>
                        <a href=\"/privacy-policy\" class=\"text-white me-3\">Privacy Policy</a>
                        <a href=\"/terms-of-service\" class=\"text-white\">Terms of Service</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js\"></script>
</body>
</html>"""
    
    terms_html = """<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Terms of Service - IELTS GenAI Prep</title>
    
    <!-- Bootstrap CSS -->
    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
    
    <!-- Font Awesome for icons -->
    <link href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css\" rel=\"stylesheet\">
    
    <!-- Google Fonts -->
    <link href=\"https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap\" rel=\"stylesheet\">
    
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            line-height: 1.6;
            background-color: #f8f9fa;
        }
        
        .navbar {
            background-color: #fff !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-brand {
            font-weight: bold;
            color: #4361ee !important;
        }
        
        .terms-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-top: 30px;
            margin-bottom: 30px;
        }
        
        .terms-header {
            background: linear-gradient(135deg, #4361ee 0%, #3651d4 100%);
            color: white;
            padding: 30px;
            border-radius: 10px 10px 0 0;
        }
        
        .terms-content {
            padding: 40px;
        }
        
        .terms-section {
            margin-bottom: 30px;
        }
        
        .terms-section h2 {
            color: #4361ee;
            font-weight: 600;
            margin-bottom: 15px;
        }
        
        .terms-section h3 {
            color: #495057;
            font-weight: 500;
            margin-top: 20px;
            margin-bottom: 10px;
        }
        
        .terms-section ul {
            padding-left: 20px;
        }
        
        .terms-section li {
            margin-bottom: 8px;
        }
        
        .last-updated {
            background: #e7f3ff;
            border: 1px solid #b3d7ff;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 30px;
        }
        
        .contact-info {
            background: #f8f9fa;
            border-left: 4px solid #4361ee;
            padding: 20px;
            margin-top: 30px;
        }
        
        .pricing-highlight {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 8px;
            padding: 15px;
            margin: 15px 0;
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <nav class=\"navbar navbar-expand-lg navbar-light bg-light\">
        <div class=\"container\">
            <a class=\"navbar-brand\" href=\"/\">
                <i class=\"fas fa-graduation-cap me-2\"></i>IELTS GenAI Prep
            </a>
            <div class=\"navbar-nav ms-auto\">
                <a class=\"nav-link\" href=\"/\">Home</a>
                <a class=\"nav-link\" href=\"/login\">Login</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class=\"container\">
        <div class=\"row justify-content-center\">
            <div class=\"col-lg-10\">
                <div class=\"terms-container\">
                    <!-- Header -->
                    <div class=\"terms-header\">
                        <h1 class=\"mb-0\">Terms of Service</h1>
                        <p class=\"mb-0 mt-2 opacity-75\">Agreement for using IELTS GenAI Prep services</p>
                    </div>
                    
                    <!-- Content -->
                    <div class=\"terms-content\">
                        <div class=\"last-updated\">
                            <p class=\"mb-0\"><strong><i class=\"fas fa-calendar-alt me-2\"></i>Last Updated:</strong> January 2025</p>
                        </div>

                        <section class=\"terms-section\">
                            <h2>1. Introduction</h2>
                            <p>Welcome to IELTS GenAI Prep, featuring TrueScore® and ClearScore® - the world's ONLY GenAI assessor tools for IELTS test preparation. These Terms of Service (\"Terms\") govern your use of our website, mobile applications, and services (collectively, the \"Service\").</p>
                            <p>Our platform utilizes cutting-edge artificial intelligence technology, including Amazon Nova Sonic and Nova Micro, to provide unparalleled AI-powered IELTS assessment and feedback.</p>
                            <p>By accessing or using our Service, you agree to be bound by these Terms. If you disagree with any part of these Terms, you may not access the Service.</p>
                        </section>

                        <section class=\"terms-section\">
                            <h2>2. Eligibility</h2>
                            <p>You must be at least 16 years old to use our Service. By using our Service, you represent and warrant that you meet this requirement and have the legal capacity to enter into these Terms.</p>
                        </section>

                        <section class=\"terms-section\">
                            <h2>3. User Accounts</h2>
                            <p>When you create an account with us, you must provide accurate, complete, and current information. You are responsible for:</p>
                            <ul>
                                <li>Maintaining the confidentiality of your account credentials</li>
                                <li>All activities that occur under your account</li>
                                <li>Notifying us immediately of any unauthorized access</li>
                                <li>Ensuring your contact information remains current</li>
                            </ul>
                            <p>You may not share your account with others or allow others to access your assessments.</p>
                        </section>

                        <section class=\"terms-section\">
                            <h2>4. Assessment Packages and Payments</h2>
                            <p>Our Service offers four distinct assessment products:</p>
                            <ul>
                                <li><strong>TrueScore® Academic Writing Assessment</strong> - AI-powered writing evaluation for Academic IELTS</li>
                                <li><strong>TrueScore® General Writing Assessment</strong> - AI-powered writing evaluation for General Training IELTS</li>
                                <li><strong>ClearScore® Academic Speaking Assessment</strong> - AI conversation-based speaking evaluation for Academic IELTS</li>
                                <li><strong>ClearScore® General Speaking Assessment</strong> - AI conversation-based speaking evaluation for General Training IELTS</li>
                            </ul>
                            
                            <div class=\"pricing-highlight\">
                                <h3><i class=\"fas fa-dollar-sign me-2\"></i>Pricing Structure</h3>
                                <p><strong>Each assessment product costs $36.00 CAD</strong> and includes:</p>
                                <ul class=\"mb-0\">
                                    <li>4 unique assessment attempts</li>
                                    <li>Comprehensive AI-powered feedback</li>
                                    <li>Detailed performance analytics</li>
                                    <li>Permanent access to completed assessments</li>
                                </ul>
                            </div>
                            
                            <p><strong>Important Payment Terms:</strong></p>
                            <ul>
                                <li>All purchases must be made through our mobile app via Apple App Store or Google Play Store</li>
                                <li>Payments are processed securely through official app store billing systems</li>
                                <li>All sales are final - refunds are handled according to respective app store policies</li>
                                <li>Prices are subject to change for new purchases without notice</li>
                                <li>Users retain permanent access to completed assessment results</li>
                            </ul>
                        </section>

                        <section class=\"terms-section\">
                            <h2>5. Mobile-First Architecture</h2>
                            <p>Our service operates on a mobile-first authentication model:</p>
                            <ul>
                                <li>Account creation and purchases must be completed through our mobile application</li>
                                <li>Website access requires prior mobile app registration and purchase</li>
                                <li>The same credentials work across both mobile and web platforms</li>
                                <li>Cross-platform session management provides seamless access</li>
                            </ul>
                        </section>

                        <section class=\"terms-section\">
                            <h2>6. AI Technology and Assessment Process</h2>
                            <p>Our assessments utilize advanced AI technology:</p>
                            <ul>
                                <li><strong>Amazon Nova Sonic:</strong> Powers bi-directional speech-to-speech conversations for speaking assessments</li>
                                <li><strong>Amazon Nova Micro:</strong> Provides comprehensive text analysis for writing assessments</li>
                                <li><strong>Real-time Processing:</strong> Immediate feedback and scoring upon assessment completion</li>
                                <li><strong>IELTS Alignment:</strong> All assessments follow official IELTS criteria and band descriptors</li>
                            </ul>
                        </section>

                        <section class=\"terms-section\">
                            <h2>7. Intellectual Property</h2>
                            <p>The Service and its original content, features, and functionality are and will remain the exclusive property of IELTS GenAI Prep and its licensors. This includes:</p>
                            <ul>
                                <li>TrueScore® and ClearScore® trademarks and technologies</li>
                                <li>Assessment questions, rubrics, and evaluation algorithms</li>
                                <li>AI models, prompts, and processing methodologies</li>
                                <li>User interface designs and software architecture</li>
                            </ul>
                            <p>Our trademarks and trade dress may not be used without our prior written consent.</p>
                        </section>

                        <section class=\"terms-section\">
                            <h2>8. User Content and Privacy</h2>
                            <p>When you submit content for assessment:</p>
                            <ul>
                                <li>You retain ownership of your submitted content</li>
                                <li>You grant us license to process your content for assessment purposes</li>
                                <li>Audio recordings are processed temporarily and automatically deleted</li>
                                <li>Only assessment results and transcripts are permanently stored</li>
                                <li>We do not use your content for training AI models</li>
                            </ul>
                        </section>

                        <section class=\"terms-section\">
                            <h2>9. Security and Platform Protection</h2>
                            <p>We maintain enterprise-grade security measures:</p>
                            <ul>
                                <li><strong>Account Security:</strong> Automatic protection with rate limiting and lockouts after failed attempts</li>
                                <li><strong>Data Encryption:</strong> End-to-end encryption for all data transmission and storage</li>
                                <li><strong>Session Monitoring:</strong> Real-time detection of suspicious activity</li>
                                <li><strong>Input Validation:</strong> Comprehensive protection against malicious attacks</li>
                                <li><strong>API Protection:</strong> Rate limiting on all assessment endpoints</li>
                            </ul>
                        </section>

                        <section class=\"terms-section\">
                            <h2>10. Prohibited Uses</h2>
                            <p>You agree not to:</p>
                            <ul>
                                <li>Use the Service for any unlawful purposes</li>
                                <li>Impersonate any person or entity</li>
                                <li>Interfere with or disrupt the Service or its security features</li>
                                <li>Use automated systems to access assessments</li>
                                <li>Share your account credentials or assessments with others</li>
                                <li>Attempt to reverse engineer our AI assessment algorithms</li>
                                <li>Bypass rate limiting or security measures</li>
                                <li>Submit malicious code or attempt injection attacks</li>
                            </ul>
                        </section>

                        <section class=\"terms-section\">
                            <h2>11. Service Availability</h2>
                            <p>We strive to maintain high service availability:</p>
                            <ul>
                                <li>Services operate 24/7 with global AWS infrastructure</li>
                                <li>Planned maintenance will be announced in advance when possible</li>
                                <li>We do not guarantee uninterrupted access due to technical limitations</li>
                                <li>Assessment attempts are not deducted for service-related failures</li>
                            </ul>
                        </section>

                        <section class=\"terms-section\">
                            <h2>12. Limitation of Liability</h2>
                            <p>To the maximum extent permitted by law, IELTS GenAI Prep shall not be liable for:</p>
                            <ul>
                                <li>Any indirect, incidental, special, or consequential damages</li>
                                <li>Loss of profits, data, or business opportunities</li>
                                <li>Any damages resulting from your use or inability to use the Service</li>
                                <li>Any conduct or content of third parties</li>
                                <li>Unauthorized access or alteration of your transmissions</li>
                            </ul>
                        </section>

                        <section class=\"terms-section\">
                            <h2>13. Disclaimer</h2>
                            <p>The Service is provided on an \"AS IS\" and \"AS AVAILABLE\" basis without warranties of any kind. We disclaim all warranties, express or implied, including:</p>
                            <ul>
                                <li>Merchantability and fitness for a particular purpose</li>
                                <li>Non-infringement of third-party rights</li>
                                <li>Accuracy or completeness of assessment results</li>
                                <li>Compatibility with official IELTS test outcomes</li>
                            </ul>
                            <p><strong>Important:</strong> Our assessments are for practice purposes only and do not guarantee performance on official IELTS tests.</p>
                        </section>

                        <section class=\"terms-section\">
                            <h2>14. Termination</h2>
                            <p>We may terminate or suspend your account immediately if you:</p>
                            <ul>
                                <li>Violate these Terms of Service</li>
                                <li>Engage in fraudulent or abusive behavior</li>
                                <li>Attempt to compromise platform security</li>
                                <li>Remain inactive for more than 24 months</li>
                            </ul>
                            <p>Upon termination, your right to use the Service ceases immediately, though completed assessment data may be retained for legal compliance.</p>
                        </section>

                        <section class=\"terms-section\">
                            <h2>15. Changes to Terms</h2>
                            <p>We reserve the right to modify these Terms at any time. When we make changes:</p>
                            <ul>
                                <li>We will update the \"Last Updated\" date</li>
                                <li>Significant changes will be communicated through the app</li>
                                <li>Continued use constitutes acceptance of updated Terms</li>
                                <li>You should review Terms periodically</li>
                            </ul>
                        </section>

                        <section class=\"terms-section\">
                            <h2>16. Governing Law</h2>
                            <p>These Terms shall be governed by and construed in accordance with applicable international laws and regulations for digital services. Any disputes will be resolved through binding arbitration.</p>
                        </section>

                        <div class=\"contact-info\">
                            <h3><i class=\"fas fa-envelope me-2\"></i>Contact Us</h3>
                            <p class=\"mb-0\">If you have any questions about these Terms of Service, please contact us through our mobile app support system or visit our website at <strong>ieltsaiprep.com</strong></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class=\"bg-dark text-white py-4 mt-5\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-12 text-center\">
                    <p>&copy; 2025 IELTS GenAI Prep. All rights reserved.</p>
                    <div>
                        <a href=\"/privacy-policy\" class=\"text-white me-3\">Privacy Policy</a>
                        <a href=\"/terms-of-service\" class=\"text-white\">Terms of Service</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js\"></script>
</body>
</html>"""
    
    # Dashboard template
    dashboard_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Roboto', sans-serif; background: #f8f9fa; }
        .navbar { background-color: #fff !important; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .assessment-card { border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand fw-bold" href="/"><i class="fas fa-graduation-cap me-2"></i>IELTS GenAI Prep</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="/logout">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <h1 class="mb-4">Your Assessment Dashboard</h1>
        <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i>
            Welcome! Your purchased assessments will appear here once you complete the mobile app purchase verification.
        </div>
        
        <div class="row">
            <div class="col-md-6 col-lg-3 mb-4">
                <div class="card assessment-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-pen-fancy fa-3x text-primary mb-3"></i>
                        <h5>Academic Writing</h5>
                        <p class="text-muted small">TrueScore® Assessment</p>
                        <span class="badge bg-secondary">Coming Soon</span>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-3 mb-4">
                <div class="card assessment-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-microphone fa-3x text-success mb-3"></i>
                        <h5>Academic Speaking</h5>
                        <p class="text-muted small">ClearScore® Assessment</p>
                        <span class="badge bg-secondary">Coming Soon</span>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-3 mb-4">
                <div class="card assessment-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-pen-fancy fa-3x text-warning mb-3"></i>
                        <h5>General Writing</h5>
                        <p class="text-muted small">TrueScore® Assessment</p>
                        <span class="badge bg-secondary">Coming Soon</span>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-3 mb-4">
                <div class="card assessment-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-microphone fa-3x text-info mb-3"></i>
                        <h5>General Speaking</h5>
                        <p class="text-muted small">ClearScore® Assessment</p>
                        <span class="badge bg-secondary">Coming Soon</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>"""

    # Route handling
    if path == '/' or path == '/index.html':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'text/html; charset=utf-8',
                'Cache-Control': 'no-cache'
            },
            'body': home_html
        }
    
    elif path == '/login':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'text/html; charset=utf-8',
                'Cache-Control': 'no-cache'
            },
            'body': login_html
        }
    
    elif path == '/dashboard':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'text/html; charset=utf-8',
                'Cache-Control': 'no-cache'
            },
            'body': dashboard_html
        }
    
    elif path == '/privacy-policy':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'text/html; charset=utf-8',
                'Cache-Control': 'no-cache'
            },
            'body': privacy_html
        }
    
    elif path == '/terms-of-service':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'text/html; charset=utf-8',
                'Cache-Control': 'no-cache'
            },
            'body': terms_html
        }
    
    elif path == '/health':
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'status': 'healthy', 'service': 'IELTS GenAI Prep API'})
        }
    
    else:
        return {
            'statusCode': 302,
            'headers': {'Location': '/'},
            'body': ''
        }
