import json
import hashlib
import urllib.parse
from datetime import datetime

class MockUsers:
    def __init__(self):
        self.users = {
            'test@ieltsgenaiprep.com': {
                'password_hash': self.hash_password('testpassword123')
            }
        }
        
    def hash_password(self, password):
        salt = b'ielts_genai_prep_salt'
        return hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000).hex()
        
    def verify_password(self, password, hash_stored):
        return self.hash_password(password) == hash_stored
        
    def get_user(self, email):
        return self.users.get(email)

user_db = MockUsers()

def lambda_handler(event, context):
    try:
        method = event.get('httpMethod', 'GET')
        path = event.get('path', '/')
        body = event.get('body', '')
        
        if path == '/login' and method == 'POST':
            form_data = urllib.parse.parse_qs(body)
            email = form_data.get('email', [''])[0].strip().lower()
            password = form_data.get('password', [''])[0]
            
            if not email or not password:
                return login_page('Please fill in all fields')
            
            user = user_db.get_user(email)
            if not user or not user_db.verify_password(password, user['password_hash']):
                return login_page('Invalid email or password')
            
            return {
                'statusCode': 302,
                'headers': {
                    'Location': '/dashboard',
                    'Set-Cookie': 'session=valid; Path=/; HttpOnly'
                },
                'body': ''
            }
        
        elif path == '/login':
            return login_page()
        elif path == '/dashboard':
            return dashboard_page()
        else:
            return home_page()
            
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }

def home_page():
    html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Roboto', sans-serif; }
        .pricing-card { border: 1px solid rgba(0, 0, 0, 0.125); box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); transition: transform 0.2s; }
        .pricing-card:hover { transform: translateY(-5px); }
        .genai-brand-section { margin-bottom: 60px; }
        .brand-icon { font-size: 2.5rem; margin-bottom: 15px; }
        .brand-title { font-size: 2rem; margin-bottom: 0.5rem; }
        .brand-tagline { color: #666; margin-bottom: 2rem; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">IELTS GenAI Prep</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="/login">Login</a>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row mb-5">
            <div class="col-12 text-center">
                <h1>GenAI Assessed IELTS Modules</h1>
                <p class="lead">Our specialized GenAI technologies provide accurate assessment for IELTS preparation</p>
            </div>
        </div>
        
        <div class="genai-brand-section">
            <div class="text-center mb-4">
                <div class="brand-icon text-success">
                    <i class="fas fa-pencil-alt"></i>
                </div>
                <h2 class="brand-title">TrueScore® Writing Assessment</h2>
                <p class="brand-tagline">Professional-grade assessment of IELTS writing tasks with detailed feedback and scoring</p>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card pricing-card">
                        <div class="card-header bg-success text-white text-center">
                            <h3 class="my-0 font-weight-bold">Academic Writing</h3>
                        </div>
                        <div class="card-body">
                            <h1 class="card-title pricing-card-title text-center">6<small class="text-muted"> for 4 assessments</small></h1>
                            <ul class="list-unstyled mt-3 mb-4">
                                <li><i class="fas fa-check text-success me-2"></i>4 Unique Assessments Included</li>
                                <li><i class="fas fa-check text-success me-2"></i>Task 1 & Task 2 Assessment</li>
                                <li><i class="fas fa-check text-success me-2"></i>TrueScore® GenAI Evaluation</li>
                                <li><i class="fas fa-check text-success me-2"></i>Official IELTS Criteria Alignment</li>
                            </ul>
                            <button class="btn btn-success btn-lg btn-block">Purchase Now</button>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 mb-4">
                    <div class="card pricing-card">
                        <div class="card-header bg-success text-white text-center">
                            <h3 class="my-0 font-weight-bold">General Training Writing</h3>
                        </div>
                        <div class="card-body">
                            <h1 class="card-title pricing-card-title text-center">6<small class="text-muted"> for 4 assessments</small></h1>
                            <ul class="list-unstyled mt-3 mb-4">
                                <li><i class="fas fa-check text-success me-2"></i>4 Unique Assessments Included</li>
                                <li><i class="fas fa-check text-success me-2"></i>Task 1: Letters Assessment</li>
                                <li><i class="fas fa-check text-success me-2"></i>Task 2: Essays Assessment</li>
                                <li><i class="fas fa-check text-success me-2"></i>TrueScore® GenAI Evaluation</li>
                            </ul>
                            <button class="btn btn-success btn-lg btn-block">Purchase Now</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="genai-brand-section">
            <div class="text-center mb-4">
                <div class="brand-icon text-primary">
                    <i class="fas fa-microphone-alt"></i>
                </div>
                <h2 class="brand-title">ClearScore® Speaking Assessment</h2>
                <p class="brand-tagline">Advanced speech analysis and feedback to improve your IELTS speaking performance</p>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card pricing-card">
                        <div class="card-header bg-primary text-white text-center">
                            <h3 class="my-0 font-weight-bold">Academic Speaking</h3>
                        </div>
                        <div class="card-body">
                            <h1 class="card-title pricing-card-title text-center">6<small class="text-muted"> for 4 assessments</small></h1>
                            <ul class="list-unstyled mt-3 mb-4">
                                <li><i class="fas fa-check text-success me-2"></i>4 Unique Assessments Included</li>
                                <li><i class="fas fa-check text-success me-2"></i>All 3 speaking parts covered</li>
                                <li><i class="fas fa-check text-success me-2"></i>ClearScore® GenAI speech analysis</li>
                                <li><i class="fas fa-check text-success me-2"></i>Real-time feedback</li>
                            </ul>
                            <button class="btn btn-primary btn-lg btn-block">Purchase Now</button>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 mb-4">
                    <div class="card pricing-card">
                        <div class="card-header bg-primary text-white text-center">
                            <h3 class="my-0 font-weight-bold">General Training Speaking</h3>
                        </div>
                        <div class="card-body">
                            <h1 class="card-title pricing-card-title text-center">6<small class="text-muted"> for 4 assessments</small></h1>
                            <ul class="list-unstyled mt-3 mb-4">
                                <li><i class="fas fa-check text-success me-2"></i>4 Unique Assessments Included</li>
                                <li><i class="fas fa-check text-success me-2"></i>All 3 speaking parts covered</li>
                                <li><i class="fas fa-check text-success me-2"></i>ClearScore® GenAI speech analysis</li>
                                <li><i class="fas fa-check text-success me-2"></i>General Training topics</li>
                            </ul>
                            <button class="btn btn-primary btn-lg btn-block">Purchase Now</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="alert alert-info mt-5">
            <h5>How to Get Started</h5>
            <p>Create your account and purchase assessment packages for 6.00 each through secure app store billing</p>
            <ol>
                <li>Download our mobile app from the App Store or Google Play</li>
                <li>Create an account and purchase your preferred assessments</li>
                <li>Access your assessments on both mobile and desktop platforms</li>
            </ol>
        </div>
    </div>
</body>
</html>"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html'},
        'body': html
    }

def login_page(error_msg=None):
    error_display = f'<div class="alert alert-danger">{error_msg}</div>' if error_msg else ''
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; }}
        .login-container {{ background: white; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); padding: 40px; max-width: 400px; width: 100%; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="login-container">
                    <div class="text-center mb-4">
                        <h2 class="text-primary">Welcome Back</h2>
                        <p class="text-muted">Sign in to your IELTS GenAI Prep account</p>
                    </div>
                    
                    <div class="alert alert-info">
                        <h6>New to IELTS GenAI Prep?</h6>
                        <p class="mb-2">To get started, you need to:</p>
                        <ol class="mb-0">
                            <li>Download our mobile app (iOS/Android)</li>
                            <li>Create an account and purchase assessments</li>
                            <li>Return here to access your assessments on desktop</li>
                        </ol>
                    </div>
                    
                    {error_display}
                    
                    <form method="post" action="/login">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" id="email" value="test@ieltsgenaiprep.com" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" id="password" value="testpassword123" required>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Sign In</button>
                        </div>
                    </form>
                    <div class="text-center mt-3">
                        <a href="/" class="text-decoration-none">← Back to Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html'},
        'body': html
    }

def dashboard_page():
    html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - IELTS GenAI Prep</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .assessment-card { border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); transition: transform 0.3s ease; }
        .assessment-card:hover { transform: translateY(-5px); }
        .header-card { background: white; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="header-card mb-5 p-4">
            <div class="text-center">
                <h1 class="text-primary mb-3">IELTS GenAI Prep Dashboard</h1>
                <p class="lead text-muted">Welcome! Your assessments are ready.</p>
                <p class="text-success"><strong>Login Successful!</strong> Mobile app credentials work on website.</p>
            </div>
        </div>
        
        <div class="row g-4">
            <div class="col-md-6">
                <div class="card assessment-card h-100" style="border-left: 5px solid #4361ee;">
                    <div class="card-body">
                        <h5 class="card-title text-primary">🎓 Academic Writing Assessment</h5>
                        <p class="card-text">TrueScore® GenAI writing evaluation with detailed feedback</p>
                        <p class="text-success"><strong>4 assessments remaining</strong></p>
                        <button class="btn btn-primary">Start Assessment</button>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card assessment-card h-100" style="border-left: 5px solid #e74c3c;">
                    <div class="card-body">
                        <h5 class="card-title text-danger">🎤 Academic Speaking Assessment</h5>
                        <p class="card-text">ClearScore® GenAI speaking practice with AI examiner Maya</p>
                        <p class="text-success"><strong>4 assessments remaining</strong></p>
                        <button class="btn btn-danger">Start Assessment</button>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card assessment-card h-100" style="border-left: 5px solid #2ecc71;">
                    <div class="card-body">
                        <h5 class="card-title text-success">📝 General Writing Assessment</h5>
                        <p class="card-text">TrueScore® GenAI writing evaluation for General Training</p>
                        <p class="text-success"><strong>4 assessments remaining</strong></p>
                        <button class="btn btn-success">Start Assessment</button>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card assessment-card h-100" style="border-left: 5px solid #f39c12;">
                    <div class="card-body">
                        <h5 class="card-title text-warning">🗣️ General Speaking Assessment</h5>
                        <p class="card-text">ClearScore® GenAI speaking practice for General Training</p>
                        <p class="text-success"><strong>4 assessments remaining</strong></p>
                        <button class="btn btn-warning">Start Assessment</button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-5">
            <a href="/login" class="btn btn-outline-light me-3">Logout</a>
            <a href="/" class="btn btn-outline-light">Back to Home</a>
        </div>
    </div>
</body>
</html>"""
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html'},
        'body': html
    }
